<?php
include(dirname(__FILE__).'/../includes/config.php');

session_start();

# Redirect to Dashboard if LoggedIn
if(isset($_SESSION["is_loggedIn"]) && $_SESSION["is_loggedIn"] == 'mrtaxx@gmail.com') {
    header("Location: ".$domain."/backend/post-list.php");
}

# Login
if($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['email_id']) && isset($_POST['password'])) {
    if($_POST['email_id'] == 'mrtaxx@gmail.com' && $_POST['password'] == "Motherfucker17_@") {
        $_SESSION["is_loggedIn"] = 'mrtaxx@gmail.com';
        header("Location: ".$domain."/backend/post-list.php");
    }
    else {
        exit('Invalid login credentials, please go back.');
    }
}
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <?php include('../partials/header.php'); ?>
        <title>Signin to <?= $website_name; ?> Dashboard</title>
    </head>
    <body>
        <?php include('../partials/nav.php'); ?>
        <main>
<section>
    <div class="container">
        <div class="row">
            <div class="col-md-10 col-lg-8 col-xl-6 mx-auto">
				<h2>Log in to your account</h2>
                <div class="p-4 p-sm-5 bg-primary bg-opacity-10 rounded">
                    <form action="<?= $domain; ?>/signin/" method="post">
                        <div class="mb-3">
                            <label class="form-label" for="exampleInputEmail1">Email ID</label>
                            <input type="email" class="form-control" name="email_id" placeholder="Email ID" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label" for="exampleInputPassword1">Password</label>
                            <input type="password" class="form-control" name="password" placeholder="*********" required>
                        </div>
                        <div class="row align-items-center">
                            <div class="col-sm-4">
                                <button type="submit" class="btn btn-success">Sign me in</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>
		</main>
        <?php include('../partials/footer.php'); ?>
    </body>
</html>
