﻿
<?php
include(dirname(__FILE__).'/includes/config.php');

# Recet Posts
$recentPostObjs = recentPosts($pdoObj, 12);
$postOftheMonth = array_rand($recentPostObjs, 1);

# Close Database Connection
$pdoObj=null;
?><!DOCTYPE html>
<html lang="en-US">

<head>
	<?php include('partials/header.php'); ?>
	<title><?= $website_name; ?></title>
</head>

<body>

	<?php include('partials/nav.php'); ?>

    <!-- start of banner two -->
    <section class="banner-2 bg-white overflow-hidden">
        <div class="container">
            <div class="row align-items-center justify-content-between">
                <div class="col-lg-5 col-md-8">
                    <h1 class="mb-4 lh-sm">Welcome to the <br> <?= $website_name; ?></h1>
                    <p class="lead">Subscribe for updates from us, delivered to your inbox twice a month.</p>

                    <!-- start newsletter -->
                    <div class="newsletter-block p-0 mt-4 pt-2">
                        <div id="mc_embed_signup">
                            <form action="<?= $domain; ?>/legal/submit.php" method="post" id="mc-embedded-subscribe-form" name="mc-embedded-subscribe-form">
                                <div id="mc_embed_signup_scroll" class="input-group d-flex">
                                    <input type="email" value="" name="EMAIL"
                                        class="form-control required email flex-grow-1 mb-3" id="mce-EMAIL"
                                        placeholder="Your email address *" aria-label="Subscription"
                                        autocomplete="new-email" required>
                                    <div id="mce-responses" class="clear">
                                        <div class="response" id="mce-error-response" style="display:none"></div>
                                        <div class="response" id="mce-success-response" style="display:none"></div>
                                    </div>
                                    <div style="position: absolute; left: -5000px;" aria-hidden="true">
                                        <input type="text" name="b_92641572a6c6ec43da15feed0_d28bb2454f" tabindex="-1"
                                            value="">
                                    </div>
                                    <div class="input-group-append ms-0 flex-shrink-0">
                                        <button type="submit" name="subscribe" id="mc-embedded-subscribe"
                                            class="input-group-text mb-0 position-relative"
                                            aria-label="Subscription Button">Subscribe</button>
                                    </div>
                                    <small>By clicking Subscribe, you agree to our <a class='text-link active'
                                            href='<?= $domain; ?>/legal/terms-service'>Terms</a> and <a class='text-link active'
                                            href='<?= $domain; ?>/legal/privacy-policy'>Privacy Policy</a>.</small>
                                </div>
                            </form>
                        </div>
                    </div>
                    <!-- end newsletter -->
                </div>

                <?php if(isset($recentPostObjs[$postOftheMonth])) : ?>
                <!-- Post of the month -->
                <div class="col-lg-6">
                    <div class="post-of-the-month"
                        style="background-image:url('<?= $recentPostObjs[$postOftheMonth]['post_image']; ?>')">
                        <div class="text-center">
                            <div class="mb-5">
                                <h2 class="text-uppercase h6 text-black bg-white mb-0 d-inline-block px-3 py-2 lh-1">
                                    Post of the month</h2>
                            </div>
                            <ul class="post-meta list-inline mb-3 text-light">
                                <li class="list-inline-item">
                                    <i class="ti ti-calendar-event me-1"></i><?= $recentPostObjs[$postOftheMonth]['post_date']; ?>
                                </li>
                                <li class="list-inline-item">•</li>
                                <li class="list-inline-item">
                                    <i class="ti ti-clock-2 me-1"></i>05 min read
                                </li>
                            </ul>
                            <h3 class="post-title mb-4 position-relative">
                                <a class='text-white text-link stretched-link' href='<?= $domain; ?>/single?post=<?= $recentPostObjs[$postOftheMonth]['post_slug']; ?>'><?= $recentPostObjs[$postOftheMonth]['post_title']; ?></a>
                            </h3>
                            <div class="post-author">
                                <a class='is-hoverable' href='#'
                                    title='Read all posts of - <?= $author_name; ?>'>
                                    <img loading="lazy" class="w-auto rounded-circle me-2" src="<?= $domain; ?>/assets/frontend/avatar.jpg" alt="<?= $author_name; ?>" width="26" height="26">
                                </a>
                                <span class="text-light">by </span>
                                <a class='text-link text-white' href='#' title='Read all posts of - <?= $author_name; ?>'><?= $author_name; ?></a>
                            </div>
                        </div>
                    </div>
                    <!-- Post of the month -->
                </div>
                <?php endif ?>
            </div>
        </div>
    </section>
    <!-- end of banner two -->

    <!-- start of Recent Posts -->
    <section class="section">
        <div class="container">
            <div class="row align-items-center section-title">
                <div class="col-sm-7">
                    <h2 class="h3 mb-0 title">Recent Posts</h2>
                </div>
                <div class="col-sm-5 text-end d-none d-sm-block">
                    <a class='text-link lead active' href='#'> All Posts <i class="ti ti-arrow-up-right"></i>
                    </a>
                </div>
            </div>
            <div class="row gy-5 gx-md-5">
				<?php foreach($recentPostObjs as $loop_postObj): ?>
                <div class="col-lg-4 col-md-6">
                    <article class="bg-white d-flex flex-column h-100">
                        <div class="post-image">
                            <a class='d-block' href='<?= $domain; ?>/single?post=<?= $loop_postObj['post_slug']; ?>' title='<?= $loop_postObj['post_title']; ?>'>
                                <img loading="lazy" class="w-100 h-auto" src="<?= $loop_postObj['post_image']; ?>" alt="featured_image" width="400" height="264">
                            </a>
                        </div>
                        <div class="p-4 pb-0">
                            <ul class="post-meta list-inline mb-3">
                                <li class="list-inline-item">
                                    <i class="ti ti-calendar-event me-1"></i><?= $loop_postObj['post_date']; ?>
                                </li>
                                <li class="list-inline-item">•</li>
                                <li class="list-inline-item">
                                    <i class="ti ti-clock-2 me-1"></i>05 min read
                                </li>
                            </ul>
                            <div class="position-relative">
                                <h3 class="h4 post-title mb-2 line-clamp clamp-2">
                                    <a class='text-link stretched-link' href='<?= $domain; ?>/single?post=<?= $loop_postObj['post_slug']; ?>' title='Read more about - <?= $loop_postObj['post_title']; ?>'><?= $loop_postObj['post_title']; ?></a>
                                </h3>
                                <p class="mb-0 line-clamp clamp-3"><?= $loop_postObj['post_summary']; ?></p>
                            </div>
                        </div>
                        <div class="post-author d-flex mt-auto p-4">
                            <div class="flex-shrink-0">
                                <a class='is-hoverable' href='#' title='Read all posts of - <?= $author_name; ?>'>
                                    <img loading="lazy" class="rounded-circle w-auto" src="<?= $domain; ?>/assets/frontend/avatar.jpg" alt="<?= $author_name; ?>" width="42" height="42">
                                </a>
                            </div>
                            <div class="flex-grow-1 ms-3">
                                <p class="mb-0 lh-base small">Written by</p>
                                <a class='text-link' href='#' title='Read all posts by - <?= $author_name; ?>'><?= $author_name; ?></a>
                            </div>
                        </div>
                    </article>
                </div>
				<?php endforeach ?>
            </div>
        </div>
    </section>
    <!-- end of Recent Posts -->

    <!-- start of Top Authors -->
    <section class="section bg-white">
        <div class="container">
            <div class="row align-items-center section-title">
                <div class="col-sm-7">
                    <h2 class="h3 mb-0 title">Top Authors</h2>
                </div>
            </div>
            <div id="author-list" class="row gy-5 gx-md-5">
                <div class="col-lg-4 col-md-6">
                    <a class='bg-body text-dark p-3 d-flex is-hoverable' href='#'>
                        <div class="flex-shrink-0 me-3">
                            <img loading="lazy" class="shadow img-fluid" src="<?= $domain; ?>/assets/frontend/images/author/ann-monika.jpg" alt="Ann Monika" width="90" height="90">
                        </div>
                        <div class="flex-grow-1">
                            <div class="d-flex flex-column h-100">
                                <div>
                                    <h3 class="h4 text-dark mb-1 line-clamp clamp-1">Ann Monika</h3>
                                    <p class="mb-2 lh-1 line-clamp clamp-1">Director of Operations</p>
                                </div>
                                <p class="fw-medium mt-auto mb-0 small">
                                    <i class="ti ti-edit-circle me-2"></i>
                                    <span class="text-black">03</span> Published posts
                                </p>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-lg-4 col-md-6">
                    <a class='bg-body text-dark p-3 d-flex is-hoverable' href='#'>
                        <div class="flex-shrink-0 me-3">
                            <img loading="lazy" class="shadow img-fluid" src="<?= $domain; ?>/assets/frontend/images/author/alexander-hipp.jpg" alt="<?= $author_name; ?>" width="90" height="90">
                        </div>
                        <div class="flex-grow-1">
                            <div class="d-flex flex-column h-100">
                                <div>
                                    <h3 class="h4 text-dark mb-1 line-clamp clamp-1"><?= $author_name; ?></h3>
                                    <p class="mb-2 lh-1 line-clamp clamp-1">Director and Chief Evangelist</p>
                                </div>
                                <p class="fw-medium mt-auto mb-0 small">
                                    <i class="ti ti-edit-circle me-2"></i>
                                    <span class="text-black">02</span> Published posts
                                </p>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-lg-4 col-md-6">
                    <a class='bg-body text-dark p-3 d-flex is-hoverable' href='#'>
                        <div class="flex-shrink-0 me-3">
                            <img loading="lazy" class="shadow img-fluid" src="<?= $domain; ?>/assets/frontend/images/author/anil-vugels.jpg"
                                alt="Anil Vugels" width="90" height="90">
                        </div>
                        <div class="flex-grow-1">
                            <div class="d-flex flex-column h-100">
                                <div>
                                    <h3 class="h4 text-dark mb-1 line-clamp clamp-1">Anil Vugels</h3>
                                    <p class="mb-2 lh-1 line-clamp clamp-1">Managing Partner</p>
                                </div>
                                <p class="fw-medium mt-auto mb-0 small">
                                    <i class="ti ti-edit-circle me-2"></i>
                                    <span class="text-black">02</span> Published posts
                                </p>
                            </div>
                        </div>
                    </a>
                </div>
            </div>
        </div>
    </section>
    <!-- end of Top Authors -->

	<?php include('partials/footer.php'); ?>
</body>

</html>