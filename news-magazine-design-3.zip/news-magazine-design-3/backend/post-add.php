<?php
include(dirname(__FILE__).'/../includes/config.php');

# Redirect to SignIn if Not LoggedIn
session_start();
if(!isset($_SESSION["is_loggedIn"]) || $_SESSION["is_loggedIn"] != 'mrtaxx@gmail.com') {
    header("Location: ".$domain."/signin");
}

if($_SERVER['REQUEST_METHOD'] === 'POST') {

    # Create Post
    $insertObj = insertPost($pdoObj, $_POST);

    # Close Database Connection
    $pdoObj=null;

    # Check Create Status
    if($insertObj['status'] == 'failed') {
        echo $insertObj['msg']; exit();
    }

    # Redirect
    header("Location: ".$domain."/backend/post-edit.php?post_id=".$insertObj['msg']);
}
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <?php include('partials/header.php'); ?>
        <title>Add New Post - <?= $website_name; ?></title>
    </head>
    <body>
        <?php include('partials/nav.php'); ?>
        <main>
            <section class="py-4">
                <div class="container">
                    <div class="row pb-4">
                        <div class="col-12">
                            <h1 class="mb-0 h2">Create a post</h1>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-12">
                        <form method="post" action="<?= $domain; ?>/backend/post-add.php" id="postForm">
                            <input type="hidden" id="post_content" name="post_content" required/>

                            <div class="card border">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-12">
                                            <div class="mb-3">
                                                <label class="form-label">Post Title</label>
                                                <input id="con-name" name="post_title" type="text" class="form-control" placeholder="Post Title" required>
                                            </div>
                                        </div>
                                        <div class="col-12">
                                            <div class="mb-3">
                                                <label class="form-label">Post Slug</label>
                                                <input id="con-name" name="post_slug" type="text" class="form-control" placeholder="Post Slug" required>
                                            </div>
                                        </div>
                                        <div class="col-12">
                                            <div class="mb-3">
                                                <label class="form-label">Post Image URL</label>
                                                <input id="con-name" name="post_image" type="text" class="form-control" placeholder="Post Image URL" required>
                                            </div>
                                        </div>
                                        <div class="col-12">
                                            <div class="mb-3">
                                                <label class="form-label">Short Summary</label>
                                                <textarea name="post_summary" class="form-control" rows="3" placeholder="Add Summary" required></textarea>
                                            </div>
                                        </div>
                                        <div class="col-lg-4">
                                            <div class="mb-3">
                                                <label class="form-label">Post Date</label>
                                                <input id="con-name" name="post_date" type="text" class="form-control" placeholder="Post Date" value="<?= date('M d, Y') ?>" required>
                                            </div>
                                        </div>
                                        <div class="col-lg-4">
                                            <div class="mb-3">
                                                <label class="form-label">Category</label>
                                                <select name="post_category" class="form-select" aria-label="Default select example">
                                                    <option>Select Category</option>
                                                    <option value="Celebrities">Celebrities</option>
                                                    <option value="Lifestyles">Lifestyles</option>
                                                    <option value="Fitness">Fitness</option>
                                                    <option value="Travel">Travel</option>
                                                    <option value="Business">Business</option>
                                                    <option value="Marketing">Marketing</option>
                                                </select>
                                            </div>
                                        </div>
                                        
                                        <!-- Main toolbar -->
                                        <div class="col-md-12">
                                            <!-- Subject -->
                                            <div class="mb-3">
                                                <label class="form-label">Post Content</label>
                                                <!-- Editor toolbar -->
                                                <div class="bg-light border border-bottom-0 rounded-top py-3" id="quilltoolbar">
                                                    <span class="ql-formats">
                                                        <select class="ql-size"></select>
                                                    </span>
                                                    <span class="ql-formats">
                                                        <button class="ql-bold"></button>
                                                        <button class="ql-italic"></button>
                                                        <button class="ql-underline"></button>
                                                        <button class="ql-strike"></button>
                                                    </span>
                                                    <span class="ql-formats">
                                                        <select class="ql-color"></select>
                                                        <select class="ql-background"></select>
                                                    </span>
                                                    <span class="ql-formats">
                                                        <button class="ql-code-block"></button>
                                                    </span>
                                                    <span class="ql-formats">
                                                        <button class="ql-list" value="ordered"></button>
                                                        <button class="ql-list" value="bullet"></button>
                                                        <button class="ql-indent" value="-1"></button>
                                                        <button class="ql-indent" value="+1"></button>
                                                    </span>
                                                    <span class="ql-formats">
                                                        <button class="ql-link"></button>
                                                        <button class="ql-image"></button>
                                                    </span>
                                                    <span class="ql-formats">
                                                        <button class="ql-clean"></button>
                                                    </span>
                                                </div>
                                                <!-- Main toolbar -->
                                                <div class="bg-body border rounded-bottom h-500 overflow-hidden" id="quilleditor"></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="card border mt-4">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-lg-6">
                                            <div class="mb-3">
                                                <label class="form-label">Adspect Stream ID</label>
                                                <input id="con-name" name="adspect_stream_id" type="text" class="form-control" placeholder="Adspect Stream ID" value="NA" required>
                                            </div>
                                        </div>
                                        <div class="col-lg-3">
                                            <div class="mb-3">
                                                <label class="form-label">NOIP Campaign ID</label>
                                                <input id="con-name" name="noip_campaign" type="text" class="form-control" placeholder="NOIP Campaign ID" value="NA" required>
                                            </div>
                                        </div>
                                        <div class="col-lg-3">
                                            <div class="mb-3">
                                                <label class="form-label">Age Verification</label>
                                                <input id="con-name" name="age_verification" type="text" class="form-control" placeholder="Age Verification" value="NA" required>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="card border mt-4">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-lg-4">
                                            <div class="mb-3">
                                                <label class="form-label">Related Keyword 1</label>
                                                <input id="con-name" name="related_keyword_1" type="text" class="form-control" placeholder="Related Keyword 1" value="NA" required>
                                            </div>
                                        </div>
                                        <div class="col-lg-8">
                                            <div class="mb-3">
                                                <label class="form-label">Related URL 1</label>
                                                <input id="con-name" name="related_url_1" type="text" class="form-control" placeholder="Related URL 1" value="NA" required>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-lg-4">
                                            <div class="mb-3">
                                                <label class="form-label">Related Keyword 2</label>
                                                <input id="con-name" name="related_keyword_2" type="text" class="form-control" placeholder="Related Keyword 2" value="NA" required>
                                            </div>
                                        </div>
                                        <div class="col-lg-8">
                                            <div class="mb-3">
                                                <label class="form-label">Related URL 2</label>
                                                <input id="con-name" name="related_url_2" type="text" class="form-control" placeholder="Related URL 2" value="NA" required>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-lg-4">
                                            <div class="mb-3">
                                                <label class="form-label">Related Keyword 3</label>
                                                <input id="con-name" name="related_keyword_3" type="text" class="form-control" placeholder="Related Keyword 3" value="NA" required>
                                            </div>
                                        </div>
                                        <div class="col-lg-8">
                                            <div class="mb-3">
                                                <label class="form-label">Related URL 3</label>
                                                <input id="con-name" name="related_url_3" type="text" class="form-control" placeholder="Related URL 3" value="NA" required>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-lg-4">
                                            <div class="mb-3">
                                                <label class="form-label">Related Keyword 4</label>
                                                <input id="con-name" name="related_keyword_4" type="text" class="form-control" placeholder="Related Keyword 4" value="NA" required>
                                            </div>
                                        </div>
                                        <div class="col-lg-8">
                                            <div class="mb-3">
                                                <label class="form-label">Related URL 4</label>
                                                <input id="con-name" name="related_url_4" type="text" class="form-control" placeholder="Related URL 4" value="NA" required>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-lg-4">
                                            <div class="mb-3">
                                                <label class="form-label">Related Keyword 5</label>
                                                <input id="con-name" name="related_keyword_5" type="text" class="form-control" placeholder="Related Keyword 5" value="NA" required>
                                            </div>
                                        </div>
                                        <div class="col-lg-8">
                                            <div class="mb-3">
                                                <label class="form-label">Related URL 5</label>
                                                <input id="con-name" name="related_url_5" type="text" class="form-control" placeholder="Related URL 5" value="NA" required>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Create post button -->
                            <div class="mt-5 col-md-12 text-start">
                                <button class="btn btn-primary w-100" type="submit"><i class="bi bi-save me-2"></i>Create post</button>
                            </div>
                        </form>
                    </div>
                </div>
            </section>
        </main>
        <?php include('partials/footer.php'); ?>
        <script>
            document.getElementById("postForm").addEventListener("submit", function(event) {
                document.getElementById("post_content").value = document.querySelector(".ql-editor").innerHTML;
            });
        </script>
    </body>
</html>
