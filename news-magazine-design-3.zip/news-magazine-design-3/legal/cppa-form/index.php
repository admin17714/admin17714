<?php include(dirname(__FILE__).'/../../includes/config.php'); ?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <title>CCPA Form - <?= $website_name; ?> </title>
        <link rel="icon" href="<?= $domain; ?>/assets/frontend/favicon.ico" type="image/x-icon" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />

        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />

        <link href="https://fonts.googleapis.com/css2?family=Public+Sans:wght@400;500;700&display=swap" rel="stylesheet" />
        <link rel="stylesheet" type="text/css" href="<?= $domain; ?>/legal/css/form.min.css" />
    </head>
    <body class="chrome-wrap">
        <main class="main-wrapper flex justify-center">
            <div class="wrapper-inner">
                <div class="formWrap">
                    <h1 class="formWrap__heading fw-700">Hello!</h1>
                    <p class="formWrap__subHeading">
                        If you are a US Resident, you have certain rights regarding your personal information.
                    </p>
                    <p class="formWrap__subHeading">
                        You can exercise your rights by submitting a request using this web form or by emailing us at support@<?php echo $domainOnly; ?></a>
                    </p>
                    <form class="form" autocomplete="off" method="post" action="<?= $domain; ?>/legal/submit.php">
                        <div class="form__wrap--main flex">
                            <div class="form__inner flex_1">
                                <label><span>*</span> First name</label>
                                <input autocomplete="off" required type="text" name="first_name" class="input" />
                            </div>
                            <div class="form__inner pdl-20 flex_1">
                                <label><span>*</span> Last name</label>
                                <input autocomplete="off" required type="text" name="last_name" class="input" />
                            </div>
                        </div>

                        <div class="form__inner flex_1">
                            <label><span>*</span> Email ID</label>
                            <input autocomplete="off" required type="text" name="email" class="input" />
                        </div>

                        <div class="form__inner flex_1 customSelect">
                            <label><span>*</span> Request Type</label>
                            <select name="request_type" required id="request_type">
                                <option value="">Select</option>
                                <option value="access">Access to your personal information</option>
                                <option value="deletion">Deletion of your personal information</option>
                                <option value="optOut"> Opt-out from the sharing of your personal information</option>
                                <option value="correcting"> Correcting your personal information</option>
                            </select>
                        </div>

                        <div class="form__inner flex_1">
                            <label><span>*</span> Enter your request details</label>
                            <textarea name="request_detail" required class="input"></textarea>
                        </div>
                        <p class="mandotry_txt"><span class="mandotry_mark">* </span> <span>Mandatory fields</span></p>
                        <p class="agreement_disclaimer">
                            <label for="term_accept" class="checkbox">
                                <input type="checkbox" name="term_accept" id="term_accept" required/>
                                <span class="checkbox_inner"></span>
                            </label>
                            By submitting this form, I agree that (i) I am a resident of the United States of America and (ii) the information provided in this form is true and accurate.
                        </p>

                        <div class="form__inner">
                            <input type="submit" class="submit" value="Submit" />
                        </div>
                    </form>
                </div>
                <p class="footer-disclaimer">
                    Please note that we may request for additional information to verify your identity. Any information shared by you as a part of your request will only be used to verify your identity.
                </p>
            </div>
        </main>
    </body>
</html>