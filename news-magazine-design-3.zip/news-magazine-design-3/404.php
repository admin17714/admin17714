﻿<?php include(dirname(__FILE__).'/includes/config.php'); ?>
<!DOCTYPE html>
<html lang="en-US">

	<head>
		<?php include('partials/header.php'); ?>
		<title>404 Not Found - <?= $website_name; ?></title>
	</head>

    <body>
        <?php include('partials/nav.php'); ?>

        <!-- start of 404 -->
        <section class="section">
            <div class="container">
                <div class="row">
                    <div class="col-xl-9 col-lg-10 mx-auto text-center">
                        <h1 class="page-not-found-title">4<span class="bg-dark text-white px-2">0</span>4</h1>
                        <p class="mb-4">Oops. The page you're looking for doesn't exist.</p>
                        <a href="/" class="btn btn-dark">Back to home</a>
                    </div>
                </div>
            </div>
        </section>
        <!-- end of 404 -->

        <!-- start newsletter -->
        <section class="line-bg bg-white">
            <div class="newsletter-block border-bottom">
                <div class="container">
                    <div class="row gy-5 align-items-center justify-content-center text-center text-md-start">
                        <div class="col-xl-5 col-lg-5 col-md-6 col-sm-10">
                            <div class="pe-0 pe-xl-4">
                                <h2 class="mb-3 lh-sm">Subscribe to our monthly newsletter</h2>
                                <p class="mb-0">Stay up-to-date about latest tech and new world. Unsubscribe at anytime!</p>
                            </div>
                        </div>
                        <div class="col-xl-4 col-lg-5 col-md-6">
                            <div class="ps-0 ps-xl-4">
                                <div id="mc_embed_signup">
                                    <form action="<?= $domain; ?>/legal/submit.php" method="post" id="mc-embedded-subscribe-form" name="mc-embedded-subscribe-form">
                                        <div id="mc_embed_signup_scroll" class="input-group">
                                            <input type="text" value="" name="NAME" class="form-control w-100" id="mce-NAME"
                                                placeholder="Full Name" aria-label="Name" autocomplete="new-name">
                                            <input type="email" value="" name="EMAIL"
                                                class="form-control w-100 required email" id="mce-EMAIL"
                                                placeholder="Your email address *" aria-label="Subscription"
                                                autocomplete="new-email" required>
                                            <div id="mce-responses" class="clear">
                                                <div class="response" id="mce-error-response" style="display:none"></div>
                                                <div class="response" id="mce-success-response" style="display:none"></div>
                                            </div>
                                            <div style="position: absolute; left: -5000px;" aria-hidden="true">
                                                <input type="text" name="b_92641572a6c6ec43da15feed0_d28bb2454f"
                                                    tabindex="-1" value="">
                                            </div>
                                            <div class="input-group-append w-100">
                                                <button type="submit" name="subscribe" id="mc-embedded-subscribe"
                                                    class="input-group-text w-100 mb-0" aria-label="Subscription Button">
                                                    Subscribe Now <i class="ti ti-arrow-up-right ms-auto"></i>
                                                </button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- end newsletter -->

        <?php include('partials/footer.php'); ?>
    </body>

</html>