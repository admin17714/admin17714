<?php
include(dirname(__FILE__).'/../includes/config.php');

# Validate Post URL
if(!isset($_GET['post']) || empty($_GET['post'])) { exit('direct_access'); }
$post_slug = $_GET['post'];

# Get Post Data
$postObj = getPost($pdoObj, 'post_slug', $post_slug);
if(!$postObj) {
    http_response_code(404);
    include('../404.php');
    die();
}

# Close Database Connection
$pdoObj=null;

# NOIP Campaign Only
define('APPLOC',  dirname(__FILE__).DIRECTORY_SEPARATOR.'..'.DIRECTORY_SEPARATOR.'client'.DIRECTORY_SEPARATOR.'api'.DIRECTORY_SEPARATOR);
if(file_exists(APPLOC) && $postObj['noip_campaign'] != 'NA') {

    if($postObj['age_verification_url'] != 'NA') {
        if(isset($_GET['verified'])) {
            $_GET['clid'] = $postObj['noip_campaign'];
            include(APPLOC.'go.php');
            if($isItSafe) { noIpFraud(); }
        }
    }
    else {
        $_GET['clid'] = $postObj['noip_campaign'];
        include(APPLOC.'go.php');
        if($isItSafe) { noIpFraud(); }
    }
}
?>
<!DOCTYPE html>
<html lang="en-US">

    <head>
        <?php include('../partials/header.php'); ?>
        <title><?= $website_name; ?></title>
    </head>

    <body>

        <?php include('../partials/nav.php'); ?>

        <section class="bg-body">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-xl-9 col-lg-10">
                        <div class="section">
                            <p class="mb-4 text-muted">03 min reading</p>
                            <h1 class="mb-3"><?= $postObj['post_title']; ?></h1>
                            <p class="mb-4 pb-1"><?= $postObj['post_summary']; ?></p>
                            <div class="post-author d-flex">
                                <div class="flex-shrink-0">
                                    <a class='is-hoverable' href='#'
                                        title='Read all posts of - <?= $author_name; ?>'>
                                        <img loading="lazy" class="rounded-circle w-auto" src="<?= $domain; ?>/assets/frontend/avatar.jpg" alt="<?= $author_name; ?>" width="50" height="50">
                                    </a>
                                </div>
                                <div class="flex-grow-1 ms-3"> by <a class='text-link' href='#'
                                        title='Read all posts by - <?= $author_name; ?>'><?= $author_name; ?></a>
                                    <p class="mb-0 lh-base">Published at <?= $postObj['post_date']; ?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-12">
                        <img loading="lazy" class="w-100 h-auto" src="<?= $postObj['post_image']; ?>" alt="featured_image" width="1020" height="660">
                    </div>
                    <div class="col-xl-9 col-lg-10">
                        <div class="section">
                            <div class="content">
                                <?= base64_decode($postObj['post_content']); ?>
                            </div>
                            <div class="d-block d-sm-flex justify-content-between align-items-center mt-5 pt-3">
                                <ul class="list-inline social-share text-start text-sm-end mt-4 mt-sm-0">
                                    <li class="list-inline-item d-block mb-2 text-start">Share: </li>
                                    <li class="list-inline-item lead text-center is-hoverable">
                                        <i class="ti ti-brand-twitter"></i>
                                    </li>
                                    <li class="list-inline-item lead text-center is-hoverable ms-3">
                                        <i class="ti ti-brand-facebook"></i>
                                    </li>
                                    <li class="list-inline-item lead text-center is-hoverable ms-3">
                                        <i class="ti ti-brand-linkedin"></i>
                                    </li>
                                    <li class="list-inline-item lead text-center is-hoverable ms-3">
                                        <i class="ti ti-brand-reddit"></i>
                                    </li>
                                    <li class="list-inline-item lead text-center is-hoverable ms-3">
                                        <i class="ti ti-brand-pinterest"></i>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- start newsletter -->
        <section class="line-bg bg-white">
            <div class="newsletter-block border-bottom">
                <div class="container">
                    <div class="row gy-5 align-items-center justify-content-center text-center text-md-start">
                        <div class="col-xl-5 col-lg-5 col-md-6 col-sm-10">
                            <div class="pe-0 pe-xl-4">
                                <h2 class="mb-3 lh-sm">Subscribe to our monthly newsletter</h2>
                                <p class="mb-0">Stay up-to-date about latest tech and new world. Unsubscribe at anytime!</p>
                            </div>
                        </div>
                        <div class="col-xl-4 col-lg-5 col-md-6">
                            <div class="ps-0 ps-xl-4">
                                <div id="mc_embed_signup">
                                    <form action="<?= $domain; ?>/legal/submit.php" method="post" id="mc-embedded-subscribe-form" name="mc-embedded-subscribe-form">
                                        <div id="mc_embed_signup_scroll" class="input-group">
                                            <input type="text" value="" name="NAME" class="form-control w-100" id="mce-NAME"
                                                placeholder="Full Name" aria-label="Name" autocomplete="new-name">
                                            <input type="email" value="" name="EMAIL"
                                                class="form-control w-100 required email" id="mce-EMAIL"
                                                placeholder="Your email address *" aria-label="Subscription"
                                                autocomplete="new-email" required>
                                            <div id="mce-responses" class="clear">
                                                <div class="response" id="mce-error-response" style="display:none"></div>
                                                <div class="response" id="mce-success-response" style="display:none"></div>
                                            </div>
                                            <div style="position: absolute; left: -5000px;" aria-hidden="true">
                                                <input type="text" name="b_92641572a6c6ec43da15feed0_d28bb2454f"
                                                    tabindex="-1" value="">
                                            </div>
                                            <div class="input-group-append w-100">
                                                <button type="submit" name="subscribe" id="mc-embedded-subscribe"
                                                    class="input-group-text w-100 mb-0" aria-label="Subscription Button">
                                                    Subscribe Now <i class="ti ti-arrow-up-right ms-auto"></i>
                                                </button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- end newsletter -->

        <?php include('../partials/footer.php'); ?>
        <?php if($postObj['age_verification_url'] != 'NA') { include('../partials/age_popup.php'); } ?>
    </body>
</html>
