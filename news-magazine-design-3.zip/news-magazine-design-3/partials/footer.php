<!-- start footer -->
<footer class="bg-white">
	<div class="container">
		<div class="row gy-3">
			<div class="col-lg-8 text-center text-lg-start">
				<ul class="list-inline footer-menu">
					<li class="list-inline-item m-0">
						<a class="text-link" href="<?= $domain; ?>/about-us">About us </a>
					</li>
					<li class="list-inline-item m-0">
						<a class="text-link" href="<?= $domain; ?>/legal/contact-us">Contact us</a>
					</li>
					<li class="list-inline-item m-0">
						<a class='text-link' href='<?= $domain; ?>/legal/privacy-policy'>Privacy</a>
					</li>
					<li class="list-inline-item m-0">
						<a class='text-link' href='<?= $domain; ?>/legal/terms-service'>Terms</a>
					</li>
					<li class="list-inline-item m-0">
						<a class='text-link' href='<?= $domain; ?>/legal/cppa-form'>Data Privacy</a>
					</li>
				</ul>
			</div>
			<div class="col-lg-4 text-center">
				<p class="copyright-text mb-0">&copy; 2025 <?= $website_name; ?>. All rights reserved.</p>
			</div>
		</div>
	</div>
</footer>

<!-- scroll-to-top -->
<button class="scroll-to-top">
	<i class="ti ti-arrow-up"></i>
</button>
<!-- end footer -->

<!-- JS Plugins -->
<script src="<?= $domain; ?>/assets/frontend/plugins/bootstrap/bootstrap.min.js"></script>
<script src="<?= $domain; ?>/assets/frontend/plugins/lightense/lightense.min.js"></script>

<!-- Main Script -->
<script src="<?= $domain; ?>/assets/frontend/js/script.js"></script>

<?php if($site_code_footer != 'NA') { echo $site_code_footer; } ?>