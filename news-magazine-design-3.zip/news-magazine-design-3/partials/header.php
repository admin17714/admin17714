<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=5">

<meta name="author" content="<?= $website_name; ?>">
<meta name="description" content="<?= $homepage_title; ?>">
<meta name="robots" content="noindex,nofollow" />
<meta name="referrer" content="no-referrer"/>

<link rel="shortcut icon" href="<?= $domain; ?>/assets/frontend/favicon.ico" type="image/x-icon">

<!-- CSS Plugins and Fonts -->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=DM&#43;Sans:wght@400;500&amp;display=swap">
<link rel="stylesheet" href="<?= $domain; ?>/assets/frontend/plugins/tabler-icons/tabler-icons.min.css">

<!-- Main Stylesheet -->
<link rel="stylesheet" href="<?= $domain; ?>/assets/frontend/css/bootstrap.min.css">
<link rel="stylesheet" href="<?= $domain; ?>/assets/frontend/css/style.css">


<?php
$site_code_header = base64_decode($configObj['site_code_header']);
$site_code_footer = base64_decode($configObj['site_code_footer']);

$matamo_domain = $configObj['matamo_domain'];
$matamo_site_id = $configObj['matamo_site_id'];

if($site_code_header != 'NA') { echo $site_code_header; }

if($matamo_domain != 'NA' && $matamo_site_id != 'NA') { ?>
<!-- Matomo -->
<script>
  var _paq = window._paq = window._paq || [];
  /* tracker methods like "setCustomDimension" should be called before "trackPageView" */
  _paq.push(['trackPageView']);
  _paq.push(['enableLinkTracking']);
  (function() {
    var u="//<?= $matamo_domain; ?>/";
    _paq.push(['setTrackerUrl', u+'matomo.php']);
    _paq.push(['setSiteId', '<?= $matamo_site_id; ?>']);
    var d=document, g=d.createElement('script'), s=d.getElementsByTagName('script')[0];
    g.async=true; g.src=u+'matomo.js'; s.parentNode.insertBefore(g,s);
  })();
</script>
<!-- End Matomo Code -->
<?php } ?>