<div class="header-height-fix"></div>
<!-- start header-nav -->
<header class="header-nav">
	<div class="container">
		<div class="row">
			<div class="col-12">
				<nav class="navbar navbar-expand-lg navbar-light p-0">
					<button class="navbar-toggler d-inline-flex d-lg-none" type="button" data-bs-toggle="collapse" data-bs-target="#navHeader" aria-controls="navHeader" aria-expanded="false" aria-label="Toggle navigation">
						<svg xmlns="http://www.w3.org/2000/svg" class="menu-open" width="32" height="32" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
							<path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
							<line x1="4" y1="6" x2="20" y2="6"></line>
							<line x1="4" y1="12" x2="14" y2="12"></line>
							<line x1="4" y1="18" x2="18" y2="18"></line>
						</svg>
						<svg xmlns="http://www.w3.org/2000/svg" class="menu-close" width="32" height="32" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
							<path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
							<line x1="18" y1="6" x2="6" y2="18"></line>
							<line x1="6" y1="6" x2="18" y2="18"></line>
						</svg>
					</button>
					<a class='navbar-brand d-flex mb-0 me-0' href='<?= $domain; ?>' title='<?= $website_name; ?>'>
						<img loading="lazy" class="img-fluid" width="50" height="31" src="<?= $domain; ?>/assets/frontend/logo.png" alt="logo">
					</a>
					<div class="collapse navbar-collapse" id="navHeader">
						<ul class="navbar-nav ms-auto">
							<li class="nav-item ">
								<a class='nav-link' href='<?= $domain; ?>'>Home</a>
							</li>
							<li class="nav-item ">
								<a class='nav-link' href='<?= $domain; ?>/archive?category=celebrities'>Celebrities</a>
							</li>
							<li class="nav-item ">
								<a class='nav-link' href='<?= $domain; ?>/archive?category=travel'>Travel</a>
							</li>
							<li class="nav-item ">
								<a class='nav-link' href='<?= $domain; ?>/archive?category=lifestyle'>Lifestyle</a>
							</li>
							<li class="nav-item ">
								<a class='nav-link' href='<?= $domain; ?>/archive?category=fitness'>Fitness</a>
							</li>
							<li class="nav-item ">
								<a class='nav-link' href='<?= $domain; ?>/archive?category=business'>Business</a>
							</li>
						</ul>
					</div>
				</nav>
			</div>
		</div>
	</div>
</header>
<!-- end header-nav -->