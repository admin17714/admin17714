<?php
include(dirname(__FILE__).'/../includes/config.php');

# Validate Archive Name
if(!isset($_GET['category']) || empty($_GET['category'])) { aexit('direct_access'); }
$post_category = ucfirst($_GET['category']);

# Get Post Data
$postObjs = getPosts($pdoObj, 'post_category', $post_category);

# Close Database Connection
$pdoObj=null;
?>
<!DOCTYPE html>
<html lang="en-US">
    <head>
        <?php include('../partials/header.php'); ?>
        <title>News Archives for <?= $post_category; ?> - <?= $website_name; ?></title>
    </head>
    <body>
        <?php include('../partials/nav.php'); ?>

        <!-- start blog archive -->
        <section class="section">
            <div class="container">
                <div class="row g-0 justify-content-center">
                    <div class="col-xl-9 col-lg-10">
                        <div class="row gy-2 align-items-center section-title mb-0 section pt-0">
                            <div class="col-12">
                                <h1 class="h3 mb-0 title">Showing posts from <?= $post_category; ?></h1>
                            </div>
                            <div class="col-12">
                                <ul class="list-inline breadcrumb-menu">
                                    <li class="list-inline-item">
                                        <a class="text-link" href="/">Home</a>
                                    </li>
                                    <li class="list-inline-item">• &nbsp; <a class='text-link' href='#'>Categories</a>
                                    </li>
                                    <li class="list-inline-item">• &nbsp; <a class='text-link' href='#'><?= $post_category; ?></a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row justify-content-center">
                    <div class="col-xl-9 col-lg-10">
                        <div class="archive-block">
                            <?php if($postObjs && count($postObjs) > 0) : ?>
                            <ul class="list-unstyled">
                                <?php foreach($postObjs as $loop_postObj) : ?>
                                <li class="archive-post-item">
                                    <a class='border px-4 py-3 d-block' href='<?= $domain; ?>/single?post=<?= $loop_postObj['post_slug']; ?>'>
                                    <?= $loop_postObj['post_title']; ?></a>
                                </li>
                                <?php endforeach ?>
                            </ul>
                            <?php else : ?>
                                <h2 class="h3 mb-3">NO POSTS FOUND</h2>
                            <?php endif ?>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- end blog archive -->


        <!-- start newsletter -->
        <section class="line-bg bg-white">
            <div class="newsletter-block border-bottom">
                <div class="container">
                    <div class="row gy-5 align-items-center justify-content-center text-center text-md-start">
                        <div class="col-xl-5 col-lg-5 col-md-6 col-sm-10">
                            <div class="pe-0 pe-xl-4">
                                <h2 class="mb-3 lh-sm">Subscribe to our monthly newsletter</h2>
                                <p class="mb-0">Stay up-to-date about latest tech and new world. Unsubscribe at anytime!</p>
                            </div>
                        </div>
                        <div class="col-xl-4 col-lg-5 col-md-6">
                            <div class="ps-0 ps-xl-4">
                                <div id="mc_embed_signup">
                                    <form action="<?= $domain; ?>/legal/submit.php" method="post" id="mc-embedded-subscribe-form" name="mc-embedded-subscribe-form">
                                        <div id="mc_embed_signup_scroll" class="input-group">
                                            <input type="text" value="" name="NAME" class="form-control w-100" id="mce-NAME"
                                                placeholder="Full Name" aria-label="Name" autocomplete="new-name">
                                            <input type="email" value="" name="EMAIL"
                                                class="form-control w-100 required email" id="mce-EMAIL"
                                                placeholder="Your email address *" aria-label="Subscription"
                                                autocomplete="new-email" required>
                                            <div id="mce-responses" class="clear">
                                                <div class="response" id="mce-error-response" style="display:none"></div>
                                                <div class="response" id="mce-success-response" style="display:none"></div>
                                            </div>
                                            <div style="position: absolute; left: -5000px;" aria-hidden="true">
                                                <input type="text" name="b_92641572a6c6ec43da15feed0_d28bb2454f"
                                                    tabindex="-1" value="">
                                            </div>
                                            <div class="input-group-append w-100">
                                                <button type="submit" name="subscribe" id="mc-embedded-subscribe"
                                                    class="input-group-text w-100 mb-0" aria-label="Subscription Button">
                                                    Subscribe Now <i class="ti ti-arrow-up-right ms-auto"></i>
                                                </button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- end newsletter -->

        <?php include('../partials/footer.php'); ?>
	</body>

</html>