<?php include(dirname(__FILE__).'/../includes/config.php'); ?>
<!DOCTYPE html>
<html lang="en-US">
    <head>
        <?php include('../partials/header.php'); ?>
        <title>Know About us - <?= $website_name; ?></title>
    </head>
    <body>
        <?php include('../partials/nav.php'); ?>

        <!-- start of about intro -->
        <section class="section">
            <div class="container">
            <div class="row g-0 justify-content-center">
                <div class="col-xl-9 col-lg-10">
                <div class="row gy-2 align-items-center section-title mb-0 section pt-0">
                    <div class="col-12">
                    <h1 class="h3 mb-0 title">About Us</h1>
                    </div>
                    <div class="col-12">
                    <ul class="list-inline breadcrumb-menu">
                        <li class="list-inline-item">
                        <a class="text-link" href="/">Home</a>
                        </li>
                        <li class="list-inline-item">• &nbsp; <a class='text-link' href='<?= $domain; ?>/about-us'>About Us</a>
                        </li>
                    </ul>
                    </div>
                </div>
                </div>
            </div>
            <div class="row justify-content-center">
                <div class="col-xl-9 col-lg-10">
                    <img class="img-fluid mb-5" loading="lazy" src="<?= $domain; ?>/assets/frontend/images/about-image.jpg" alt="about">
                    <div class="content">
                        <h3 id="tushi-is-a-media-network-that-builds-and-operates"><?= $website_name; ?> is a media network that builds and
                        operates.</h3>
                        <p>We do this with the aim of creating the future of media. The future of media is one that is disruptive,
                        agile, and credible. It embraces diversity, creates a positive impact, and leaves its audience in a better
                        place than where they were before. We advocate for a media that embraces this and we embody.
                    </div>
                </div>
            </div>
            </div>
        </section>
        <!-- end of about intro -->

        <!-- start of our-story -->
        <section class="section bg-white">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-xl-9 col-lg-10">
                    <div class="section-title">
                        <h2 class="h3 mb-0 title">Our Story</h2>
                    </div>
                    <div class="row gx-lg-5 gy-4">
                        <div class="col-md-6">
                            <div class="content">
                                <p>The truth is important to us, so our work must always be trustworthy and demonstrate integrity. We
                                push ourselves to move fast and not be afraid to change things up.</p>
                                <p>We actively encourage fresh ideas and creative ways of doing things better.</p>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="content">Our work must positively impact the lives. We come from different backgrounds and are
                                varied in our thoughts and beliefs. We respect diversity and our work reflects that.</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- end of our-story -->

        <!-- start of authors -->
        <div class="section">
            <div class="container">
            <div class="row justify-content-center">
                <div class="col-xl-9 col-lg-10">
                <div class="section-title">
                    <h2 class="h3 mb-0 title">Our Authors</h2>
                </div>
                <div id="author-list" class="row gy-5 gx-md-5">
                    <div class="col-md-6">
                    <a class='bg-white text-dark p-3 d-flex is-hoverable' href='#'>
                        <div class="flex-shrink-0 me-3">
                        <img loading="lazy" class="shadow img-fluid" src="<?= $domain; ?>/assets/frontend/images/author/ann-monika.jpg"
                            alt="Ann Monika" width="90" height="90">
                        </div>
                        <div class="flex-grow-1">
                        <div class="d-flex flex-column h-100">
                            <div>
                            <h3 class="h4 text-dark mb-1 line-clamp clamp-1">Ann Monika</h3>
                            <p class="mb-2 lh-1 line-clamp clamp-1">Director of Operations</p>
                            </div>
                            <p class="fw-medium mt-auto mb-0 small">
                            <i class="ti ti-edit-circle me-2"></i>
                            <span class="text-black">03</span> Published posts
                            </p>
                        </div>
                        </div>
                    </a>
                    </div>
                    <div class="col-md-6">
                    <a class='bg-white text-dark p-3 d-flex is-hoverable' href='#'>
                        <div class="flex-shrink-0 me-3">
                        <img loading="lazy" class="shadow img-fluid" src="<?= $domain; ?>/assets/frontend/images/author/alexander-hipp.jpg"
                            alt="Alexander Hipp" width="90" height="90">
                        </div>
                        <div class="flex-grow-1">
                        <div class="d-flex flex-column h-100">
                            <div>
                            <h3 class="h4 text-dark mb-1 line-clamp clamp-1">Alexander Hipp</h3>
                            <p class="mb-2 lh-1 line-clamp clamp-1">Director and Chief Evangelist</p>
                            </div>
                            <p class="fw-medium mt-auto mb-0 small">
                            <i class="ti ti-edit-circle me-2"></i>
                            <span class="text-black">02</span> Published posts
                            </p>
                        </div>
                        </div>
                    </a>
                    </div>
                    <div class="col-md-6">
                    <a class='bg-white text-dark p-3 d-flex is-hoverable' href='#'>
                        <div class="flex-shrink-0 me-3">
                        <img loading="lazy" class="shadow img-fluid" src="<?= $domain; ?>/assets/frontend/images/author/anil-vugels.jpg"
                            alt="Anil Vugels" width="90" height="90">
                        </div>
                        <div class="flex-grow-1">
                        <div class="d-flex flex-column h-100">
                            <div>
                            <h3 class="h4 text-dark mb-1 line-clamp clamp-1">Anil Vugels</h3>
                            <p class="mb-2 lh-1 line-clamp clamp-1">Managing Partner</p>
                            </div>
                            <p class="fw-medium mt-auto mb-0 small">
                            <i class="ti ti-edit-circle me-2"></i>
                            <span class="text-black">02</span> Published posts
                            </p>
                        </div>
                        </div>
                    </a>
                    </div>
                    <div class="col-md-6">
                    <a class='bg-white text-dark p-3 d-flex is-hoverable' href='#'>
                        <div class="flex-shrink-0 me-3">
                        <img loading="lazy" class="shadow img-fluid" src="<?= $domain; ?>/assets/frontend/images/author/robert-britt.jpg"
                            alt="Robert Britt" width="90" height="90">
                        </div>
                        <div class="flex-grow-1">
                        <div class="d-flex flex-column h-100">
                            <div>
                            <h3 class="h4 text-dark mb-1 line-clamp clamp-1">Robert Britt</h3>
                            <p class="mb-2 lh-1 line-clamp clamp-1">Content Specialist</p>
                            </div>
                            <p class="fw-medium mt-auto mb-0 small">
                            <i class="ti ti-edit-circle me-2"></i>
                            <span class="text-black">02</span> Published posts
                            </p>
                        </div>
                        </div>
                    </a>
                    </div>
                </div>
                </div>
            </div>
            </div>
        </div>
        <!-- end of authors -->


        <!-- start newsletter -->
        <section class="line-bg bg-white">
            <div class="newsletter-block border-bottom">
                <div class="container">
                    <div class="row gy-5 align-items-center justify-content-center text-center text-md-start">
                        <div class="col-xl-5 col-lg-5 col-md-6 col-sm-10">
                            <div class="pe-0 pe-xl-4">
                                <h2 class="mb-3 lh-sm">Subscribe to our monthly newsletter</h2>
                                <p class="mb-0">Stay up-to-date about latest tech and new world. Unsubscribe at anytime!</p>
                            </div>
                        </div>
                        <div class="col-xl-4 col-lg-5 col-md-6">
                            <div class="ps-0 ps-xl-4">
                                <div id="mc_embed_signup">
                                    <form action="<?= $domain; ?>/legal/submit.php" method="post" id="mc-embedded-subscribe-form" name="mc-embedded-subscribe-form">
                                        <div id="mc_embed_signup_scroll" class="input-group">
                                            <input type="text" value="" name="NAME" class="form-control w-100" id="mce-NAME"
                                                placeholder="Full Name" aria-label="Name" autocomplete="new-name">
                                            <input type="email" value="" name="EMAIL"
                                                class="form-control w-100 required email" id="mce-EMAIL"
                                                placeholder="Your email address *" aria-label="Subscription"
                                                autocomplete="new-email" required>
                                            <div id="mce-responses" class="clear">
                                                <div class="response" id="mce-error-response" style="display:none"></div>
                                                <div class="response" id="mce-success-response" style="display:none"></div>
                                            </div>
                                            <div style="position: absolute; left: -5000px;" aria-hidden="true">
                                                <input type="text" name="b_92641572a6c6ec43da15feed0_d28bb2454f"
                                                    tabindex="-1" value="">
                                            </div>
                                            <div class="input-group-append w-100">
                                                <button type="submit" name="subscribe" id="mc-embedded-subscribe"
                                                    class="input-group-text w-100 mb-0" aria-label="Subscription Button">
                                                    Subscribe Now <i class="ti ti-arrow-up-right ms-auto"></i>
                                                </button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- end newsletter -->

        <?php include('../partials/footer.php'); ?>
    </body>

</html>