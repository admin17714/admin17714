<?php
# $pdoObj = connectDb();
# createTables($pdoObj);

/*
$pdoObj = connectDb();
$dataPayload = [
    'website_name' => 'Scalify',
    'author_name' => 'Louis Ferguson',
    'homepage_title' => 'Breaking News & In-Depth Analysis - Your Trusted Source for Current Events',
    'matamo_domain' => 'NA',
    'matamo_site_id' => 'NA'
];
createConfigTable($pdoObj, $dataPayload);
*/


function connectDb() {
    try {
        $db_path = dirname(__FILE__).DIRECTORY_SEPARATOR.'posts.db';
        $pdoObj = new \PDO("sqlite:".$db_path);
        $pdoObj->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        # echo "Opened database successfully\n";
        return $pdoObj;
    }
    catch (\PDOException $ex) {
        # var_dump($ex->getMessage());
        return false;
    }
}

function createPostTable($pdoObj) {
    try {
        $postsTable = 'CREATE TABLE IF NOT EXISTS tbl_posts (
            post_id             INTEGER PRIMARY KEY,
            post_date           TEXT NOT NULL,
            post_title          TEXT NOT NULL,
            post_slug           TEXT NOT NULL,
            post_summary        TEXT NOT NULL,
            post_image          TEXT NOT NULL,
            post_category       TEXT NOT NULL,
            noip_campaign       TEXT NOT NULL,
            age_verification_url  TEXT NOT NULL,
            post_content        TEXT NOT NULL
        );';
        $pdoObj->query($postsTable);
        echo "Table created successfully\n";
    }
    catch (\PDOException $ex) {
        var_dump($ex->getMessage());
    }
}
function createConfigTable($pdoObj, $data) {
    try {
        $postsTable = 'CREATE TABLE IF NOT EXISTS tbl_config (
            config_id       INTEGER PRIMARY KEY,
            website_name    TEXT NOT NULL,
            author_name     TEXT NOT NULL,
            homepage_title  TEXT NOT NULL,
            matamo_domain   TEXT NOT NULL,
            matamo_site_id  TEXT NOT NULL
        );';
        $pdoObj->query($postsTable);
        echo "Table created successfully\n";

        $stmt = $pdoObj->prepare("INSERT INTO tbl_config (website_name, author_name, homepage_title, matamo_domain, matamo_site_id) VALUES(?,?,?,?,?)");
        $pdoObj->beginTransaction();
        $stmt->execute([$data['website_name'], $data['author_name'], $data['homepage_title'], $data['matamo_domain'], $data['matamo_site_id']]);
        $pdoObj->commit();

        echo "Data inserted successfully\n";
    }
    catch (\PDOException $ex) {
        var_dump($ex->getMessage());
    }
}

function insertPost($pdoObj, $data) {

    try {
        $stmt = $pdoObj->prepare("INSERT INTO tbl_posts (post_date, post_title, post_slug, post_summary, post_image, post_category, noip_campaign, age_verification_url, post_content) VALUES(?,?,?,?,?,?,?,?,?)");
        $pdoObj->beginTransaction();
        $stmt->execute([$data['post_date'], $data['post_title'], $data['post_slug'], $data['post_summary'], $data['post_image'], $data['post_category'], $data['noip_campaign'], $data['age_verification_url'], base64_encode($data['post_content'])]);
        $pdoObj->commit();

        return $pdoObj->lastInsertId();
    }
    catch(\PDOExecption $ex) {

        $pdoObj->rollback();
        # var_dump($ex->getMessage());
        return false;
    }
}
function updatePost($pdoObj, $data, $post_id) {

    try {
        $stmt = $pdoObj->prepare("UPDATE tbl_posts SET post_date=?, post_title=?, post_slug=?, post_summary=?, post_image=?, post_category=?, noip_campaign=?, age_verification_url=?, post_content=? WHERE post_id=?");
        $pdoObj->beginTransaction();
        $stmt->execute([$data['post_date'], $data['post_title'], $data['post_slug'], $data['post_summary'], $data['post_image'], $data['post_category'], $data['noip_campaign'], $data['age_verification_url'], base64_encode($data['post_content']), $post_id]);
        $pdoObj->commit();

        return true;
    }
    catch(\PDOExecption $ex) {

        $pdoObj->rollback();
        # var_dump($ex->getMessage());
        return false;
    }
}
function deletePost($pdoObj, $post_id) {

    try {
        $stmt = $pdoObj->prepare("DELETE FROM tbl_posts where post_id=?");
        $pdoObj->beginTransaction();
        $stmt->execute([$post_id]);
        $pdoObj->commit();

        return true;
    }
    catch(\PDOExecption $ex) {

        $pdoObj->rollback();
        # var_dump($ex->getMessage());
        return false;
    }
}
function getPost($pdoObj, $post_col, $post_val) {

    try {
        $stmt = $pdoObj->prepare("SELECT * FROM tbl_posts WHERE ".$post_col."=?");
        $stmt->execute([$post_val]);
        $postObj = $stmt->fetch();
        return $postObj;
    }
    catch(\PDOExecption $ex) {

        #var_dump($ex->getMessage());
        return false;
    }
}
function getPosts($pdoObj, $post_col, $post_val) {

    try {
        $stmt = $pdoObj->prepare("SELECT * FROM tbl_posts WHERE ".$post_col."=?");
        $stmt->execute([$post_val]);
        $postObj = $stmt->fetchAll(\PDO::FETCH_ASSOC);
        return $postObj;
    }
    catch(\PDOExecption $ex) {

        #var_dump($ex->getMessage());
        return false;
    }
}
function recentPosts($pdoObj, $limit=null) {

    try {
        if($limit) {
            $stmt = $pdoObj->prepare("SELECT post_id, post_slug, post_category, post_title, post_summary, post_image, post_date, noip_campaign, age_verification_url FROM tbl_posts ORDER BY post_id DESC LIMIT ?");
            $stmt->execute([$limit]);
        }
        else {
            $stmt = $pdoObj->prepare("SELECT post_id, post_slug, post_category, post_title, post_summary, post_image, post_date, noip_campaign, age_verification_url FROM tbl_posts ORDER BY post_id DESC");
            $stmt->execute();
        }
        $postObj = $stmt->fetchAll(\PDO::FETCH_ASSOC);
        return $postObj;
    }
    catch(\PDOExecption $ex) {

        #var_dump($ex->getMessage());
        return false;
    }
}
function getConfig($pdoObj) {

    try {
        $stmt = $pdoObj->prepare("SELECT * FROM tbl_config WHERE config_id=1");
        $stmt->execute();
        $configObj = $stmt->fetch();
        return $configObj;
    }
    catch(\PDOExecption $ex) {

        #var_dump($ex->getMessage());
        return false;
    }
}
function updateConfig($pdoObj, $data) {

    try {
        $stmt = $pdoObj->prepare("UPDATE tbl_config SET website_name=?, author_name=?, homepage_title=?, matamo_domain=?, matamo_site_id=? WHERE config_id=1");
        $pdoObj->beginTransaction();
        $stmt->execute([$data['website_name'], $data['author_name'], $data['homepage_title'], $data['matamo_domain'], $data['matamo_site_id']]);
        $pdoObj->commit();

        return true;
    }
    catch(\PDOExecption $ex) {

        $pdoObj->rollback();
        # var_dump($ex->getMessage());
        return false;
    }
}