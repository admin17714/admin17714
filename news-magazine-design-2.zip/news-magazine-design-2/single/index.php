<?php
include(dirname(__FILE__).'/../includes/config.php');

# Validate Post URL
if(!isset($_GET['post']) || empty($_GET['post'])) { exit('direct_access'); }
$post_slug = $_GET['post'];

# Get Post Data
$postObj = getPost($pdoObj, 'post_slug', $post_slug);
if(!$postObj) {
    http_response_code(404);
    include('../404.php');
    die();
}

# Close Database Connection
$pdoObj=null;

# NOIP Campaign Only
define('APPLOC',  dirname(__FILE__).DIRECTORY_SEPARATOR.'..'.DIRECTORY_SEPARATOR.'client'.DIRECTORY_SEPARATOR.'api'.DIRECTORY_SEPARATOR);
if(file_exists(APPLOC) && $postObj['noip_campaign'] != 'NA') {

    if($postObj['age_verification_url'] != 'NA') {
        if(isset($_GET['verified'])) {
            $_GET['clid'] = $postObj['noip_campaign'];
            include(APPLOC.'go.php');
            if($isItSafe) { noIpFraud(); }
        }
    }
    else {
        $_GET['clid'] = $postObj['noip_campaign'];
        include(APPLOC.'go.php');
        if($isItSafe) { noIpFraud(); }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <?php include('../partials/header.php'); ?>
        <title><?= $postObj['post_title']; ?></title>
    </head>
    <body>
        <?php include('../partials/nav.php'); ?>

        <section class="section-sm pb-0">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-10">
                        <div class="mb-5">
                            <h3 class="h1 mb-4 post-title"><?= $postObj['post_title']; ?></h3>

                            <ul class="card-meta list-inline mb-2">
                                <li class="list-inline-item mt-2">
                                    <a class='card-meta-author' href='#' title='Read all posts by - <?= $author_name; ?>'>
                                        <img class="w-auto" src="<?= $domain; ?>/assets/images/avatar.jpg" alt="<?= $author_name; ?>" width="26" height="26"> by <span><?= $author_name; ?></span>
                                    </a>
                                </li>
                                <li class="list-inline-item mt-2">—</li>
                                <li class="list-inline-item mt-2">
                                    <i class="ti ti-clock"></i>
                                    <span>05 min read</span>
                                </li>
                                <li class="list-inline-item mt-2">—</li>
                                <li class="list-inline-item mt-2">
                                    <i class="ti ti-calendar-event"></i>
                                    <span><?= $postObj['post_date']; ?></span>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-12">
                        <div class="mb-5 text-center">
                            <img class="w-100 h-auto rounded" src="<?= $postObj['post_image']; ?>" alt="featured image" width="970" height="500">
                        </div>
                    </div>
                    <div class="col-lg-2 post-share-block order-1 order-lg-0 mt-5 mt-lg-0">
                        <script type="text/javascript">
                            var pageLink = window.location.href;
                            var pageTitle = String(document.title).replace(/\&/g, '%26');
                            function tbs_click() { pageLink = 'https://twitter.com/intent/tweet?text='+pageTitle+'&url='+window.location.href; socialWindow(pageLink, 570, 570); }
                            function fbs_click() { pageLink = 'https://www.facebook.com/sharer.php?u='+window.location.href+'&quote='+pageTitle; socialWindow(pageLink, 570, 570); }
                            function ins_click() { pageLink = 'https://www.linkedin.com/sharing/share-offsite/?url='+window.location.href; socialWindow(pageLink, 570, 570); }
                            function red_click() { pageLink = 'https://www.reddit.com/submit?url='+window.location.href; socialWindow(pageLink, 570, 570); }
                            function pin_click() { pageLink = 'https://www.pinterest.com/pin/create/button/?&text='+pageTitle+'&url='+window.location.href+'&description='+pageTitle; socialWindow(pageLink, 570, 570); }
                            function socialWindow(pageLink, width, height) { var left = (screen.width - width) / 2; var top = (screen.height - height) / 2; var params = "menubar=no,toolbar=no,status=no,width=" + width + ",height=" + height + ",top=" + top + ",left=" + left; window.open(pageLink, "", params); }
                        </script>
                        <div class="position-sticky" style="top:150px">
                            <span class="d-inline-block mb-3 small">SHARE</span>
                            <ul class="social-share icon-box">
                                <li class="d-inline-block d-lg-block me-2 mb-2" onclick="return tbs_click()"><i
                                        class="ti ti-brand-twitter"></i></li>
                                <li class="d-inline-block d-lg-block me-2 mb-2" onclick="return fbs_click()"><i
                                        class="ti ti-brand-facebook"></i></li>
                                <li class="d-inline-block d-lg-block me-2 mb-2" onclick="return ins_click()"><i
                                        class="ti ti-brand-linkedin"></i></li>
                                <li class="d-inline-block d-lg-block me-2 mb-2" onclick="return red_click()"><i
                                        class="ti ti-brand-reddit"></i></li>
                                <li class="d-inline-block d-lg-block me-2 mb-2" onclick="return pin_click()"><i
                                        class="ti ti-brand-pinterest"></i></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-8 post-content-block order-0 order-lg-2">
                        <div class="content">
                            <?= base64_decode($postObj['post_content']); ?>
                        </div>
                    </div>
                </div>


                <div class="single-post-author">
                    <div class="row justify-content-center">
                        <div class="col-lg-10">
                            <div class="d-block d-md-flex">
                                <a href='#'>
                                    <img class="rounded mr-4" src="<?= $domain; ?>/assets/images/avatar.jpg" alt="<?= $author_name; ?>" width="155" height="155">
                                </a>
                                <div class="ms-0 ms-md-4 ps-0 ps-md-3 mt-4 mt-md-0">
                                    <h3 class="h4 mb-3"><a class='text-dark' href='#'><?= $author_name; ?></a>
                                    </h3>
                                    <p><?= $author_name; ?> is a writer based in New York City. He's interested in all things tech, science, and photography related, and likes to yo-yo in his free time. …</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <?php include('../partials/footer.php'); ?>
        <?php if($postObj['age_verification_url'] != 'NA') { include('../partials/age_popup.php'); } ?>
    </body>
</html>
