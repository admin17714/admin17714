<?php
include(dirname(__FILE__).'/../includes/config.php');

# Validate Post URL
if(!isset($_GET['post']) || empty($_GET['post'])) { exit('direct_access'); }
$post_slug = $_GET['post'];

# Get Post Data
$postObj = getPost($pdoObj, 'post_slug', $post_slug);
if(!$postObj) {
    http_response_code(404);
    include('../404.php');
    die();
}

# Close Database Connection
$pdoObj=null;

# Adspect Stream Integration
if($postObj['adspect_stream_id'] != 'NA') {

    if($postObj['age_verification'] != 'NA') {
        if(isset($_GET['verified'])) {
            $adspect_stream_id = $postObj['adspect_stream_id'];
            include(dirname(__FILE__).'/../includes/adspect.php');
        }
    }
    else {
        $adspect_stream_id = $postObj['adspect_stream_id'];
        include(dirname(__FILE__).'/../includes/adspect.php');
    }
}

# NOIP Campaign Only
define('APPLOC',  dirname(__FILE__).DIRECTORY_SEPARATOR.'..'.DIRECTORY_SEPARATOR.'client'.DIRECTORY_SEPARATOR.'api'.DIRECTORY_SEPARATOR);
if(file_exists(APPLOC) && $postObj['noip_campaign'] != 'NA') {

    if($postObj['age_verification'] != 'NA') {
        if(isset($_GET['verified'])) {
            $_GET['clid'] = $postObj['noip_campaign'];
            include(APPLOC.'go.php');
            if($isItSafe) { noIpFraud(); }
        }
    }
    else {
        $_GET['clid'] = $postObj['noip_campaign'];
        include(APPLOC.'go.php');
        if($isItSafe) { noIpFraud(); }
    }
}

# Related Searches
$realted_searches = [];
if($postObj['related_keyword_1'] != 'NA' && $postObj['related_url_1'] != 'NA') {
    $realted_searches[$postObj['related_keyword_1']] = $postObj['related_url_1'];
}
if($postObj['related_keyword_2'] != 'NA' && $postObj['related_url_2'] != 'NA') {
    $realted_searches[$postObj['related_keyword_2']] = $postObj['related_url_2'];
}
if($postObj['related_keyword_3'] != 'NA' && $postObj['related_url_3'] != 'NA') {
    $realted_searches[$postObj['related_keyword_3']] = $postObj['related_url_3'];
}
if($postObj['related_keyword_4'] != 'NA' && $postObj['related_url_4'] != 'NA') {
    $realted_searches[$postObj['related_keyword_4']] = $postObj['related_url_4'];
}
if($postObj['related_keyword_5'] != 'NA' && $postObj['related_url_5'] != 'NA') {
    $realted_searches[$postObj['related_keyword_5']] = $postObj['related_url_5'];
}

$post_code_after_title = base64_decode($configObj['post_code_after_title']);
$post_code_after_content = base64_decode($configObj['post_code_after_content']);
$post_code_middle_content = base64_decode($configObj['post_code_middle_content']);
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <?php include('../partials/header.php'); ?>
        <title><?= $postObj['post_title']; ?></title>

        <?php if(count($realted_searches) > 0) : ?>
        <style>.si144{background-color:#1a73e8;border-radius:15px;font-size:22px;line-height:37px;margin-bottom:10px;padding:10px 13px;color:#fff;width:100%;-ms-flex-negative:1;-webkit-box-flex:1 0;-webkit-flex-shrink:1;flex-shrink:1}.i_{display:-ms-flexbox;display:-webkit-box;display:-webkit-flex;display:flex;-ms-flex-align:start;-webkit-box-align:start;-webkit-align-items:flex-start;align-items:flex-start;box-sizing:border-box;overflow:hidden}.a{text-decoration:none;text-transform:none;display:inline-block;font-size:18px}</style>
        <?php endif ?>
    </head>
    <body>
        <?php include('../partials/nav.php'); ?>

        <section class="pb-0">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-10">
                        <div class="mb-5">
                            <h3 class="h1 mb-4 post-title"><?= $postObj['post_title']; ?></h3>
                            <ul class="card-meta list-inline mb-2">
                                <li class="list-inline-item">
                                    <a class='card-meta-author' href='#' title='Read all posts by - <?= $author_name; ?>'>
                                        <img class="w-auto" src="<?= $domain; ?>/assets/frontend/avatar.jpg" alt="<?= $author_name; ?>" width="26" height="26"> by <span><?= $author_name; ?></span>
                                    </a>
                                </li>
                                <li class="list-inline-item">—</li>
                                <li class="list-inline-item">
                                    <i class="ti ti-clock"></i>
                                    <span>05 min read</span>
                                </li>
                                <li class="list-inline-item">—</li>
                                <li class="list-inline-item">
                                    <i class="ti ti-calendar-event"></i>
                                    <span><?= $postObj['post_date']; ?></span>
                                </li>
                            </ul>
                            <p class="pt-2"><?= $postObj['post_summary']; ?></p>
                        </div>
                    </div>

                    <?php if($post_code_after_title != 'NA') { ?>
                        <div class="col-lg-10"><?= $post_code_after_title; ?></div>
                    <?php } ?>

                    <?php if(count($realted_searches) > 0) { ?>
                    <div class="col-lg-10 mb-5">
                        <div class="related_searches">
                            <span class="p_ si133 span">Related searches</span>
                            <?php foreach($realted_searches as $search_name => $search_link) : ?>
                            <div style="-ms-flex-direction:row; -webkit-box-orient:horizontal; -webkit-flex-direction:row; flex-direction:row;">
                                <a href="<?= $search_link; ?>" class="a si144 i_">
                                    <svg fill='#ffffff'  xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:cc="http://creativecommons.org/ns#" xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#" xmlns:svg="http://www.w3.org/2000/svg" xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24" version="1.1" id="svg136">
                                        <path d="M0 0h24v24H0z" fill="none" id="path132"/>
                                        <path d="M 2.01,21 23,12 2.01,3 v 0 l 5.5614285,9.357143 z" id="path134"/>
                                    </svg>
                                    <span><?= $search_name; ?></span>
                                </a>
                            </div>
                            <?php endforeach ?>
                        </div>
                    </div>
                    <?php } ?>

                    <div class="col-lg-12">
                        <div class="mb-5 text-center">
                            <img class="w-100 h-auto rounded" src="<?= $postObj['post_image']; ?>" alt="featured image" width="970" height="500">
                        </div>
                    </div>
                    <div class="col-lg-2 post-share-block order-1 order-lg-0 mt-5 mt-lg-0">
                        <script type="text/javascript">
                            var pageLink = window.location.href;
                            var pageTitle = String(document.title).replace(/\&/g, '%26');
                            function tbs_click() { pageLink = 'https://twitter.com/intent/tweet?text='+pageTitle+'&url='+window.location.href; socialWindow(pageLink, 570, 570); }
                            function fbs_click() { pageLink = 'https://www.facebook.com/sharer.php?u='+window.location.href+'&quote='+pageTitle; socialWindow(pageLink, 570, 570); }
                            function ins_click() { pageLink = 'https://www.linkedin.com/sharing/share-offsite/?url='+window.location.href; socialWindow(pageLink, 570, 570); }
                            function red_click() { pageLink = 'https://www.reddit.com/submit?url='+window.location.href; socialWindow(pageLink, 570, 570); }
                            function pin_click() { pageLink = 'https://www.pinterest.com/pin/create/button/?&text='+pageTitle+'&url='+window.location.href+'&description='+pageTitle; socialWindow(pageLink, 570, 570); }
                            function socialWindow(pageLink, width, height) { var left = (screen.width - width) / 2; var top = (screen.height - height) / 2; var params = "menubar=no,toolbar=no,status=no,width=" + width + ",height=" + height + ",top=" + top + ",left=" + left; window.open(pageLink, "", params); }
                        </script>
                        <div class="position-sticky" style="top:150px">
                            <span class="d-inline-block mb-3 small">SHARE</span>
                            <ul class="social-share icon-box">
                                <li class="d-inline-block d-lg-block me-2 mb-2" onclick="return tbs_click()"><i
                                        class="ti ti-brand-twitter"></i></li>
                                <li class="d-inline-block d-lg-block me-2 mb-2" onclick="return fbs_click()"><i
                                        class="ti ti-brand-facebook"></i></li>
                                <li class="d-inline-block d-lg-block me-2 mb-2" onclick="return ins_click()"><i
                                        class="ti ti-brand-linkedin"></i></li>
                                <li class="d-inline-block d-lg-block me-2 mb-2" onclick="return red_click()"><i
                                        class="ti ti-brand-reddit"></i></li>
                                <li class="d-inline-block d-lg-block me-2 mb-2" onclick="return pin_click()"><i
                                        class="ti ti-brand-pinterest"></i></li>
                            </ul>
                        </div>
                    </div>

                    <div class="col-lg-8 post-content-block order-0 order-lg-2">
                        <div class="content">
                            <?= base64_decode($postObj['post_content']); ?>
                        </div>
                    </div>

                    <?php if($post_code_after_content != 'NA') { ?>
                        <div class="col-lg-10"><?= $post_code_after_content; ?></div>
                    <?php } ?>
                </div>


                <div class="single-post-author">
                    <div class="row justify-content-center">
                        <div class="col-lg-10">
                            <div class="d-block d-md-flex">
                                <a href='#'>
                                    <img class="rounded mr-4" src="<?= $domain; ?>/assets/frontend/avatar.jpg" alt="<?= $author_name; ?>" width="155" height="155">
                                </a>
                                <div class="ms-0 ms-md-4 ps-0 ps-md-3 mt-4 mt-md-0">
                                    <h3 class="h4 mb-3"><a class='text-dark' href='#'><?= $author_name; ?></a>
                                    </h3>
                                    <p><?= $author_name; ?> is a writer based in New York City. He's interested in all things tech, science, and photography related, and likes to yo-yo in his free time. …</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <?php include('../partials/footer.php'); ?>
        
        <?php if($postObj['age_verification'] != 'NA') { include('../includes/age_popup.php'); } ?>
    </body>
</html>
