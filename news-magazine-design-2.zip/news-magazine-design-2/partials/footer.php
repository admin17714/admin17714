<!-- start of footer -->
<footer>
	<div class="container">
		<div class="section">
			<div class="row justify-content-center align-items-center">
				<div class="col-xl-6 col-lg-8 col-md-10">
					<!-- newsletter block -->
					<div class="newsletter-block">
						<h2 class="section-title text-center mb-4">Get latest posts delivered right to your inbox</h2>
						<form action="<?= $domain; ?>/legal/submit.php" method="post" novalidate>
						<div class="input-group flex-column flex-sm-row flex-nowrap flex-sm-nowrap">
							<input type="email" name="email" class="form-control required email w-auto text-center text-sm-start"
							placeholder="Your email address" aria-label="Subscription" required>
							<div class="input-group-append d-flex d-sm-inline-block mt-2 mt-sm-0 ms-0 w-auto">
							<button type="submit" name="subscribe" id="mc-embedded-subscribe"
								class="input-group-text w-100 justify-content-center" aria-label="Subscription Button"><i
								class="ti ti-user-plus me-2"></i> Join today</button>
							</div>
						</div>
						</form>
					</div>
				<!-- newsletter block -->
				</div>
			</div>
		</div>
		<div class="pb-5">
			<div class="row g-2 g-lg-4 align-items-center">
				<div class="col-lg-6 text-center text-lg-start">
				<p class="mb-0 copyright-text content">© 2025 The <?= $website_name; ?>. All rights reserved</p>
				</div>
				<div class="col-lg-6 text-center text-lg-end">
				<ul class="list-inline footer-menu">
					<li class="list-inline-item m-0"><a href='<?= $domain; ?>/about-us'>About us</a></li>
					<li class="list-inline-item m-0"><a href='<?= $domain; ?>/legal/contact-us'>Contact us</a></li>
					<li class="list-inline-item m-0"><a href='<?= $domain; ?>/legal/privacy-policy'>Privacy</a></li>
					<li class="list-inline-item m-0"><a href='<?= $domain; ?>/legal/terms-service'>Terms</a></li>
					<li class="list-inline-item m-0"><a href='<?= $domain; ?>/legal/cppa-form'>Data Privacy</a></li>
				</ul>
				</div>
			</div>
		</div>
	</div>
</footer>
<!-- end of footer -->

<!-- JS Plugins -->
<script src="<?= $domain; ?>/assets/frontend/plugins/bootstrap/bootstrap.min.js"></script>
<script src="<?= $domain; ?>/assets/frontend/plugins/lightense/lightense.min.js"></script>

<!-- Main Script -->
<script src="<?= $domain; ?>/assets/frontend/js/script.js"></script>