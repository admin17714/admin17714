<div class="header-height-fix"></div>
<header class="header-nav">
	<div class="container">
		<div class="row">
			<div class="col-12">
				<nav class="navbar navbar-expand-lg navbar-light p-0">
					<a class='navbar-brand font-weight-bold mb-0' href='<?= $domain; ?>' title='<?= $website_name; ?>'>
						<img class="img-fluid" width="55" height="55" src="<?= $domain; ?>/assets/images/news-logo.png" alt="<?= $website_name; ?>">
					</a>

					<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navHeader" aria-controls="navHeader" aria-expanded="false" aria-label="Toggle navigation">
						<i class="ti ti-menu-2 menu-open"></i>
						<i class="ti ti-x menu-close"></i>
					</button>

					<div class="collapse navbar-collapse" id="navHeader">
						<ul class="navbar-nav mx-auto">
							<li class="nav-item active">
								<a class='nav-link' href='<?= $domain; ?>'>Home</a>
							</li>
							<li class="nav-item @@celebrities">
								<a class='nav-link' href='<?= $domain; ?>/archive?category=celebrities'>Celebrities</a>
							</li>
							<li class="nav-item @@travel">
								<a class='nav-link' href='<?= $domain; ?>/archive?category=travel'>Travel</a>
							</li>
							<li class="nav-item @@lifestyle">
								<a class='nav-link' href='<?= $domain; ?>/archive?category=lifestyle'>Lifestyle</a>
							</li>
							<li class="nav-item @@fitness">
								<a class='nav-link' href='<?= $domain; ?>/archive?category=fitness'>Fitness</a>
							</li>
							<li class="nav-item @@business">
								<a class='nav-link' href='<?= $domain; ?>/archive?category=business'>Business</a>
							</li>
						</ul>
					</div>
				</nav>
			</div>
		</div>
	</div>
</header>