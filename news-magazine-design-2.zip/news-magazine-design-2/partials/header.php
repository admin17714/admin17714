<meta charset="utf-8">

<meta name="author" content="Breaking News">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=5">
<meta name="description" content="Breaking News & In-Depth Analysis - Your Trusted Source for Current Events">

<link rel="shortcut icon" href="<?= $domain; ?>/favicon.ico">

<!-- CSS Plugins -->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Crete+Round&family=Work+Sans:wght@500;600&display=swap" rel="stylesheet">

<link rel="stylesheet" href="<?= $domain; ?>/assets/plugins/bootstrap/bootstrap.min.css">
<link rel="stylesheet" href="<?= $domain; ?>/assets/plugins/tabler-icons/tabler-icons.min.css">

<!-- Main Stylesheet -->
<link rel="stylesheet" href="<?= $domain; ?>/assets/css/style.css">


<?php if(isset($postObj['age_verification_url']) && $postObj['age_verification_url'] != 'NA') { ?>
<!-- Taboola Pixel Code -->
<script type='text/javascript'>
  window._tfa = window._tfa || [];
  window._tfa.push({notify: 'event', name: 'page_view', id: 1698853});
  !function (t, f, a, x) {
         if (!document.getElementById(x)) {
            t.async = 1;t.src = a;t.id=x;f.parentNode.insertBefore(t, f);
         }
  }(document.createElement('script'),
  document.getElementsByTagName('script')[0],
  '//cdn.taboola.com/libtrc/unip/1698853/tfa.js',
  'tb_tfa_script');
</script>
<!-- End of Taboola Pixel Code -->
<?php } ?>


<?php if($matamo_domain != 'NA' && $matamo_site_id != 'NA') { ?>
<!-- Matomo -->
<script>
  var _paq = window._paq = window._paq || [];
  /* tracker methods like "setCustomDimension" should be called before "trackPageView" */
  _paq.push(['trackPageView']);
  _paq.push(['enableLinkTracking']);
  (function() {
    var u="//<?= $matamo_domain; ?>/";
    _paq.push(['setTrackerUrl', u+'matomo.php']);
    _paq.push(['setSiteId', '<?= $matamo_site_id; ?>']);
    var d=document, g=d.createElement('script'), s=d.getElementsByTagName('script')[0];
    g.async=true; g.src=u+'matomo.js'; s.parentNode.insertBefore(g,s);
  })();
</script>
<!-- End Matomo Code -->
<?php } ?>