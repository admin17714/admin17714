<?php include(dirname(__FILE__).'/../includes/config.php'); ?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <title>Thank you for your valuable time - <?= $website_name; ?> </title>
        <link rel="icon" href="<?= $domain; ?>/assets/frontend/favicon.ico" type="image/x-icon" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />

        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />

        <link href="https://fonts.googleapis.com/css2?family=Public+Sans:wght@400;500;700&display=swap" rel="stylesheet" />
        <link rel="stylesheet" type="text/css" href="<?= $domain; ?>/legal/css/form.min.css" />
    </head>
    <body class="chrome-wrap">
        <main class="main-wrapper flex justify-center">
            <div class="wrapper-inner">
                <?php if($_SERVER['REQUEST_METHOD'] == 'POST') { ?>
                <div class="formWrap">
                    <h1 class="formWrap__heading fw-700">Thank you for your valuable time!</h1>
                    <p class="formWrap__subHeading">We have received your submission and we are working on it. Our customer executive will be shortly in touch with you.</p>
                </div>
                <?php } else { ?>
                <div class="formWrap">
                    <h1 class="formWrap__heading fw-700">Direct access not allowed.</h1>
                    <p class="formWrap__subHeading">Please go through our website forms to submit feedback or queries..</p>
                </div>
                <?php } ?>
                <p class="footer-disclaimer">
                    Please note that we may request for additional information to verify your identity. Any information shared by you as a part of your request will only be used to verify your identity.
                </p>
            </div>
        </main>
    </body>
</html>