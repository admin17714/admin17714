<footer class="mb-3">
    <div class="container">
        <div class="card card-body bg-light">
            <div class="row align-items-center justify-content-between">
                <div class="col-lg-6">
                    <div class="text-center text-lg-start">© 2025 <?= $website_name; ?>. All rights reserved</div>
                </div>
            </div>
        </div>
    </div>
</footer>
<!-- Back to top -->
<div class="back-top">
    <i class="bi bi-arrow-up-short"></i>
</div>
<script src="<?= $domain; ?>/assets/backend/vendor/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?= $domain; ?>/assets/backend/vendor/quill/js/quill.min.js"></script>
<script src="<?= $domain; ?>/assets/backend/js/functions.js"></script>
