<header class="navbar-light navbar-sticky header-static border-bottom navbar-dashboard">
    <!-- Logo Nav START -->
    <nav class="navbar navbar-expand-xl">
        <div class="container">
            <!-- Logo START -->
            <a class="navbar-brand d-flex" href="<?= $domain; ?>">
				<img class="navbar-brand-item light-mode-item" src="<?= $domain; ?>/assets/images/news-logo.png" alt="logo"><span class="ms-2 text-secondary light-mode-item" style="font-weight: 500;"><?= $website_name; ?></span>
				<img class="navbar-brand-item dark-mode-item" src="<?= $domain; ?>/assets/images/news-logo.png" alt="logo"><span class="ms-2 text-white dark-mode-item" style="font-weight: 500;"><?= $website_name; ?></span>		
			</a>
            <!-- Logo END -->

            <!-- Responsive navbar toggler -->
            <button class="navbar-toggler ms-auto" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
                <span class="text-body h6 d-none d-sm-inline-block">Menu</span>
                <span class="navbar-toggler-icon"></span>
            </button>

            <!-- Main navbar START -->
            <div class="collapse navbar-collapse" id="navbarCollapse" style="justify-content:end">
                <ul class="navbar-nav navbar-nav-scroll">
                    <li class="nav-item"><a class="nav-link" href="<?= $domain; ?>/backend/post-list.php"><i class="bi bi-signpost-2 me-2"></i>All Posts</a></li>
                    <li class="nav-item"><a class="nav-link" href="<?= $domain; ?>/backend/post-add.php"><i class="bi bi-send-plus me-2"></i>Add Post</a></li>
                    <li class="nav-item"><a class="nav-link" href="<?= $domain; ?>/backend/config.php"><i class="bi bi-gear-wide-connected me-2"></i>Website Config</a></li>
                    <li class="nav-item"><a class="nav-link" href="<?= $domain; ?>/backend/logout.php"><i class="bi bi-shield-lock me-2"></i>Logout</a></li>
                </ul>
            </div>
            <!-- Main navbar END -->
        </div>
    </nav>
    <!-- Logo Nav END -->
</header>