﻿<?php include(dirname(__FILE__).'/includes/config.php'); ?>
<!DOCTYPE html>
<html lang="en-US">

	<head>
		<?php include('partials/header.php'); ?>
		<title>404 Not Found - <?= $website_name; ?></title>
	</head>

    <body>
        <?php include('partials/nav.php'); ?>

        <section class="section-sm pb-0">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="text-center">
                            <h1 class="page-not-found-title">404</h1>
                            <p class="mb-4">Oops. The page you're looking for doesn't exist.</p>
                            <a class='btn btn-primary' href='<?= $domain; ?>'>Back to home</a>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <?php include('partials/footer.php'); ?>
    </body>

</html>