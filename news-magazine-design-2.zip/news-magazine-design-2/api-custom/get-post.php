<?php
# Validate Token and Parameter
if(!isset($_SERVER['HTTP_X_SECRET_TOKEN']) || $_SERVER['HTTP_X_SECRET_TOKEN'] != 'gIUioNaOuaeaVF1k') {

    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['status' => 'failed', 'error' => 'Authentication Failed']);
    die();
}

include(dirname(__FILE__).'/../includes/config.php');

# Validate Post URL
if(!isset($_GET['post_id']) || empty($_GET['post_id'])) {

    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['status' => 'failed', 'error' => 'Direct Access Failed']);

    $pdoObj=null;
    die();
}
$post_id = $_GET['post_id'];


# Get Post Data
$postObj = getPost($pdoObj, 'post_id', $post_id);
if($postObj) {
    
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['status' => 'success', 'data' => $postObj]);
}
else {
    
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['status' => 'failed', 'error' => 'Post not found']);
}

$pdoObj=null;
die();