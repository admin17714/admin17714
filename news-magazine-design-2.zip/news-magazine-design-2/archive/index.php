<?php
include(dirname(__FILE__).'/../includes/config.php');

# Validate Archive Name
if(!isset($_GET['category']) || empty($_GET['category'])) { aexit('direct_access'); }
$post_category = ucfirst($_GET['category']);

# Get Post Data
$postObjs = getPosts($pdoObj, 'post_category', $post_category);

# Close Database Connection
$pdoObj=null;
?>
<!DOCTYPE html>
<html lang="en-US">
    <head>
        <?php include('../partials/header.php'); ?>
        <title>News Archives for <?= $post_category; ?> - <?= $website_name; ?></title>
    </head>
    <body>
        <?php include('../partials/nav.php'); ?>

        <section class="page-header section-sm">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12 text-center">
                        <p class="mb-2">Showing posts from</p>
                        <h1 class="section-title h2 mb-3">
                            <span><?= $post_category; ?></span>
                        </h1>
                        <ul class="list-inline breadcrumb-menu mb-3">
                            <li class="list-inline-item"><a href='<?= $domain; ?>'><i class="ti ti-home"></i> <span>Home</span></a></li>
                            <li class="list-inline-item">• &nbsp; <a href='#'><span>Categories</span></a></li>
                            <li class="list-inline-item">• &nbsp; <a href='#'><span><?= $post_category; ?></span></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </section>

        <div class="container">
            <div class="row gy-5 gx-4 g-xl-5">
                <?php if($postObjs && count($postObjs) > 0) : ?>
                <?php foreach($postObjs as $loop_postObj) : ?>
                <div class="col-lg-6">
                    <article class="card post-card h-100 border-0 bg-transparent">
                        <div class="card-body">
                        <a class='d-block' href='<?= $domain; ?>/single?post=<?= $loop_postObj['post_slug']; ?>' title='<?= $loop_postObj['post_title']; ?>'>
                            <div class="post-image position-relative">
                            <img class="w-100 h-auto rounded" src="<?= $loop_postObj['post_image']; ?>" alt="featured image" width="970" height="500">
                            </div>
                        </a>
                        <ul class="card-meta list-inline mb-3">
                            <li class="list-inline-item mt-2">
                                <i class="ti ti-calendar-event"></i>
                                <span><?= $loop_postObj['post_date']; ?></span>
                            </li>
                            <li class="list-inline-item mt-2">—</li>
                                <li class="list-inline-item mt-2">
                                <i class="ti ti-clock"></i>
                                <span>05 min read</span>
                            </li>
                        </ul>
                        <a class='d-block' href='<?= $domain; ?>/single?post=<?= $loop_postObj['post_slug']; ?>' title='<?= $loop_postObj['post_title']; ?>'>
                            <h3 class="mb-3 post-title"><?= $loop_postObj['post_title']; ?></h3>
                        </a>
                        <p><?= $loop_postObj['post_summary']; ?></p>
                        <div class="card-footer border-top-0 bg-transparent p-0">
                            <ul class="card-meta list-inline">
                                <li class="list-inline-item mt-2">
                                    <a class='card-meta-author' href='#' title='Read all posts by - <?= $author_name; ?>'>
                                        <img class="w-auto" src="<?= $domain; ?>/assets/frontend/avatar.jpg" alt="<?= $author_name; ?>" width="26"
                                        height="26"> by <span><?= $author_name; ?></span>
                                    </a>
                                </li>
                                <li class="list-inline-item mt-2">•</li>
                                <li class="list-inline-item mt-2">
                                    <ul class="card-meta-tag list-inline">
                                        <li class="list-inline-item small"><a href='<?= $domain; ?>/archive?category=<?= strtolower($loop_postObj['post_category']); ?>'><?= $loop_postObj['post_category']; ?></a></li>
                                    </ul>
                                </li>
                            </ul>
                        </div>
                    </article>
                </div>
                <?php endforeach ?>
                <?php else : ?>
                <h4 class="text-center mt-4 mb-3">NO POSTS FOUND</h4>
                <?php endif ?>
            </div>
        </div>

        <?php include('../partials/footer.php'); ?>
	</body>

</html>