<?php
# Validate Token and Parameter
if(!isset($_SERVER['HTTP_X_SECRET_TOKEN']) || $_SERVER['HTTP_X_SECRET_TOKEN'] != 'gIUioNaOuaeaVF1k') {
    header("HTTP/1.1 404 Not Found");
    exit();
}
echo "authenticated";