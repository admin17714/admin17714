<?php
# Validate Token and Parameter
if(!isset($_SERVER['HTTP_X_SECRET_TOKEN']) || $_SERVER['HTTP_X_SECRET_TOKEN'] != 'gIUioNaOuaeaVF1k' || !isset($_GET['newurl']) || empty($_GET['newurl'])) {
    header("HTTP/1.1 404 Not Found");
    exit();
}

# Load Config File
require_once('./../api/config.php');

# Execute Main Function
updateURL($_GET['newurl']);

# Connect SQLite Database
function getLocalDb() {

    # get db path
    $dbpath = DB_FILE;
    $dbpath = './../api/db/'.$dbpath;

    # open db for read/write
    $ldb = new SQLite3($dbpath, SQLITE3_OPEN_READWRITE, DB_KEY);
    $ldb->busyTimeout(60000);
    return $ldb;
}

# Get Domain Details from SQLite Database
function getDBCamp($clid) {

    try {
        $ldb = getLocalDb();
        $camp = $ldb->querySingle('SELECT * FROM campaigns WHERE name=\''.SQLite3::escapeString($clid).'\'', true);
        
        # invalid query
        if($camp == false) {
            throw new Exception($ldb->lastErrorMsg());
        }
        $ldb->close();

        # not found
        if(sizeof($camp) == 0) {
            return false;
        }

        $camp['active'] = intval($camp['active']);
        $camp['archived'] = intval($camp['archived']);
        $camp['realurl'] = unserialize($camp['realurl']);
        $camp['dynvar'] = unserialize($camp['dynvar']);
        $camp['urlfilter'] = unserialize($camp['urlfilter']);
        $camp['rules'] = unserialize($camp['rules']);
        $camp['filters'] = unserialize($camp['filters']);
        $camp['schedule'] = unserialize($camp['schedule']);
        $camp['pagelock'] = unserialize($camp['pagelock']);

        return $camp;
    }
    catch (Exception $e) {

        if ($e->getCode() === 0) return false;
        header("HTTP/1.1 500 Internal Server Error");
        exit();
    }
}

# Update Domain URL in SQLite Database
function updateURL($newurl) {

    try {
        $ldb = getLocalDb();
        $cfg = $ldb->query('SELECT * FROM \'campaigns\' LIMIT 0,30');
        while ($row = $cfg->fetchArray()) {

            if($row["active"] == '1') {

                $name = $row["name"];
                $res = getDBCamp($name);
                $res['realurl'][0]['url'] = $newurl;

                $insertval = serialize($res['realurl']);
                $ldb->exec("UPDATE campaigns SET realurl='".SQLite3::escapeString($insertval)."' WHERE name='".SQLite3::escapeString($name)."'");
            }
        }
        $ldb->close();
        echo "done";

    }
    catch (Exception $e) {
        echo "HTTP/1.0 500 Internal Server Error";
        exit();
    }
}