<?php
// for legacy campaigns
$pathAppend='api/';
include_once($pathAppend.'go.php');
