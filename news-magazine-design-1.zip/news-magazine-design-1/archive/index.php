<?php
include(dirname(__FILE__).'/../includes/config.php');

# Validate Archive Name
if(!isset($_GET['category']) || empty($_GET['category'])) { aexit('direct_access'); }
$post_category = ucfirst($_GET['category']);

# Get Post Data
$postObjs = getPosts($pdoObj, 'post_category', $post_category);

# Recet Posts
$recentPostObjs = recentPosts($pdoObj, 3);

# Close Database Connection
$pdoObj=null;
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <?php include('../partials/header.php'); ?>
        <title>News Archives for <?= $post_category; ?> - <?= $website_name; ?></title>
    </head>
    <body>
        <?php include('../partials/nav.php'); ?>
        <main>
            <section class="pt-4">
                <div class="container">
                    <div class="row">
                        <div class="col-12">
                            <div class="border p-4 text-center rounded-3">
                                <h1>News Archives for <?= $post_category; ?></h1>
                                <nav class="d-flex justify-content-center" aria-label="breadcrumb">
                                    <ol class="breadcrumb breadcrumb-dots m-0">
                                        <li class="breadcrumb-item">
                                            <a href="<?= $domain; ?>"><i class="bi bi-house me-1"></i>Home</a>
                                        </li>
                                        <li class="breadcrumb-item active">News Archives for <?= $post_category; ?></li>
                                    </ol>
                                </nav>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <section class="position-relative pt-0">
                <div class="container" data-sticky-container="">
                    <div class="row">
                        <div class="col-lg-9">
                            <?php if($postObjs && count($postObjs) > 0) : ?>
                            <?php foreach($postObjs as $loop_postObj) : ?>
                            <div class="card mb-4">
                                <div class="row">
                                    <div class="col-md-5">
                                        <img class="rounded-3" src="<?= $loop_postObj['post_image']; ?>" alt="featured_image">
                                    </div>
                                    <div class="col-md-7 mt-3 mt-md-0">
                                        <a href="#" class="badge text-bg-warning mb-2">
                                            <i class="fas fa-circle me-2 small fw-bold"></i><?= $loop_postObj['post_category']; ?>
                                        </a>
                                        <h3><a href="<?= $domain; ?>/single?post=<?= $loop_postObj['post_slug']; ?>" class="btn-link stretched-link text-reset"><?= $loop_postObj['post_title']; ?></a></h3>
                                        <p><?= $loop_postObj['post_summary']; ?></p>
                                        <!-- Card info -->
                                        <ul class="nav nav-divider align-items-center d-none d-sm-inline-block">
                                            <li class="nav-item">
                                                <div class="nav-link">
                                                    <div class="d-flex align-items-center position-relative">
                                                        <div class="avatar avatar-xs">
                                                            <img class="avatar-img rounded-circle" src="<?= $domain; ?>/assets/images/avatar.jpg" alt="avatar">
                                                        </div>
                                                        <span class="ms-3">by
                                                            <a href="#" class="stretched-link text-reset btn-link">Jacqueline</a>
                                                        </span>
                                                    </div>
                                                </div>
                                            </li>
                                            <li class="nav-item"><?= $loop_postObj['post_date']; ?></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach ?>
                            <?php else : ?>
                            <h4 class="text-center mt-4 mb-3">NO POSTS FOUND</h4>
                            <?php endif ?>
                        </div>
                        <div class="col-lg-3 mt-5 mt-lg-0">
                            <div data-sticky="" data-margin-top="80" data-sticky-for="767">
                                <div>
                                    <h4 class="mb-3">Trending topics</h4>
                                    <!-- Category item -->
                                    <div class="text-center mb-3 card-bg-scale position-relative overflow-hidden rounded" style="background-image:url(<?= $domain; ?>/assets/images/category/travel.jpg); background-position: center left; background-size: cover;">
                                        <div class="bg-dark-overlay-4 p-3">
                                            <a href="<?= $domain; ?>/archive?category=travel" class="stretched-link btn-link fw-bold text-white h5">Travel</a>
                                        </div>
                                    </div>
                                    <!-- Category item -->
                                    <div class="text-center mb-3 card-bg-scale position-relative overflow-hidden rounded" style="background-image:url(<?= $domain; ?>/assets/images/category/business.jpg); background-position: center left; background-size: cover;">
                                        <div class="bg-dark-overlay-4 p-3">
                                            <a href="<?= $domain; ?>/archive?category=business" class="stretched-link btn-link fw-bold text-white h5">Business</a>
                                        </div>
                                    </div>
                                    <!-- Category item -->
                                    <div class="text-center mb-3 card-bg-scale position-relative overflow-hidden rounded" style="background-image:url(<?= $domain; ?>/assets/images/category/marketing.jpg); background-position: center left; background-size: cover;">
                                        <div class="bg-dark-overlay-4 p-3">
                                            <a href="<?= $domain; ?>/archive?category=marketing" class="stretched-link btn-link fw-bold text-white h5">Marketing</a>
                                        </div>
                                    </div>
                                    <!-- Category item -->
                                    <div class="text-center mb-3 card-bg-scale position-relative overflow-hidden rounded" style="background-image:url(<?= $domain; ?>/assets/images/category/fitness.jpg); background-position: center left; background-size: cover;">
                                        <div class="bg-dark-overlay-4 p-3">
                                            <a href="<?= $domain; ?>/archive?category=fitness" class="stretched-link btn-link fw-bold text-white h5">Fitness</a>
                                        </div>
                                    </div>
                                    <!-- Category item -->
                                    <div class="text-center mb-3 card-bg-scale position-relative overflow-hidden rounded" style="background-image:url(<?= $domain; ?>/assets/images/category/lifestyles.jpg); background-position: center left; background-size: cover;">
                                        <div class="bg-dark-overlay-4 p-3">
                                            <a href="<?= $domain; ?>/archive?category=lifestyles" class="stretched-link btn-link fw-bold text-white h5">Lifestyles</a>
                                        </div>
                                    </div>
                                    <!-- Category item -->
                                    <div class="text-center mb-3 card-bg-scale position-relative overflow-hidden rounded" style="background-image:url(<?= $domain; ?>/assets/images/category/celebrities.jpg); background-position: center left; background-size: cover;">
                                        <div class="bg-dark-overlay-4 p-3">
                                            <a href="<?= $domain; ?>/archive?category=celebrities" class="stretched-link btn-link fw-bold text-white h5">Celebrities</a>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-12 col-sm-6 col-lg-12">
                                        <h4 class="mt-4 mb-3">Recent post</h4>
                                        <?php if($recentPostObjs && count($recentPostObjs) > 0) : ?>
                                        <?php foreach($recentPostObjs as $loop_postObj) : ?>
                                        <div class="card mb-3">
                                            <div class="row g-3">
                                                <div class="col-4">
                                                    <img class="rounded" src="<?= $loop_postObj['post_image']; ?>" alt="featured_image">
                                                </div>
                                                <div class="col-8">
                                                    <h6>
                                                        <a href="<?= $domain; ?>/single?post=<?= $loop_postObj['post_slug']; ?>" class="btn-link stretched-link text-reset fw-bold"><?= $loop_postObj['post_title']; ?></a>
                                                    </h6>
                                                    <div class="small mt-1"><?= $loop_postObj['post_date']; ?></div>
                                                </div>
                                            </div>
                                        </div>
                                        <?php endforeach ?>
                                        <?php else : ?>
                                        <h6 class="text-center mt-4 mb-3">NO POSTS FOUND</h6>
                                        <?php endif ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </main>
        <?php include('../partials/footer.php'); ?>
    </body>
</html>
