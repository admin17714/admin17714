<!-- Meta Tags -->
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta name="description" content="Breaking News & In-Depth Analysis - Your Trusted Source for Current Events">

<!-- Dark mode -->
<script>const storedTheme=localStorage.getItem("theme"),getPreferredTheme=()=>storedTheme||(window.matchMedia("(prefers-color-scheme: light)").matches,"light"),setTheme=function(e){"auto"===e&&window.matchMedia("(prefers-color-scheme: dark)").matches?document.documentElement.setAttribute("data-bs-theme","dark"):document.documentElement.setAttribute("data-bs-theme",e)};setTheme(getPreferredTheme()),window.addEventListener("DOMContentLoaded",()=>{var e=document.querySelector(".theme-icon-active");if("undefined"!=e&&null!=e){let t=e=>{let t=document.querySelector(".theme-icon-active use"),r=document.querySelector(`[data-bs-theme-value="${e}"]`),a=r.querySelector(".mode-switch use").getAttribute("href");document.querySelectorAll("[data-bs-theme-value]").forEach(e=>{e.classList.remove("active")}),r.classList.add("active"),t.setAttribute("href",a)};window.matchMedia("(prefers-color-scheme: dark)").addEventListener("change",()=>{("light"!==storedTheme||"dark"!==storedTheme)&&setTheme(getPreferredTheme())}),t(getPreferredTheme()),document.querySelectorAll("[data-bs-theme-value]").forEach(e=>{e.addEventListener("click",()=>{let r=e.getAttribute("data-bs-theme-value");localStorage.setItem("theme",r),setTheme(r),t(r)})})}});</script>

<!-- Favicon -->
<link rel="shortcut icon" href="<?= $domain; ?>/favicon.ico">

<!-- Google Font -->
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Nunito+Sans:wght@400;700&family=Rubik:wght@400;500;700&display=swap" rel="stylesheet">

<!-- Plugins CSS -->
<link rel="stylesheet" type="text/css" href="<?= $domain; ?>/assets/backend/vendor/font-awesome/css/all.min.css">
<link rel="stylesheet" type="text/css" href="<?= $domain; ?>/assets/backend/vendor/bootstrap-icons/bootstrap-icons.css">
<link rel="stylesheet" type="text/css" href="<?= $domain; ?>/assets/backend/vendor/quill/css/quill.snow.css">

<!-- Theme CSS -->
<link rel="stylesheet" type="text/css" href="<?= $domain; ?>/assets/backend/css/style.css">