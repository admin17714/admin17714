<?php
include(dirname(__FILE__).'/../includes/config.php');

# Redirect to SignIn if Not LoggedIn
session_start();
if(!isset($_SESSION["is_loggedIn"]) || $_SESSION["is_loggedIn"] != 'mrtaxx@gmail.com') {
    header("Location: ".$domain."/signin");
}


# Post Method
if($_SERVER['REQUEST_METHOD'] === 'POST') {

    # Update Post
    $updateObj = updateConfig($pdoObj, $_POST);

    # Close Database Connection
    $pdoObj=null;

    # Check Update Status
    if(!$updateObj) {
        echo 'Error while updating config, please go back'; exit();
    }

    # Redirect
    header("Location: ".$domain."/backend/config.php");
}


# Get Config Data
$configObj = getConfig($pdoObj);
if(!$configObj) {
    http_response_code(404);
    include('../404.php');
    die();
}

# Close Database Connection
$pdoObj=null;
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <?php include('partials/header.php'); ?>
        <title>Edit Post - <?= $website_name; ?></title>
    </head>
    <body>
        <?php include('partials/nav.php'); ?>
        <main>
            <section class="py-4">
                <div class="container">
                    <div class="row pb-4">
                        <div class="col-12">
                            <h1 class="mb-0 h3">Edit Website Configuration</h1>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-12">
                            <!-- Chart START -->
                            <div class="card border">
                                <!-- Card body -->
                                <div class="card-body">
                                    <!-- Form START -->
                                    <form method="post" action="<?= $domain; ?>/backend/config.php" id="configForm">
                                        <!-- Main form -->
                                        <div class="row">
                                            <div class="col-6">
                                                <div class="mb-3">
                                                    <label class="form-label">Website Name</label>
                                                    <input id="con-name" name="website_name" type="text" class="form-control" placeholder="Website Name" value="<?= $configObj['website_name']; ?>" required>
                                                </div>
                                            </div>
                                            <div class="col-6">
                                                <div class="mb-3">
                                                    <label class="form-label">Author Name</label>
                                                    <input id="con-name" name="author_name" type="text" class="form-control" placeholder="Author Name" value="<?= $configObj['author_name']; ?>" required>
                                                </div>
                                            </div>
                                            <div class="col-12">
                                                <div class="mb-3">
                                                    <label class="form-label">Homepage Title</label>
                                                    <input id="con-name" name="homepage_title" type="text" class="form-control" placeholder="Homepage Title" value="<?= $configObj['homepage_title']; ?>" required>
                                                </div>
                                            </div>
                                            <div class="col-8">
                                                <div class="mb-3">
                                                    <label class="form-label">Matamo Domain</label>
                                                    <input id="con-name" name="matamo_domain" type="text" class="form-control" placeholder="Matamo Domain" value="<?= $configObj['matamo_domain']; ?>" required>
                                                </div>
                                            </div>
                                            <div class="col-4">
                                                <div class="mb-3">
                                                    <label class="form-label">Matamo Site ID</label>
                                                    <input id="con-name" name="matamo_site_id" type="text" class="form-control" placeholder="Matamo Site ID" value="<?= $configObj['matamo_site_id']; ?>" required>
                                                </div>
                                            </div>
                                            <div class="mt-5 col-md-12 text-start">
                                                <button class="btn btn-primary w-100" type="submit"><i class="bi bi-save me-2"></i>Update Config</button>
                                            </div>
                                        </div>
                                    </form>
                                    <!-- Form END -->
                                </div>
                            </div>
                            <!-- Chart END -->
                        </div>
                    </div>
                </div>
            </section>
        </main>
        <?php include('partials/footer.php'); ?>
        <script>
            document.getElementById("configForm").addEventListener("submit", function(event) {
                if(!confirm("Are you sure want to update ?")) { event.preventDefault(); }
            });
        </script>
    </body>
</html>
