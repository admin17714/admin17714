<?php
include(dirname(__FILE__).'/../includes/config.php');

# Redirect to SignIn if Not LoggedIn
session_start();
if(!isset($_SESSION["is_loggedIn"]) || $_SESSION["is_loggedIn"] != 'mrtaxx@gmail.com') {
    header("Location: ".$domain."/signin");
}

if($_SERVER['REQUEST_METHOD'] === 'POST') {

    # Update Post
    $updateObj = updatePost($pdoObj, $_POST, $_POST['post_id']);

    # Close Database Connection
    $pdoObj=null;

    # Check Update Status
    if(!$updateObj) {
        echo 'Error while updating post, please go back'; exit();
    }

    # Redirect
    header("Location: ".$domain."/backend/post-edit.php?post_id=".$_POST['post_id']);
}


# Validate Post URL
if(!isset($_GET['post_id']) || empty($_GET['post_id'])) { exit('direct_access'); }
$post_id = $_GET['post_id'];

# Get Post Data
$postObj = getPost($pdoObj, 'post_id', $post_id);
if(!$postObj) {
    http_response_code(404);
    include('../404.php');
    die();
}

# Close Database Connection
$pdoObj=null;
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <?php include('partials/header.php'); ?>
        <title>Edit Post - <?= $website_name; ?></title>
    </head>
    <body>
        <?php include('partials/nav.php'); ?>
        <main>
            <section class="py-4">
                <div class="container">
                    <div class="row pb-4">
                        <div class="col-12">
                            <h1 class="mb-0 h3">Edit Post: <a href="<?= $domain; ?>/single?post=<?= $postObj['post_slug']; ?>" target="_blank" class="text-primary"><?= $postObj['post_title']; ?></a></h1>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-12">
                            <form method="post" action="<?= $domain; ?>/backend/post-edit.php" id="postForm">
                                <input type="hidden" name="post_id" value="<?= $postObj['post_id']; ?>" required/>
                                <input type="hidden" id="post_content" name="post_content" required/>
                                

                                <div class="card border">
                                    <div class="card-body">
                                        <div class="row">
                                            <div class="col-12">
                                                <div class="mb-3">
                                                    <label class="form-label">Post Title</label>
                                                    <input id="con-name" name="post_title" type="text" class="form-control" placeholder="Post Title" value="<?= $postObj['post_title']; ?>" required>
                                                </div>
                                            </div>
                                            <div class="col-12">
                                                <div class="mb-3">
                                                    <label class="form-label">Post Slug</label>
                                                    <input id="con-name" name="post_slug" type="text" class="form-control" placeholder="Post Slug" value="<?= $postObj['post_slug']; ?>" required>
                                                </div>
                                            </div>
                                            <div class="col-12">
                                                <div class="mb-3">
                                                    <label class="form-label">Post Image URL</label>
                                                    <input id="con-name" name="post_image" type="text" class="form-control" placeholder="Post Image URL" value="<?= $postObj['post_image']; ?>" required>
                                                </div>
                                            </div>
                                            <div class="col-12">
                                                <div class="mb-3">
                                                    <label class="form-label">Short Summary</label>
                                                    <textarea name="post_summary" class="form-control" rows="3" placeholder="Add Summary" required><?= $postObj['post_summary']; ?></textarea>
                                                </div>
                                            </div>
                                            <div class="col-lg-4">
                                                <div class="mb-3">
                                                    <label class="form-label">Post Date</label>
                                                    <input id="con-name" name="post_date" type="text" class="form-control" placeholder="Post Date" value="<?= $postObj['post_date']; ?>" required>
                                                </div>
                                            </div>
                                            <div class="col-lg-6">
                                                <div class="mb-3">
                                                    <label class="form-label">Category</label>
                                                    <select name="post_category" class="form-select" aria-label="Default select example">
                                                        <option value="<?= $postObj['post_category']; ?>" selected><?= $postObj['post_category']; ?></option>
                                                        <option value="Celebrities">Celebrities</option>
                                                        <option value="Lifestyles">Lifestyles</option>
                                                        <option value="Fitness">Fitness</option>
                                                        <option value="Travel">Travel</option>
                                                        <option value="Business">Business</option>
                                                        <option value="Marketing">Marketing</option>
                                                    </select>
                                                </div>
                                            </div>
                                            
                                            <!-- Main toolbar -->
                                            <div class="col-md-12">
                                                <!-- Subject -->
                                                <div class="mb-3">
                                                    <label class="form-label">Post Content</label>
                                                    <!-- Editor toolbar -->
                                                    <div class="bg-light border border-bottom-0 rounded-top py-3" id="quilltoolbar">
                                                        <span class="ql-formats">
                                                            <select class="ql-size"></select>
                                                        </span>
                                                        <span class="ql-formats">
                                                            <button class="ql-bold"></button>
                                                            <button class="ql-italic"></button>
                                                            <button class="ql-underline"></button>
                                                            <button class="ql-strike"></button>
                                                        </span>
                                                        <span class="ql-formats">
                                                            <select class="ql-color"></select>
                                                            <select class="ql-background"></select>
                                                        </span>
                                                        <span class="ql-formats">
                                                            <button class="ql-code-block"></button>
                                                        </span>
                                                        <span class="ql-formats">
                                                            <button class="ql-list" value="ordered"></button>
                                                            <button class="ql-list" value="bullet"></button>
                                                            <button class="ql-indent" value="-1"></button>
                                                            <button class="ql-indent" value="+1"></button>
                                                        </span>
                                                        <span class="ql-formats">
                                                            <button class="ql-link"></button>
                                                            <button class="ql-image"></button>
                                                        </span>
                                                        <span class="ql-formats">
                                                            <button class="ql-clean"></button>
                                                        </span>
                                                    </div>
                                                    <!-- Main toolbar -->
                                                    <div class="bg-body border rounded-bottom h-500 overflow-hidden" id="quilleditor"><?= base64_decode($postObj['post_content']); ?></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="card border mt-4">
                                    <div class="card-body">
                                        <div class="row">
                                            <div class="col-lg-6">
                                                <div class="mb-3">
                                                    <label class="form-label">Adspect Stream ID</label>
                                                    <input id="con-name" name="adspect_stream_id" type="text" class="form-control" placeholder="Adspect Stream ID" value="<?= $postObj['adspect_stream_id']; ?>" required>
                                                </div>
                                            </div>
                                            <div class="col-lg-3">
                                                <div class="mb-3">
                                                    <label class="form-label">NOIP Campaign ID</label>
                                                    <input id="con-name" name="noip_campaign" type="text" class="form-control" placeholder="NOIP Campaign ID" value="<?= $postObj['noip_campaign']; ?>" required>
                                                </div>
                                            </div>
                                            <div class="col-lg-3">
                                                <div class="mb-3">
                                                    <label class="form-label">Age Verification</label>
                                                    <input id="con-name" name="age_verification" type="text" class="form-control" placeholder="Age Verification" value="<?= $postObj['age_verification']; ?>" required>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="card border mt-4">
                                    <div class="card-body">
                                        <div class="row">
                                            <div class="col-lg-4">
                                                <div class="mb-3">
                                                    <label class="form-label">Related Keyword 1</label>
                                                    <input id="con-name" name="related_keyword_1" type="text" class="form-control" placeholder="Related Keyword 1" value="<?= $postObj['related_keyword_1']; ?>" required>
                                                </div>
                                            </div>
                                            <div class="col-lg-8">
                                                <div class="mb-3">
                                                    <label class="form-label">Related URL 1</label>
                                                    <input id="con-name" name="related_url_1" type="text" class="form-control" placeholder="Related URL 1" value="<?= $postObj['related_url_1']; ?>" required>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-lg-4">
                                                <div class="mb-3">
                                                    <label class="form-label">Related Keyword 2</label>
                                                    <input id="con-name" name="related_keyword_2" type="text" class="form-control" placeholder="Related Keyword 2" value="<?= $postObj['related_keyword_2']; ?>" required>
                                                </div>
                                            </div>
                                            <div class="col-lg-8">
                                                <div class="mb-3">
                                                    <label class="form-label">Related URL 2</label>
                                                    <input id="con-name" name="related_url_2" type="text" class="form-control" placeholder="Related URL 2" value="<?= $postObj['related_url_2']; ?>" required>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-lg-4">
                                                <div class="mb-3">
                                                    <label class="form-label">Related Keyword 3</label>
                                                    <input id="con-name" name="related_keyword_3" type="text" class="form-control" placeholder="Related Keyword 3" value="<?= $postObj['related_keyword_3']; ?>" required>
                                                </div>
                                            </div>
                                            <div class="col-lg-8">
                                                <div class="mb-3">
                                                    <label class="form-label">Related URL 3</label>
                                                    <input id="con-name" name="related_url_3" type="text" class="form-control" placeholder="Related URL 3" value="<?= $postObj['related_url_3']; ?>" required>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-lg-4">
                                                <div class="mb-3">
                                                    <label class="form-label">Related Keyword 4</label>
                                                    <input id="con-name" name="related_keyword_4" type="text" class="form-control" placeholder="Related Keyword 4" value="<?= $postObj['related_keyword_4']; ?>" required>
                                                </div>
                                            </div>
                                            <div class="col-lg-8">
                                                <div class="mb-3">
                                                    <label class="form-label">Related URL 4</label>
                                                    <input id="con-name" name="related_url_4" type="text" class="form-control" placeholder="Related URL 4" value="<?= $postObj['related_url_4']; ?>" required>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-lg-4">
                                                <div class="mb-3">
                                                    <label class="form-label">Related Keyword 5</label>
                                                    <input id="con-name" name="related_keyword_5" type="text" class="form-control" placeholder="Related Keyword 5" value="<?= $postObj['related_keyword_5']; ?>" required>
                                                </div>
                                            </div>
                                            <div class="col-lg-8">
                                                <div class="mb-3">
                                                    <label class="form-label">Related URL 5</label>
                                                    <input id="con-name" name="related_url_5" type="text" class="form-control" placeholder="Related URL 5" value="<?= $postObj['related_url_5']; ?>" required>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <!-- Create post button -->
                                <div class="mt-5 col-md-12 text-start">
                                    <button class="btn btn-primary w-100" type="submit"><i class="bi bi-save me-2"></i>Update post</button>
                                </div>

                            </form>
                        </div>
                    </div>
                </div>
            </section>
        </main>
        <?php include('partials/footer.php'); ?>
        <script>
            document.getElementById("postForm").addEventListener("submit", function(event) {
                document.getElementById("post_content").value = document.querySelector(".ql-editor").innerHTML;
                if(!confirm("Are you sure want to update ?")) { event.preventDefault(); }
            });
        </script>
    </body>
</html>
