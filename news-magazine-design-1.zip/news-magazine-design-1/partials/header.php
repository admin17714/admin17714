<!-- Meta Tags -->
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta name="description" content="Breaking News & In-Depth Analysis - Your Trusted Source for Current Events">

<!-- Dark mode -->
<script>const storedTheme=localStorage.getItem("theme"),getPreferredTheme=()=>storedTheme||(window.matchMedia("(prefers-color-scheme: light)").matches,"light"),setTheme=function(e){"auto"===e&&window.matchMedia("(prefers-color-scheme: dark)").matches?document.documentElement.setAttribute("data-bs-theme","dark"):document.documentElement.setAttribute("data-bs-theme",e)};setTheme(getPreferredTheme()),window.addEventListener("DOMContentLoaded",()=>{var e=document.querySelector(".theme-icon-active");if("undefined"!=e&&null!=e){let t=e=>{let t=document.querySelector(".theme-icon-active use"),r=document.querySelector(`[data-bs-theme-value="${e}"]`),a=r.querySelector(".mode-switch use").getAttribute("href");document.querySelectorAll("[data-bs-theme-value]").forEach(e=>{e.classList.remove("active")}),r.classList.add("active"),t.setAttribute("href",a)};window.matchMedia("(prefers-color-scheme: dark)").addEventListener("change",()=>{("light"!==storedTheme||"dark"!==storedTheme)&&setTheme(getPreferredTheme())}),t(getPreferredTheme()),document.querySelectorAll("[data-bs-theme-value]").forEach(e=>{e.addEventListener("click",()=>{let r=e.getAttribute("data-bs-theme-value");localStorage.setItem("theme",r),setTheme(r),t(r)})})}});</script>

<!-- Favicon -->
<link rel="shortcut icon" href="<?= $domain; ?>/assets/backend/favicon.ico">

<!-- Google Font -->
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Nunito+Sans:wght@400;700&family=Rubik:wght@400;500;700&display=swap" rel="stylesheet">

<!-- Plugins CSS -->
<link rel="stylesheet" type="text/css" href="<?= $domain; ?>/assets/frontend/vendor/font-awesome/css/all.min.css">
<link rel="stylesheet" type="text/css" href="<?= $domain; ?>/assets/frontend/vendor/bootstrap-icons/bootstrap-icons.css">

<!-- Theme CSS -->
<link rel="stylesheet" type="text/css" href="<?= $domain; ?>/assets/frontend/css/style.css">

<?php
$site_code_header = base64_decode($configObj['site_code_header']);
$site_code_footer = base64_decode($configObj['site_code_footer']);

$matamo_domain = $configObj['matamo_domain'];
$matamo_site_id = $configObj['matamo_site_id'];

if($site_code_header != 'NA') { echo $site_code_header; }

if($matamo_domain != 'NA' && $matamo_site_id != 'NA') { ?>
<!-- Matomo -->
<script>
  var _paq = window._paq = window._paq || [];
  /* tracker methods like "setCustomDimension" should be called before "trackPageView" */
  _paq.push(['trackPageView']);
  _paq.push(['enableLinkTracking']);
  (function() {
    var u="//<?= $matamo_domain; ?>/";
    _paq.push(['setTrackerUrl', u+'matomo.php']);
    _paq.push(['setSiteId', '<?= $matamo_site_id; ?>']);
    var d=document, g=d.createElement('script'), s=d.getElementsByTagName('script')[0];
    g.async=true; g.src=u+'matomo.js'; s.parentNode.insertBefore(g,s);
  })();
</script>
<!-- End Matomo Code -->
<?php } ?>