<footer class="pb-5">
	<div class="container">
		<div class="row pt-5">
			<div class="col-lg-7 mx-auto text-center">
				<!-- Logo -->
				<img class="light-mode-item mx-auto" src="<?= $domain; ?>/assets/frontend/logo.png" alt="logo" width="80px" height="80px">			
				<img class="dark-mode-item mx-auto" src="<?= $domain; ?>/assets/frontend/logo.png" alt="logo" width="80px" height="80px">
				<p class="mt-3">We are committed to delivering in-depth reporting on a wide range of topics, from politics and business to culture and technology. Our team of dedicated journalists works tirelessly to bring you the stories that matter, offering unique insights and analysis. We believe in the power of information to shape our world, and we strive to keep our readers informed and engaged.</p>
				<!-- Links -->
                <ul class="nav text-center text-sm-end justify-content-center justify-content-center mt-3 mt-md-0">
                    <li class="nav-item"><a class="nav-link" href="<?= $domain; ?>/about-us">About</a></li>
                    <li class="nav-item"><a class="nav-link" href="<?= $domain; ?>/legal/terms-service">Terms</a></li>
                    <li class="nav-item"><a class="nav-link" href="<?= $domain; ?>/legal/privacy-policy">Privacy</a></li>
                    <li class="nav-item"><a class="nav-link" href="<?= $domain; ?>/legal/contact-us">Contact us</a></li>
                    <li class="nav-item"><a class="nav-link pe-0" href="<?= $domain; ?>/legal/cppa-form">Data Privacy</a></li>
                </ul>
				<div class="mt-2">© 2025 The <?= $website_name; ?>. All rights reserved </div>
			</div>
		</div>
	</div>
</footer>

<!-- Back to top -->
<div class="back-top"><i class="bi bi-arrow-up-short"></i></div>

<!-- =======================
JS libraries, plugins and custom scripts -->

<!-- Bootstrap JS -->
<script src="<?= $domain; ?>/assets/frontend/vendor/bootstrap/dist/js/bootstrap.bundle.min.js"></script>

<!-- Template Functions -->
<script src="<?= $domain; ?>/assets/frontend/js/functions.js"></script>

<?php if($site_code_footer != 'NA') { echo $site_code_footer; } ?>