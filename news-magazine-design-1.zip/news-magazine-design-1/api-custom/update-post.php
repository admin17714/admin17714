<?php
# Validate Token and Parameter
if(!isset($_SERVER['HTTP_X_SECRET_TOKEN']) || $_SERVER['HTTP_X_SECRET_TOKEN'] != 'gIUioNaOuaeaVF1k') {

    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['status' => 'failed', 'error' => 'Authentication Failed']);
    die();
}

if($_SERVER['REQUEST_METHOD'] !== 'POST') {

    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['status' => 'failed', 'error' => 'Method not allowed']);
    die();
}

include(dirname(__FILE__).'/../includes/config.php');

# Update Post
$updateObj = updatePost($pdoObj, $_POST, $_POST['post_id']);

# Check Update Status
if($updateObj['status'] != 'failed') {

    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['status' => 'success']);
}
else {
    
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['status' => 'failed', 'error' => $updateObj['error']]);
}

$pdoObj=null;
die();