<?php
include(dirname(__FILE__).'/../includes/config.php');

# Validate Post URL
if(!isset($_GET['post']) || empty($_GET['post'])) { exit('direct_access'); }
$post_slug = $_GET['post'];

# Get Post Data
$postObj = getPost($pdoObj, 'post_slug', $post_slug);
if(!$postObj) {
    http_response_code(404);
    include('../404.php');
    die();
}

# Close Database Connection
$pdoObj=null;

# NOIP Campaign Only
define('APPLOC',  dirname(__FILE__).DIRECTORY_SEPARATOR.'..'.DIRECTORY_SEPARATOR.'client'.DIRECTORY_SEPARATOR.'api'.DIRECTORY_SEPARATOR);
if(file_exists(APPLOC) && $postObj['noip_campaign'] != 'NA') {

    if($postObj['age_verification_url'] != 'NA') {
        if(isset($_GET['verified'])) {
            $_GET['clid'] = $postObj['noip_campaign'];
            include(APPLOC.'go.php');
            if($isItSafe) { noIpFraud(); }
        }
    }
    else {
        $_GET['clid'] = $postObj['noip_campaign'];
        include(APPLOC.'go.php');
        if($isItSafe) { noIpFraud(); }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <?php include('../partials/header.php'); ?>
        <title><?= $postObj['post_title']; ?></title>
    </head>
    <body>
        <?php include('../partials/nav.php'); ?>
        <main>
            <div class="border-bottom border-primary border-1 opacity-1"></div>
            <section class="pb-3 pb-lg-5">
                <div class="container">
                    <div class="row">
                        <div class="col-12">
                            <a href="<?= $domain; ?>/archive?category=<?= strtolower($postObj['post_category']); ?>" class="badge text-bg-warning mb-2">
                                <i class="fas fa-circle me-2 small fw-bold"></i><?= $postObj['post_category']; ?>
                            </a>
                            <h1><?= $postObj['post_title']; ?></h1>
                        </div>
                        <p class="lead"><?= $postObj['post_summary']; ?></p>
                    </div>
                </div>
            </section>

            <section class="pt-0">
                <div class="container position-relative" data-sticky-container="">
                    <div class="row">
                        <div class="col-lg-2">
                            <div
                                class="text-start text-lg-center mb-5"
                                data-sticky=""
                                data-margin-top="80"
                                data-sticky-for="991"
                            >
                                <div class="position-relative">
                                    <div class="avatar avatar-xl">
                                        <img class="avatar-img rounded-circle" src="<?= $domain; ?>/assets/images/avatar.jpg" alt="avatar">
                                    </div>
                                    <a href="#" class="h5 stretched-link mt-2 mb-0 d-block"><?= $author_name; ?></a>
                                    <p>An editor at <?= $website_name; ?></p>
                                </div>
                                <hr class="d-none d-lg-block">
                                <ul class="list-inline list-unstyled">
                                    <li class="list-inline-item d-lg-block my-lg-2"><?= $postObj['post_date']; ?></li>
                                    <li class="list-inline-item d-lg-block my-lg-2">5 min read</li>
                                </ul>
                            </div>
                        </div>

                        <div class="col-lg-10 mb-5">
                            <img src="<?= $postObj['post_image']; ?>" class="rounded mx-auto d-block w-100" alt="featured_image" /><br>
                            <?= base64_decode($postObj['post_content']); ?>
                        </div>
                    </div>
                </div>
            </section>
        </main>
        <?php include('../partials/footer.php'); ?>
        <?php if($postObj['age_verification_url'] != 'NA') { include('../partials/age_popup.php'); } ?>
    </body>
</html>
