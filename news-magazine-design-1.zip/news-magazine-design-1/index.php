﻿<?php
include(dirname(__FILE__).'/includes/config.php');

# Recet Posts
$recentPostObjs = recentPosts($pdoObj, 12);

# Close Database Connection
$pdoObj=null;
?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<?php include('partials/header.php'); ?>
		<title><?= $website_name; ?></title>
	</head>
	<body>
		<?php include('partials/nav.php'); ?>
		<main>
			<section class="p-0">
				<div class="container">
					<div class="row g-4">
						<?php foreach($recentPostObjs as $loop_postObj): ?>
						<div class="col-sm-6 col-lg-4">
							<div class="card card-overlay-bottom card-image-scale">
								<img src="<?= $loop_postObj['post_image']; ?>" alt="featured_image">
								<div class="card-img-overlay d-flex flex-column p-3 p-md-4">
									<div>
										<a href="<?= $domain; ?>/archive?category=<?= strtolower($loop_postObj['post_category']); ?>" class="badge bg-warning mb-2"><i class="fas fa-circle me-2 small fw-bold"></i><?= $loop_postObj['post_category']; ?></a>
									</div>
									<div class="w-100 mt-auto">
										<h4 class="text-white"><a href="<?= $domain; ?>/single?post=<?= $loop_postObj['post_slug']; ?>" class="btn-link text-reset stretched-link"><?= $loop_postObj['post_title']; ?></a></h4>
										<ul class="nav nav-divider text-white-force align-items-center small">
											<li class="nav-item position-relative">
											<div class="nav-link">by <a href="#" class="stretched-link text-reset btn-link"><?= $author_name; ?></a>
											</div>
											</li>
											<li class="nav-item"><?= $loop_postObj['post_date']; ?></li>
										</ul>
									</div>
								</div>
							</div>
						</div>
						<?php endforeach ?>
					</div>
				</div>
			</section>

			<section class="p-0 mt-5">
				<div class="container">
					<div class="row">
						<div class="col-lg-2 col-md-4 col-sm-6 mb-4">
							<div class="card card-overlay-bottom card-img-scale">
								<img class="card-img" src="<?= $domain; ?>/assets/images/category/travel.jpg" alt="card image">
								<div class="card-img-overlay d-flex px-3 px-sm-5">
									<h5 class="mt-auto mx-auto">
										<a href="<?= $domain; ?>/archive?category=travel" class="stretched-link btn-link fw-bold text-white">Travel</a>
									</h5>
								</div>
							</div>
						</div>
						<div class="col-lg-2 col-md-4 col-sm-6 mb-4">
							<div class="card card-overlay-bottom card-img-scale">
								<img class="card-img" src="<?= $domain; ?>/assets/images/category/business.jpg" alt="card image">
								<div class="card-img-overlay d-flex px-3 px-sm-5">
									<h5 class="mt-auto mx-auto">
										<a href="<?= $domain; ?>/archive?category=business" class="stretched-link btn-link fw-bold text-white">Business</a>
									</h5>
								</div>
							</div>
						</div>
						<div class="col-lg-2 col-md-4 col-sm-6 mb-4">
							<div class="card card-overlay-bottom card-img-scale">
								<img class="card-img" src="<?= $domain; ?>/assets/images/category/marketing.jpg" alt="card image">
								<div class="card-img-overlay d-flex px-3 px-sm-5">
									<h5 class="mt-auto mx-auto">
										<a href="<?= $domain; ?>/archive?category=marketing" class="stretched-link btn-link fw-bold text-white">Marketing</a>
									</h5>
								</div>
							</div>
						</div>
						<div class="col-lg-2 col-md-4 col-sm-6 mb-4">
							<div class="card card-overlay-bottom card-img-scale">
								<img class="card-img" src="<?= $domain; ?>/assets/images/category/fitness.jpg" alt="card image">
								<div class="card-img-overlay d-flex px-3 px-sm-5">
									<h5 class="mt-auto mx-auto">
										<a href="<?= $domain; ?>/archive?category=fitness" class="stretched-link btn-link fw-bold text-white">Fitness</a>
									</h5>
								</div>
							</div>
						</div>
						<div class="col-lg-2 col-md-4 col-sm-6 mb-4">
							<div class="card card-overlay-bottom card-img-scale">
								<img class="card-img" src="<?= $domain; ?>/assets/images/category/lifestyles.jpg" alt="card image">
								<div class="card-img-overlay d-flex px-3 px-sm-5">
									<h5 class="mt-auto mx-auto">
										<a href="<?= $domain; ?>/archive?category=lifestyles" class="stretched-link btn-link fw-bold text-white">Lifestyles</a>
									</h5>
								</div>
							</div>
						</div>
						<div class="col-lg-2 col-md-4 col-sm-6 mb-4">
							<div class="card card-overlay-bottom card-img-scale">
								<img class="card-img" src="<?= $domain; ?>/assets/images/category/celebrities.jpg" alt="card image">
								<div class="card-img-overlay d-flex px-3 px-sm-5">
									<h5 class="mt-auto mx-auto">
										<a href="<?= $domain; ?>/archive?category=celebrities" class="stretched-link btn-link fw-bold text-white">Celebrities</a>
									</h5>
								</div>
							</div>
						</div>
					</div>
				</div>
			</section>
		</main>
		<?php include('partials/footer.php'); ?>
	</body>
</html>