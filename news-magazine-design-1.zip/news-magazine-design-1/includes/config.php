<?php
include('sqlite.php');

$domain = (empty($_SERVER['HTTPS']) ? 'http' : 'https')."://".$_SERVER['HTTP_HOST'];
$domainOnly = $_SERVER['SERVER_NAME'];

# Create Database Connection
$pdoObj = connectDb();
if(!$pdoObj) { exit('db_error'); }

# Get Config Data
$configObj = getConfig($pdoObj);
if(!$configObj) {
    http_response_code(404);
    include('../404.php');
    die();
}

# Static Variables
$website_name = $configObj['website_name'];
$homepage_title = $configObj['homepage_title'];
$author_name = $configObj['author_name'];