﻿
<?php
include(dirname(__FILE__).'/includes/config.php');

# Recet Posts
$recentPostObjs = recentPosts($pdoObj, 12);
$postOftheMonth = array_rand($recentPostObjs, 1);

# Close Database Connection
$pdoObj=null;
?>
<!DOCTYPE html>
<html lang="en-US">

    <head>
        <?php include('partials/header.php'); ?>
        <title><?= $website_name; ?></title>
    </head>
    <body class="home">
        <?php include('partials/nav-2.php'); ?>

        <div id="wrapper">
            <?php include('partials/nav.php'); ?>

            <main id="content">

                <?php if(isset($recentPostObjs[$postOftheMonth])) : ?>
                <div class="content-widget">
                    <div class="container">
                        <div class="row justify-content-between post-has-bg ml-0 mr-0">
                            <div class="col-lg-6 col-md-8">
                                <div class="pt-5 pb-5 pl-md-5 pr-5 align-self-center">
                                    <div class="capsSubtle mb-2">Editors' Pick</div>
                                    <h2 class="entry-title mb-3"><a href="<?= $domain; ?>/single?post=<?= $recentPostObjs[$postOftheMonth]['post_slug']; ?>"><?= $recentPostObjs[$postOftheMonth]['post_title']; ?></a></h2>
                                    <div class="entry-excerpt">
                                        <p><?= $recentPostObjs[$postOftheMonth]['post_summary']; ?></p>
                                    </div>
                                    <div class="entry-meta align-items-center">
                                        <a href="#"><?= $author_name; ?></a><br>
                                        <span><?= $recentPostObjs[$postOftheMonth]['post_date']; ?></span>
                                        <span class="middotDivider"></span>
                                        <span class="readingTime" title="5 min read">5 min read</span>
                                        <span class="svgIcon svgIcon--star">
                                            <svg class="svgIcon-use" width="15" height="15">
                                                <path d="M7.438 2.324c.034-.099.09-.099.123 0l1.2 3.53a.29.29 0 0 0 .26.19h3.884c.11 0 .127.049.038.111L9.8 8.327a.271.271 0 0 0-.099.291l1.2 3.53c.034.1-.011.131-.098.069l-3.142-2.18a.303.303 0 0 0-.32 0l-3.145 2.182c-.087.06-.132.03-.099-.068l1.2-3.53a.271.271 0 0 0-.098-.292L2.056 6.146c-.087-.06-.071-.112.038-.112h3.884a.29.29 0 0 0 .26-.19l1.2-3.52z"></path>
                                            </svg>
                                        </span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6 col-md-4 bgcover d-none d-md-block pl-md-0 ml-0" style="background-image:url(<?= $recentPostObjs[$postOftheMonth]['post_image']; ?>);"></div>
                        </div>
                        <div class="divider"></div>
                    </div>
                </div> <!--content-widget-->
                <?php endif ?>

                <div class="content-widget">
                    <div class="container">
                        <div class="row justify-content-between">
                            <?php foreach($recentPostObjs as $loop_postObj): ?>
                            <article class="col-md-6 mb-5">
                                <div class="mb-3 d-flex row">
                                    <figure class="col-md-5"><a href="<?= $domain; ?>/single?post=<?= $loop_postObj['post_slug']; ?>"><img src="<?= $loop_postObj['post_image']; ?>" alt="post-title"></a></figure>
                                    <div class="entry-content col-md-7 pl-md-0">
                                        <h5 class="entry-title mb-3"><a href="<?= $domain; ?>/single?post=<?= $loop_postObj['post_slug']; ?>"><?= $loop_postObj['post_title']; ?></a></h5>
                                        <div class="entry-excerpt">
                                            <p><?= $loop_postObj['post_summary']; ?></p>
                                        </div>
                                        <div class="entry-meta align-items-center">
                                            <a href="#"><?= $author_name; ?></a><br>
                                            <span><?= $loop_postObj['post_date']; ?></span>
                                            <span class="middotDivider"></span>
                                            <span class="readingTime" title="3 min read">4 min read</span>
                                            <span class="svgIcon svgIcon--star">
                                                <svg class="svgIcon-use" width="15" height="15">
                                                    <path d="M7.438 2.324c.034-.099.09-.099.123 0l1.2 3.53a.29.29 0 0 0 .26.19h3.884c.11 0 .127.049.038.111L9.8 8.327a.271.271 0 0 0-.099.291l1.2 3.53c.034.1-.011.131-.098.069l-3.142-2.18a.303.303 0 0 0-.32 0l-3.145 2.182c-.087.06-.132.03-.099-.068l1.2-3.53a.271.271 0 0 0-.098-.292L2.056 6.146c-.087-.06-.071-.112.038-.112h3.884a.29.29 0 0 0 .26-.19l1.2-3.52z"></path>
                                                </svg>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </article>
                            <?php endforeach ?>
                        </div>
                        <div class="divider-2"></div>
                    </div>
                </div> <!--content-widget-->

            </main>
            
            <?php include('partials/footer-2.php'); ?>
        </div>
        
        <?php include('partials/footer.php'); ?>
    </body>
</html>