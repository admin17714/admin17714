<?php
include(dirname(__FILE__).'/../includes/config.php');

# Validate Archive Name
if(!isset($_GET['category']) || empty($_GET['category'])) { aexit('direct_access'); }
$post_category = ucfirst($_GET['category']);

# Get Post Data
$postObjs = getPosts($pdoObj, 'post_category', $post_category);
$postOftheMonth = array_rand($postObjs, 1);

# Close Database Connection
$pdoObj=null;
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <?php include('../partials/header.php'); ?>
        <title>News Archives for <?= $post_category; ?> - <?= $website_name; ?></title>
    </head>

    <body class="archive">
        <?php include('../partials/nav-2.php'); ?>

        <div id="wrapper">

            <?php include('../partials/nav.php'); ?>
            
            <main id="content">
                <div class="content-widget">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-12">
                                <h4 class="spanborder">
                                    <span>Showing posts from <?= $post_category; ?></span>
                                </h4>

                                <?php if(isset($postObjs[$postOftheMonth])) : ?>
                                <article class="first mb-3">
                                    <figure><a href="<?= $domain; ?>/single?post=<?= $postObjs[$postOftheMonth]['post_slug']; ?>"><img src="<?= $postObjs[$postOftheMonth]['post_image']; ?>" alt="post-title"></a></figure>
                                    <h1 class="entry-title mb-3"><a href="<?= $domain; ?>/single?post=<?= $postObjs[$postOftheMonth]['post_slug']; ?>"><?= $postObjs[$postOftheMonth]['post_title']; ?></a></h1>
                                    <div class="entry-excerpt">
                                        <p><?= $postObjs[$postOftheMonth]['post_summary']; ?></p>
                                    </div>
                                    <div class="entry-meta align-items-center">
                                        <a class="author-avatar" href="#"><img src="<?= $domain; ?>/assets/frontend/avatar.jpg" alt=""></a>
                                        <a href="#"><?= $author_name; ?></a><br>
                                        <span><?= $postObjs[$postOftheMonth]['post_date']; ?></span>
                                        <span class="middotDivider"></span>
                                        <span class="readingTime" title="3 min read">3 min read</span>
                                        <span class="svgIcon svgIcon--star">
                                            <svg class="svgIcon-use" width="15" height="15">
                                                <path d="M7.438 2.324c.034-.099.09-.099.123 0l1.2 3.53a.29.29 0 0 0 .26.19h3.884c.11 0 .127.049.038.111L9.8 8.327a.271.271 0 0 0-.099.291l1.2 3.53c.034.1-.011.131-.098.069l-3.142-2.18a.303.303 0 0 0-.32 0l-3.145 2.182c-.087.06-.132.03-.099-.068l1.2-3.53a.271.271 0 0 0-.098-.292L2.056 6.146c-.087-.06-.071-.112.038-.112h3.884a.29.29 0 0 0 .26-.19l1.2-3.52z"></path>
                                            </svg>
                                        </span>
                                    </div>
                                </article>
                                <div class="divider"></div>
                                <?php endif ?>
                                
                                <?php foreach($postObjs as $loop_postObj) : ?>
                                <article class="row justify-content-between mb-5 mr-0">
                                    <div class="col-md-9 ">
                                        <div class="align-self-center">
                                            <h3 class="entry-title mb-3"><a href="<?= $domain; ?>/single?post=<?= $loop_postObj['post_slug']; ?>"><?= $loop_postObj['post_title']; ?></a></h3>
                                            <div class="entry-excerpt">
                                                <p><?= $loop_postObj['post_summary']; ?></p>
                                            </div>
                                            <div class="entry-meta align-items-center">
                                                <a href="#"><?= $author_name; ?></a><br>
                                                <span><?= $loop_postObj['post_date']; ?></span>
                                                <span class="middotDivider"></span>
                                                <span class="readingTime" title="3 min read">5 min read</span>
                                                <span class="svgIcon svgIcon--star">
                                                    <svg class="svgIcon-use" width="15" height="15">
                                                        <path d="M7.438 2.324c.034-.099.09-.099.123 0l1.2 3.53a.29.29 0 0 0 .26.19h3.884c.11 0 .127.049.038.111L9.8 8.327a.271.271 0 0 0-.099.291l1.2 3.53c.034.1-.011.131-.098.069l-3.142-2.18a.303.303 0 0 0-.32 0l-3.145 2.182c-.087.06-.132.03-.099-.068l1.2-3.53a.271.271 0 0 0-.098-.292L2.056 6.146c-.087-.06-.071-.112.038-.112h3.884a.29.29 0 0 0 .26-.19l1.2-3.52z"></path>
                                                    </svg>
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-3 bgcover" style="background-image:url(<?= $loop_postObj['post_image']; ?>);"></div>
                                </article>
                                <?php endforeach ?>
                            </div>
                        </div>
                    </div>
                </div>

            </main>

            <?php include('../partials/footer-2.php'); ?>
        </div>

        <?php include('../partials/footer.php'); ?>
    </body>
</html>