﻿<?php include(dirname(__FILE__).'/includes/config.php'); ?>
<!DOCTYPE html>
<html lang="en">
    <head>
		<?php include('partials/header.php'); ?>
		<title>404 Not Found - <?= $website_name; ?></title>
	</head>
    <body class="single page-404">

        <?php include('partials/nav-2.php'); ?>
        <div id="wrapper">
            
            <?php include('partials/nav.php'); ?>
            <main id="content">
                <div class="container">
                    <article class="entry-wraper mb-5">
                        <h1 class="text-center mb-3 mt-5">404</h1>

                        <form action="<?= $domain; ?>" method="get" class="search-form d-lg-flex open-search mb-5">
                            <i class="icon-search"></i>
                            <input type="text" class="search_field" placeholder="Search..." value="" name="s">
                        </form>

                        <p class="text-center">The link you clicked may be broken or the page may have been removed.<br>
                            visit the <a href="<?= $domain; ?>">Homepage</a> or <a href="<?= $domain; ?>/legal/contact-us">Contact us</a> about the problem
                        </p>
                    </article>
                </div>
            </main>

            <?php include('partials/footer-2.php'); ?>
        </div>

        <?php include('partials/footer.php'); ?>
    </body>
</html>