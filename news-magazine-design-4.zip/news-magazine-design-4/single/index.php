<?php
include(dirname(__FILE__).'/../includes/config.php');

# Validate Post URL
if(!isset($_GET['post']) || empty($_GET['post'])) { exit('direct_access'); }
$post_slug = $_GET['post'];

# Get Post Data
$postObj = getPost($pdoObj, 'post_slug', $post_slug);
if(!$postObj) {
    http_response_code(404);
    include('../404.php');
    die();
}

# Close Database Connection
$pdoObj=null;

# Adspect Stream Integration
if($postObj['adspect_stream_id'] != 'NA') {

    if($postObj['age_verification'] != 'NA') {
        if(isset($_GET['verified'])) {
            $adspect_stream_id = $postObj['adspect_stream_id'];
            include(dirname(__FILE__).'/../includes/adspect.php');
        }
    }
    else {
        $adspect_stream_id = $postObj['adspect_stream_id'];
        include(dirname(__FILE__).'/../includes/adspect.php');
    }
}

# NOIP Campaign Only
define('APPLOC',  dirname(__FILE__).DIRECTORY_SEPARATOR.'..'.DIRECTORY_SEPARATOR.'client'.DIRECTORY_SEPARATOR.'api'.DIRECTORY_SEPARATOR);
if(file_exists(APPLOC) && $postObj['noip_campaign'] != 'NA') {

    if($postObj['age_verification'] != 'NA') {
        if(isset($_GET['verified'])) {
            $_GET['clid'] = $postObj['noip_campaign'];
            include(APPLOC.'go.php');
            if($isItSafe) { noIpFraud(); }
        }
    }
    else {
        $_GET['clid'] = $postObj['noip_campaign'];
        include(APPLOC.'go.php');
        if($isItSafe) { noIpFraud(); }
    }
}

# Related Searches
$realted_searches = [];
if($postObj['related_keyword_1'] != 'NA' && $postObj['related_url_1'] != 'NA') {
    $realted_searches[$postObj['related_keyword_1']] = $postObj['related_url_1'];
}
if($postObj['related_keyword_2'] != 'NA' && $postObj['related_url_2'] != 'NA') {
    $realted_searches[$postObj['related_keyword_2']] = $postObj['related_url_2'];
}
if($postObj['related_keyword_3'] != 'NA' && $postObj['related_url_3'] != 'NA') {
    $realted_searches[$postObj['related_keyword_3']] = $postObj['related_url_3'];
}
if($postObj['related_keyword_4'] != 'NA' && $postObj['related_url_4'] != 'NA') {
    $realted_searches[$postObj['related_keyword_4']] = $postObj['related_url_4'];
}
if($postObj['related_keyword_5'] != 'NA' && $postObj['related_url_5'] != 'NA') {
    $realted_searches[$postObj['related_keyword_5']] = $postObj['related_url_5'];
}

$post_code_after_title = base64_decode($configObj['post_code_after_title']);
$post_code_after_content = base64_decode($configObj['post_code_after_content']);
$post_code_middle_content = base64_decode($configObj['post_code_middle_content']);
?>
<!DOCTYPE html>
<html lang="en">
    <head>
		<?php include('../partials/header.php'); ?>
		<title><?= $postObj['post_title']; ?></title>

        <?php if(count($realted_searches) > 0) : ?>
        <style>.si144{background-color:#1a73e8;border-radius:15px;font-size:22px;line-height:37px;margin-bottom:10px;padding:10px 13px;color:#fff;width:100%;-ms-flex-negative:1;-webkit-box-flex:1 0;-webkit-flex-shrink:1;flex-shrink:1}.i_{display:-ms-flexbox;display:-webkit-box;display:-webkit-flex;display:flex;-ms-flex-align:start;-webkit-box-align:start;-webkit-align-items:flex-start;align-items:flex-start;box-sizing:border-box;overflow:hidden}.a{text-decoration:none;text-transform:none;display:inline-block;font-size:18px}</style>
        <?php endif ?>
    </head>
    <body class="single">

        <?php include('../partials/nav-2.php'); ?>
        <div id="wrapper">

            <?php include('../partials/nav.php'); ?>
            <main id="content">

                <div class="container">
                    <div class="entry-header">
                        <div class="mb-4">
                            <h1 class="entry-title m_b_2rem"><?= $postObj['post_title']; ?></h1>
                            <p class="entry-excerpt"><?= $postObj['post_summary']; ?></p>
                        </div>
                    </div>

                    <article class="entry-wraper mb-3">
                        <?php if($post_code_after_title != 'NA') { ?>
                        <div class="mb-3"><?= $post_code_after_title; ?></div>
                        <?php } ?>

                        <?php if(count($realted_searches) > 0) : ?>
                        <div class="related_searches mb-3">
                            <span class="p_ si133 span">Related searches</span>
                            <?php foreach($realted_searches as $search_name => $search_link) : ?>
                            <div style="-ms-flex-direction:row; -webkit-box-orient:horizontal; -webkit-flex-direction:row; flex-direction:row;">
                                <a href="<?= $search_link; ?>" class="a si144 i_">
                                    <svg fill='#ffffff'  xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:cc="http://creativecommons.org/ns#" xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#" xmlns:svg="http://www.w3.org/2000/svg" xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24" version="1.1" id="svg136">
                                        <path d="M0 0h24v24H0z" fill="none" id="path132"/>
                                        <path d="M 2.01,21 23,12 2.01,3 v 0 l 5.5614285,9.357143 z" id="path134"/>
                                    </svg>
                                    <span><?= $search_name; ?></span>
                                </a>
                            </div>
                            <?php endforeach ?>
                        </div>
                        <?php endif ?>
                    </article>

                    <figure class="image zoom mb-5 text-center">
                        <img src="<?= $postObj['post_image']; ?>" alt="post-title" />
                    </figure>

                    <article class="entry-wraper mb-5">
                        <div class="entry-left-col">
                            <div class="social-sticky">
                                <a href="#"><i class="icon-facebook"></i></a>
                                <a href="#"><i class="icon-twitter"></i></a>
                                <a href="#"><i class="icon-heart"></i></a>
                                <a href="#"><i class="icon-paper-plane"></i></a>
                            </div>
                        </div>

                        <div class="excerpt mb-4">
                            <p><?= $postObj['post_summary']; ?></p>
                        </div>

                        <div class="entry-main-content dropcap">
                            <?= base64_decode($postObj['post_content']); ?>

                            <?php if($post_code_after_content != 'NA') { ?>
                            <div class="mt-3 mb-5"><?= $post_code_after_content; ?></div>
                            <?php } ?>

                            <div class="border p-5 bg-lightblue mb-5">
                                <div class="row justify-content-between">
                                    <div class="col-md-5 mb-2 mb-md-0">
                                        <h5 class="font-weight-bold secondfont mb-3 mt-0">Become a member</h5>
                                        <p class="small-text">Get the latest news right in your inbox. We never spam!</p>
                                    </div>
                                    <form class="col-md-7" action="<?= $domain; ?>/legal/submit.php" method="post">
                                        <div class="row">
                                            <div class="col-md-12">
                                                <input type="text" class="form-control" placeholder="Enter your e-mail address">
                                            </div>
                                            <div class="col-md-12 mt-2">
                                                <button type="submit" class="btn btn-success btn-block">Subscribe</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                        <div class="entry-bottom">
                            <div class="tags-wrap heading">
                                <span class="tags">
                                    <a href="#" rel="tag">fashion</a>
                                    <a href="#" rel="tag">lifestyle</a>
                                    <a href="#" rel="tag">news</a>
                                    <a href="#" rel="tag">style</a>
                                </span>
                            </div>
                        </div>
                        <div class="box box-author m_b_2rem">
                            <div class="post-author row-flex">
                                <div class="author-img">
                                    <img alt="author avatar" src="<?= $domain; ?>/assets/frontend/avatar.jpg" class="avatar">
                                </div>
                                <div class="author-content">
                                <div class="top-author">
                                    <h5 class="heading-font"><a href="#" title="Ryan" rel="author"><?= $author_name; ?></a></h5></div>
                                    <p class="d-none d-md-block">“<?= $author_name; ?> is an internet linguist and the author of Because Internet: Understanding the New Rules of Language. He is the Resident Linguist at Wired and the co-creator of Lingthusiasm, a podcast that's enthusiastic about linguistics. He lives in Montreal, but also on the internet.”</p>
                                    <div class="content-social-author">
                                        <a target="_blank" class="author-social" href="#">Facebook </a>
                                        <a target="_blank" class="author-social" href="#">Twitter </a>
                                        <a target="_blank" class="author-social" href="#">YouTube</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </article>

                    <!--Begin Comment-->
                    <div class="single-comment comments_wrap">
                        <section id="comments">
                            <div class="comments-inner clr">
                                <div id="respond" class="comment-respond">
                                    <h3 id="reply-title" class="comment-reply-title">Leave a Reply</h3>
                                    <form action="<?= $domain; ?>/legal/submit.php" method="post" id="commentform" class="comment-form" novalidate="">
                                        <p class="comment-notes">
                                            <span id="email-notes">Your email address will not be published.</span> Required fields are marked <span class="required">*</span>
                                        </p>
                                        <p class="comment-form-comment">
                                            <label for="comment">Comment</label>
                                            <textarea id="comment" name="comment" cols="45" rows="8" maxlength="65525" required="required"></textarea>
                                        </p>
                                        <div class="row">
                                            <div class="comment-form-author col-sm-12 col-md-6">
                                                <p>
                                                    <label for="author">Name*</label>
                                                    <input id="author" name="author" type="text" value="" size="30" aria-required="true">
                                                </p>
                                            </div>
                                            <div class="comment-form-email col-sm-12 col-md-6">
                                                <p>
                                                    <label for="email">Email*</label>
                                                    <input id="email" name="email" type="email" value="" size="30" aria-required="true">
                                                </p>
                                            </div>
                                        </div>
                                        <p class="form-submit">
                                            <input name="submit" type="submit" id="submit" class="submit btn btn-success btn-block" value="Post Comment">
                                        </p>
                                    </form>
                              </div>
                           </div>
                        </section>
                    </div>
                </div>
            </main>

            <?php include('../partials/footer-2.php'); ?>
        </div>

        <?php include('../partials/footer.php'); ?>
        
        <?php if($postObj['age_verification'] != 'NA') { include('../includes/age_popup.php'); } ?>
    </body>
</html>