<div class="top-scroll-bar"></div>
<div class="sticky-header fixed d-lg-none d-md-block">
    <div class="text-right">
        <div class="container mobile-menu-fixed pr-5">
            <h1 class="logo-small navbar-brand"><a href="<?= $domain; ?>/" class="logo"><?= $website_name; ?></a></h1>

            <a class="author-avatar" href="#"><img src="<?= $domain; ?>/assets/frontend/avatar.jpg" alt="avatar"></a>

            <ul class="social-network heading navbar-nav d-lg-flex align-items-center">
                <li><a href="#"><i class="icon-facebook"></i></a></li>
                <li><a href="#"><i class="icon-instagram"></i></a></li>
            </ul>

            <a href="javascript:void(0)" class="menu-toggle-icon">
                <span class="lines"></span>
            </a>
        </div>
    </div>

    <div class="mobi-menu">
        <div class="mobi-menu__logo">
            <h1 class="logo navbar-brand"><a href="<?= $domain; ?>/" class="logo"><?= $website_name; ?></a></h1>
        </div>
        <nav>
            <ul>
                <li class="current-menu-item"><a href="<?= $domain; ?>/">Home</a></li>
                <li><a href="<?= $domain; ?>/archive?category=celebrities">Celebrities</a></li>
                <li><a href="<?= $domain; ?>/archive?category=travel">Travel</a></li>
                <li><a href="<?= $domain; ?>/archive?category=lifestyle">Lifestyle</a></li>
                <li><a href="<?= $domain; ?>/archive?category=fitness">Fitness</a></li>
                <li><a href="<?= $domain; ?>/archive?category=business">Business</a></li>
            </ul>
        </nav>
    </div>
</div>