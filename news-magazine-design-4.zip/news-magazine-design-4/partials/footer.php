<a href="#" class="back-to-top heading"><i class="icon-left-open-big"></i><span  class="d-lg-inline d-md-none">Top</span></a>

<!--Scripts-->
<script src="<?= $domain; ?>/assets/frontend/js/jquery.min.js"></script>
<script src="<?= $domain; ?>/assets/frontend/js/bootstrap.js"></script>
<script src="<?= $domain; ?>/assets/frontend/js/jquery-scrolltofixed-min.js"></script>
<script src="<?= $domain; ?>/assets/frontend/js/theia-sticky-sidebar.js"></script>
<script src="<?= $domain; ?>/assets/frontend/js/scripts.js"></script>