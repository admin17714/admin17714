<footer class="mt-5">
    <div class="container">
        <div class="divider"></div>
        <div class="row">
            <div class="col-md-6 copyright text-xs-center">
                <p>&copy; 2025 <?= $website_name; ?>. All rights reserved.</p>
            </div>
            <div class="col-md-6">
                <ul class="inline text-md-right text-sm-center">
					<li class="list-inline-item">
						<a class="text-link" href="<?= $domain; ?>/legal/contact-us">Contact us</a>
					</li>
					<li class="list-inline-item">
						<a class='text-link' href='<?= $domain; ?>/legal/privacy-policy'>Privacy</a>
					</li>
					<li class="list-inline-item">
						<a class='text-link' href='<?= $domain; ?>/legal/terms-service'>Terms</a>
					</li>
					<li class="list-inline-item">
						<a class='text-link' href='<?= $domain; ?>/legal/cppa-form'>Data Privacy</a>
					</li>
				</ul>
            </div>
        </div>
    </div>
</footer>