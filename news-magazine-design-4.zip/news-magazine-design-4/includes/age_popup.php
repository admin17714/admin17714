<?php if(!isset($_GET['verified'])) { ?>
<?php $site_url = $_SERVER['REQUEST_URI']; ?>
<script>
	function ageVerify(decision) {
		window.location.href = "<?= $domain.$site_url; ?>&verified="+decision;
	}
</script>
<div class="modal fade" id="ageConfirmation" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="ageConfirmationLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-body p-4 text-center">
				<div class="mt-2">
					<h2 class="mb-2">Welcome to our site</h2>
					<p class="lead pb-3">Please verify your age to enter</p>
				</div>
				<div class="flex mt-2">
					<button type="buttton" onClick="ageVerify('true')" class="btn btn-dark me-3">I AM OVER 18</button>
					<button type="buttton" onClick="ageVerify('false')" class="btn btn-light">I AM UNDER 18</button>
				</div>
			</div>
        </div>
    </div>
</div>
<script>var myModal = new bootstrap.Modal(document.getElementById('ageConfirmation'),{keyboard:false, focus:true}); myModal.show();</script>
<?php } ?>