<?php
function connectDb() {
    try {
        $db_path = dirname(__FILE__).DIRECTORY_SEPARATOR.'posts.db';
        $pdoObj = new \PDO("sqlite:".$db_path);
        $pdoObj->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        # echo "Opened database successfully\n";
        return $pdoObj;
    }
    catch (\PDOException $ex) {
        # var_dump($ex->getMessage());
        return false;
    }
}

function insertPost($pdoObj, $data) {

    try {
        $post_data = "post_date, post_title, post_slug, post_summary, post_image, post_category, post_content";
        $noip_and_age_verfication = "noip_campaign, age_verification_url";
        $related_searches = "related_keyword_1, related_url_1, related_keyword_2, related_url_2, related_keyword_3, related_url_3, related_keyword_4, related_url_4, related_keyword_5, related_url_5";

        $stmt = $pdoObj->prepare("INSERT INTO tbl_posts (".$post_data.", ".$noip_and_age_verfication.", ".$related_searches.") VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
        
        $pdoObj->beginTransaction();
        $stmt->execute([
            $data['post_date'], $data['post_title'], $data['post_slug'], $data['post_summary'], $data['post_image'], $data['post_category'], base64_encode($data['post_content']),
            $data['noip_campaign'], $data['age_verification_url'],
            $data['related_keyword_1'], $data['related_url_1'], $data['related_keyword_2'], $data['related_url_2'], $data['related_keyword_3'], $data['related_url_3'], $data['related_keyword_4'], $data['related_url_4'], $data['related_keyword_5'], $data['related_url_5']
        ]);

        $pdoObj->commit();

        return $pdoObj->lastInsertId();
    }
    catch(\PDOExecption $ex) {

        $pdoObj->rollback();
        # var_dump($ex->getMessage());
        return false;
    }
}
function updatePost($pdoObj, $data, $post_id) {

    try {
        $post_data = "post_date=?, post_title=?, post_slug=?, post_summary=?, post_image=?, post_category=?, post_content=?";
        $noip_and_age_verfication = "noip_campaign=?, age_verification_url=?";
        $related_searches = "related_keyword_1=?, related_url_1=?, related_keyword_2=?, related_url_2=?, related_keyword_3=?, related_url_3=?, related_keyword_4=?, related_url_4=?, related_keyword_5=?, related_url_5=?";

        $stmt = $pdoObj->prepare("UPDATE tbl_posts SET ".$post_data.", ".$noip_and_age_verfication.", ".$related_searches." WHERE post_id=?");
        
        $pdoObj->beginTransaction();
        $stmt->execute([
            $data['post_date'], $data['post_title'], $data['post_slug'], $data['post_summary'], $data['post_image'], $data['post_category'], base64_encode($data['post_content']),
            $data['noip_campaign'], $data['age_verification_url'],
            $data['related_keyword_1'], $data['related_url_1'], $data['related_keyword_2'], $data['related_url_2'], $data['related_keyword_3'], $data['related_url_3'], $data['related_keyword_4'], $data['related_url_4'], $data['related_keyword_5'], $data['related_url_5'],
        $post_id]);

        $pdoObj->commit();

        return true;
    }
    catch(\PDOExecption $ex) {

        $pdoObj->rollback();
        # var_dump($ex->getMessage());
        return false;
    }
}
function deletePost($pdoObj, $post_id) {

    try {
        $stmt = $pdoObj->prepare("DELETE FROM tbl_posts where post_id=?");
        $pdoObj->beginTransaction();
        $stmt->execute([$post_id]);
        $pdoObj->commit();

        return true;
    }
    catch(\PDOExecption $ex) {

        $pdoObj->rollback();
        # var_dump($ex->getMessage());
        return false;
    }
}
function getPost($pdoObj, $post_col, $post_val) {

    try {
        $stmt = $pdoObj->prepare("SELECT * FROM tbl_posts WHERE ".$post_col."=?");
        $stmt->execute([$post_val]);
        $postObj = $stmt->fetch();
        return $postObj;
    }
    catch(\PDOExecption $ex) {

        #var_dump($ex->getMessage());
        return false;
    }
}
function getPosts($pdoObj, $post_col, $post_val) {

    try {
        $stmt = $pdoObj->prepare("SELECT * FROM tbl_posts WHERE ".$post_col."=?");
        $stmt->execute([$post_val]);
        $postObj = $stmt->fetchAll(\PDO::FETCH_ASSOC);
        return $postObj;
    }
    catch(\PDOExecption $ex) {

        #var_dump($ex->getMessage());
        return false;
    }
}
function recentPosts($pdoObj, $limit=null) {

    try {
        if($limit) {
            $stmt = $pdoObj->prepare("SELECT post_id, post_slug, post_category, post_title, post_summary, post_image, post_date, noip_campaign, age_verification_url FROM tbl_posts ORDER BY post_id DESC LIMIT ?");
            $stmt->execute([$limit]);
        }
        else {
            $stmt = $pdoObj->prepare("SELECT post_id, post_slug, post_category, post_title, post_summary, post_image, post_date, noip_campaign, age_verification_url FROM tbl_posts ORDER BY post_id DESC");
            $stmt->execute();
        }
        $postObj = $stmt->fetchAll(\PDO::FETCH_ASSOC);
        return $postObj;
    }
    catch(\PDOExecption $ex) {

        #var_dump($ex->getMessage());
        return false;
    }
}
function getConfig($pdoObj) {

    try {
        $stmt = $pdoObj->prepare("SELECT * FROM tbl_config WHERE config_id=1");
        $stmt->execute();
        $configObj = $stmt->fetch();
        return $configObj;
    }
    catch(\PDOExecption $ex) {

        #var_dump($ex->getMessage());
        return false;
    }
}
function updateConfig($pdoObj, $data) {

    try {
        $stmt = $pdoObj->prepare("UPDATE tbl_config SET website_name=?, author_name=?, homepage_title=?, matamo_domain=?, matamo_site_id=? WHERE config_id=1");
        $pdoObj->beginTransaction();
        $stmt->execute([$data['website_name'], $data['author_name'], $data['homepage_title'], $data['matamo_domain'], $data['matamo_site_id']]);
        $pdoObj->commit();

        return true;
    }
    catch(\PDOExecption $ex) {

        $pdoObj->rollback();
        # var_dump($ex->getMessage());
        return false;
    }
}