<?php
include(dirname(__FILE__).'/../includes/config.php');

# Redirect to SignIn if Not LoggedIn
session_start();
if(!isset($_SESSION["is_loggedIn"]) || $_SESSION["is_loggedIn"] != 'mrtaxx@gmail.com') {
    header("Location: ".$domain."/signin");
}

# Rediret to Post List
header("Location: ".$domain."/backend/post-list.php");
?>