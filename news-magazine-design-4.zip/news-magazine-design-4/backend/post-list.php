<?php
include(dirname(__FILE__).'/../includes/config.php');

# Redirect to SignIn if Not LoggedIn
session_start();
if(!isset($_SESSION["is_loggedIn"]) || $_SESSION["is_loggedIn"] != 'mrtaxx@gmail.com') {
    header("Location: ".$domain."/signin");
}

# Delete Post
if($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] == 'delete' && isset($_POST['post_id']) && !empty($_POST['post_id'])) {

    $post_id = $_POST['post_id'];
    $deleteResult = deletePost($pdoObj, $post_id);
    if(!$deleteResult) {
        echo 'Error while deleting post, please go back'; exit();
    }
}

# Recet Posts
$recentPostObjs = recentPosts($pdoObj);

# Close Database Connection
$pdoObj=null;
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <?php include('partials/header.php'); ?>
        <title>All Posts - <?= $website_name; ?></title>
    </head>
    <body>
        <?php include('partials/nav.php'); ?>
        <main>
            <section class="py-4">
                <div class="container">
                    <div class="row pb-4">
                        <div class="col-12">
                            <!-- Title -->
                            <div class="d-sm-flex justify-content-sm-between align-items-center">
                                <h1 class="mb-2 mb-sm-0 h2">Post List
                                    <span class="badge bg-primary bg-opacity-10 text-primary"><?= count($recentPostObjs) ?></span>
                                </h1>
                                <a href="<?= $domain; ?>/backend/post-add.php" class="btn btn-sm btn-primary mb-0">
                                    <i class="bi bi-send-plus me-2"></i>Add a post
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-12">

                            <!-- Post list table START -->
                            <div class="card border bg-transparent rounded-3">
                                <!-- Card body START -->
                                <div class="card-body p-3">
                                    <!-- Post list table START -->
                                    <div class="table-responsive border-0">
                                        <table class="table align-middle p-4 mb-0 table-hover table-shrink">
                                            <!-- Table head -->
                                            <thead class="table-dark">
                                                <tr>
                                                    <th scope="col" class="border-0 rounded-start">Post Title</th>
                                                    <th scope="col" class="border-0">Adspect</th>
                                                    <th scope="col" class="border-0">NOIP</th>
                                                    <th scope="col" class="border-0">Adult</th>
                                                    <th scope="col" class="border-0 rounded-end">Action</th>
                                                </tr>
                                            </thead>
                                            <tbody class="border-top-0">
                                                <?php foreach($recentPostObjs as $loop_postObj): ?>
                                                <tr>
                                                    <td>
                                                        <h6 class="course-title mt-2 mt-md-0 mb-0">
                                                            <a href="<?= $domain; ?>/single?post=<?= $loop_postObj['post_slug']; ?>" target="_blank"><?= $loop_postObj['post_title']; ?></a>
                                                        </h6>
                                                    </td>
                                                    <td>
                                                        <?php if($loop_postObj['adspect_stream_id'] != 'NA') { ?><span class="badge bg-success bg-opacity-10 text-success mb-2">Yes</span>
                                                        <?php } else { ?><span class="badge bg-danger bg-opacity-10 text-danger mb-2">No</span> <?php } ?>
                                                    </td>
                                                    <td>
                                                        <?php if($loop_postObj['noip_campaign'] != 'NA') { ?><span class="badge bg-success bg-opacity-10 text-success mb-2">Yes</span>
                                                        <?php } else { ?><span class="badge bg-danger bg-opacity-10 text-danger mb-2">No</span> <?php } ?>
                                                    </td>
                                                    <td>
                                                        <?php if($loop_postObj['age_verification'] != 'NA') { ?><span class="badge bg-success bg-opacity-10 text-success mb-2">Yes</span>
                                                        <?php } else { ?><span class="badge bg-danger bg-opacity-10 text-danger mb-2">No</span> <?php } ?>
                                                    </td>
                                                    <td>
                                                        <div class="d-flex gap-2">
                                                            <form action="<?= $domain; ?>/backend/post-list.php" method="post" class="deleteForm">
                                                                <input type="hidden" name="action" value="delete" required/>
                                                                <input type="hidden" name="post_id" value="<?= $loop_postObj['post_id']; ?>" required/>
                                                                <button type="submit" class="btn btn-light btn-round mb-0" data-bs-toggle="tooltip" data-bs-placement="top" title="Delete"><i class="bi bi-x-circle-fill"></i></button>
                                                            </form>
                                                            <a href="<?= $domain; ?>/backend/post-edit.php?post_id=<?= $loop_postObj['post_id']; ?>" class="btn btn-light btn-round mb-0" data-bs-toggle="tooltip" data-bs-placement="top" title="Edit"><i class="bi bi-wrench-adjustable"></i></a>
                                                        </div>
                                                    </td>
                                                </tr>
                                                <?php endforeach ?>
                                            </tbody>
                                        </table>
                                    </div>
                                    <!-- Post list table END -->
                                </div>
                            </div>
                            <!-- Post list table END -->
                        </div>
                    </div>
                </div>
            </section>
        </main>
        <?php include('partials/footer.php'); ?>
        <script>
            Array.from(document.getElementsByClassName("deleteForm")).forEach(element => {
                element.addEventListener("submit", function(event) {
                    if(!confirm("Are you sure want to delete ?")) { event.preventDefault(); }
                });
            });
        </script>
    </body>
</html>