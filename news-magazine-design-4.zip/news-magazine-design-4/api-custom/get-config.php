<?php
# Validate Token and Parameter
if(!isset($_SERVER['HTTP_X_SECRET_TOKEN']) || $_SERVER['HTTP_X_SECRET_TOKEN'] != 'gIUioNaOuaeaVF1k') {

    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['status' => 'failed', 'error' => 'Authentication Failed']);
    die();
}

include(dirname(__FILE__).'/../includes/config.php');

# Get Config Data
$configObj = getConfig($pdoObj);
if($configObj) {

    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['status' => 'success', 'data' => $configObj]);
}
else {
    
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['status' => 'failed', 'error' => 'No config data']);
}

$pdoObj=null;
die();