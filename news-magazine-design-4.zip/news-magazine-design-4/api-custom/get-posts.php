<?php
# Validate Token and Parameter
if(!isset($_SERVER['HTTP_X_SECRET_TOKEN']) || $_SERVER['HTTP_X_SECRET_TOKEN'] != 'gIUioNaOuaeaVF1k') {

    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['status' => 'failed', 'error' => 'Authentication Failed']);
    die();
}

include(dirname(__FILE__).'/../includes/config.php');


$recentPostObjs = recentPosts($pdoObj);
if($recentPostObjs) {
    
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['status' => 'success', 'data' => $recentPostObjs]);
}
else {
    
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['status' => 'success', 'error' => 'No Post Found']);
}

$pdoObj=null;
die();