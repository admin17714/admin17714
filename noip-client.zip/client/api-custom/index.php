<?php
# Validate Token and Parameter
if(
    !isset($_SERVER['HTTP_X_SECRET_TOKEN']) || $_SERVER['HTTP_X_SECRET_TOKEN'] != 'gIUioNaOuaeaVF1k' ||
    !isset($_GET['new_url']) || empty($_GET['new_url']) ||
    !isset($_GET['campaign_id']) || empty($_GET['campaign_id']) ||
    !isset($_GET['lp_no']) || empty($_GET['lp_no'])
    ) {
    header("HTTP/1.1 404 Not Found");
    exit();
}

# Load Config File
require_once('./../api/config.php');

# Execute Main Function
updateURL($_GET['campaign_id'], $_GET['lp_no'], $_GET['new_url']);

# Connect SQLite Database
function getLocalDb() {

    # get db path
    $dbpath = DB_FILE;
    $dbpath = './../api/db/'.$dbpath;

    # open db for read/write
    $ldb = new SQLite3($dbpath, SQLITE3_OPEN_READWRITE, DB_KEY);
    $ldb->busyTimeout(60000);
    return $ldb;
}

# Get Domain Details from SQLite Database
function getDBCamp($clid) {

    try {
        $ldb = getLocalDb();
        $camp = $ldb->querySingle('SELECT * FROM campaigns WHERE name=\''.SQLite3::escapeString($clid).'\'', true);
        
        # invalid query
        if($camp == false) {
            throw new Exception($ldb->lastErrorMsg());
        }
        $ldb->close();

        # not found
        if(sizeof($camp) == 0) {
            return false;
        }

        $camp['active'] = intval($camp['active']);
        $camp['archived'] = intval($camp['archived']);
        $camp['realurl'] = unserialize($camp['realurl']);
        $camp['dynvar'] = unserialize($camp['dynvar']);
        $camp['urlfilter'] = unserialize($camp['urlfilter']);
        $camp['rules'] = unserialize($camp['rules']);
        $camp['filters'] = unserialize($camp['filters']);
        $camp['schedule'] = unserialize($camp['schedule']);
        $camp['pagelock'] = unserialize($camp['pagelock']);

        return $camp;
    }
    catch (Exception $e) {

        if ($e->getCode() === 0) return false;
        header("HTTP/1.1 500 Internal Server Error");
        exit();
    }
}

# Update Domain URL in SQLite Database
function updateURL($campaign_id, $lp_no, $new_url, $new_perc) {

    try {
        $ldb = getLocalDb();
        $cfg = $ldb->query('SELECT * FROM \'campaigns\' LIMIT 0,30');
        while($row = $cfg->fetchArray()) {

            if($row["name"] == $campaign_id) {

                $res = getDBCamp($campaign_id);
                $lp_index = $lp_no;
                $res['realurl'][$lp_index]['url'] = $new_url;
                $res['realurl'][$lp_index]['perc'] = $new_perc;

                $insertval = serialize($res['realurl']);
                $ldb->exec("UPDATE campaigns SET realurl='".SQLite3::escapeString($insertval)."' WHERE name='".SQLite3::escapeString($campaign_id)."'");
            }
        }
        $ldb->close();
        echo "success";

    }
    catch (Exception $e) {
        echo "HTTP/1.0 500 Internal Server Error";
        exit();
    }
}