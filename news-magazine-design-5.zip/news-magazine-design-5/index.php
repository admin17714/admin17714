﻿
<?php
include(dirname(__FILE__).'/includes/config.php');

# Recet Posts
$recentPostObjs = recentPosts($pdoObj, 12);

# Close Database Connection
$pdoObj=null;
?>
<!DOCTYPE html>
<!--[if IE 8]><html class="ie" xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!-->
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US">
<!--<![endif]-->

<head>
    <?php include('partials/header.php'); ?>
    <title><?= $website_name; ?></title>
</head>

<body>
    <!-- wrapper -->
    <div id="wrapper">

        <?php include('partials/nav.php'); ?>

        <!-- section-categories -->
        <div class="section-categories sw-layout mt-5">
            <div class="tf-container w-xxl">
                <div class="heading-section d-flex justify-content-between mb_26">
                    <h3>Top Categories</h3>
                    <div class="wrap-sw-button d-flex gap_12 md-hide">
                        <div class="sw-button sz-56 v2 style-cycle nav-prev-layout">
                            <i class="icon-CaretLeft"></i>
                        </div>
                        <div class="sw-button sz-56 v2 style-cycle nav-next-layout ">
                            <i class="icon-CaretRight"></i>
                        </div>
                    </div>
                </div>
                <div class="swiper" data-screen-xl="6" data-preview="4" data-tablet="3" data-mobile="1"
                    data-mobile-sm="2" data-space-lg="20" data-space-md="20" data-space="15">
                    <div class="swiper-wrapper">
                        <div class="swiper-slide">
                            <div class="categoires-item hover-image">
                                <a href="#" class="img-style mb_17">
                                    <img class="lazyload" decoding="async" loading="lazy"
                                        src="<?= $domain; ?>/assets/images/sections/category-1.webp"
                                        srcset="<?= $domain; ?>/assets/images/sections/category-1.webp 212w"
                                        sizes="(max-width: 212px) 100vw, 212px" width="212" height="158"
                                        alt="feature post">
                                </a>
                                <div class="content">
                                    <h6 class="mb_2"><a href="#" class="link">Lifestyle</a></h6>
                                    <p class="text-caption-1">231 Posts</p>
                                </div>
                            </div>
                        </div>
                        <div class="swiper-slide">
                            <div class="categoires-item hover-image">
                                <a href="#" class="img-style mb_17">
                                    <img class="lazyload" decoding="async" loading="lazy"
                                        src="<?= $domain; ?>/assets/images/sections/category-2.webp"
                                        srcset="<?= $domain; ?>/assets/images/sections/category-2.webp 212w"
                                        sizes="(max-width: 212px) 100vw, 212px" width="212" height="158"
                                        alt="feature post">
                                </a>
                                <div class="content">
                                    <h6 class="mb_2"><a href="#" class="link">Home Decor</a></h6>
                                    <p class="text-caption-1">182 Posts</p>
                                </div>
                            </div>
                        </div>
                        <div class="swiper-slide">
                            <div class="categoires-item hover-image">
                                <a href="#" class="img-style mb_17">
                                    <img class="lazyload" decoding="async" loading="lazy"
                                        src="<?= $domain; ?>/assets/images/sections/category-3.webp"
                                        srcset="<?= $domain; ?>/assets/images/sections/category-3.webp 212w"
                                        sizes="(max-width: 212px) 100vw, 212px" width="212" height="158"
                                        alt="feature post">
                                </a>
                                <div class="content">
                                    <h6 class="mb_2"><a href="#" class="link">Food</a></h6>
                                    <p class="text-caption-1">124 Posts</p>
                                </div>
                            </div>
                        </div>
                        <div class="swiper-slide">
                            <div class="categoires-item hover-image">
                                <a href="#" class="img-style mb_17">
                                    <img class="lazyload" decoding="async" loading="lazy"
                                        src="<?= $domain; ?>/assets/images/sections/category-4.webp"
                                        srcset="<?= $domain; ?>/assets/images/sections/category-4.webp 212w"
                                        sizes="(max-width: 212px) 100vw, 212px" width="212" height="158"
                                        alt="feature post">
                                </a>
                                <div class="content">
                                    <h6 class="mb_2"><a href="#" class="link">Beauty</a></h6>
                                    <p class="text-caption-1">192 Posts</p>
                                </div>
                            </div>
                        </div>
                        <div class="swiper-slide">
                            <div class="categoires-item hover-image">
                                <a href="#" class="img-style mb_17">
                                    <img class="lazyload" decoding="async" loading="lazy"
                                        src="<?= $domain; ?>/assets/images/sections/category-5.webp"
                                        srcset="<?= $domain; ?>/assets/images/sections/category-5.webp 212w"
                                        sizes="(max-width: 212px) 100vw, 212px" width="212" height="158"
                                        alt="feature post">
                                </a>
                                <div class="content">
                                    <h6 class="mb_2"><a href="#" class="link">Healthy</a></h6>
                                    <p class="text-caption-1">241 Posts</p>
                                </div>
                            </div>
                        </div>
                        <div class="swiper-slide">
                            <div class="categoires-item hover-image">
                                <a href="#" class="img-style mb_17">
                                    <img class="lazyload" decoding="async" loading="lazy"
                                        src="<?= $domain; ?>/assets/images/sections/category-6.webp"
                                        srcset="<?= $domain; ?>/assets/images/sections/category-6.webp 212w"
                                        sizes="(max-width: 212px) 100vw, 212px" width="212" height="158"
                                        alt="feature post">
                                </a>
                                <div class="content">
                                    <h6 class="mb_2"><a href="#" class="link">Fashion</a></h6>
                                    <p class="text-caption-1">162 Posts</p>
                                </div>
                            </div>
                        </div>
                        <div class="swiper-slide">
                            <div class="categoires-item hover-image">
                                <a href="#" class="img-style mb_17">
                                    <img class="lazyload" decoding="async" loading="lazy"
                                        src="<?= $domain; ?>/assets/images/sections/category-7.webp"
                                        srcset="<?= $domain; ?>/assets/images/sections/category-7.webp 212w"
                                        sizes="(max-width: 212px) 100vw, 212px" width="212" height="158"
                                        alt="feature post">
                                </a>
                                <div class="content">
                                    <h6 class="mb_2"><a href="#" class="link">Lifestyle</a></h6>
                                    <p class="text-caption-1">231 Posts</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="sw-dots sw-pagination-layout mt_22 justify-content-center d-flex d-md-none">
                    </div>
                </div>
            </div>
        </div>
        <!-- /End section-categories -->
            
        <!-- page-title -->
        <div class="page-title homepage-2 sw-layout">
            <div class="tf-container w-xxl">

                <div class="row">
                    <div class="col-lg-9">
                        <!-- section-highlight -->
                        <div class="section-highlight-2">
                            <div class="tf-container w-xxl">
                                <div class="row">
                                    <div class="col-lg-12">
                                        <div class="left">
                                            <?php foreach($recentPostObjs as $loop_postObj): ?>
                                            <div class="feature-post-item style-list v3 style-border hover-image-translate">
                                                <div class="img-style">
                                                    <img loading="lazy" src="<?= $loop_postObj['post_image']; ?>" alt="feature post">
                                                    <a href="<?= $domain; ?>/archive?category=<?= strtolower($loop_postObj['post_category']); ?>" class="tag categories text-caption-2 text_white"><?= $loop_postObj['post_category']; ?></a>
                                                    <div class="tag time text-caption-2 text_white"><i class="icon-Timer"></i> 4 Mins read</div>
                                                    <a href="<?= $domain; ?>/single?post=<?= $loop_postObj['post_slug']; ?>" class="overlay-link"></a>
                                                </div>
                                                <div class="content">
                                                    <ul class="meta-feature fw-7 d-flex mb_12 text-caption-2 text-uppercase">
                                                        <li><?= $loop_postObj['post_date']; ?></li>
                                                        <li><span class="text_secodary2-color">POST BY</span> <a href="#" class="link"><?= $author_name; ?></a></li>
                                                    </ul>
                                                    <h4 class="title"> <a href="<?= $domain; ?>/single?post=<?= $loop_postObj['post_slug']; ?>" class="link line-clamp-2"><?= $loop_postObj['post_title']; ?></a></h4>
                                                    <p class="text-body-1 line-clamp-2"><?= $loop_postObj['post_summary']; ?></p>
                                                </div>
                                            </div>
                                            <?php endforeach ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- /End section-highlight -->
                    </div>
                    <div class="col-lg-3">
                        <div class="box-author style-1 v2 text-center">
                            <h5 class="heading-title">Wellcome To <?= $website_name; ?></h5>
                            <div class="info ">
                                <div class="avatar mb_12">
                                    <img src="<?= $domain; ?>/assets/images/avatar/main-avatar.jpg" alt="avatar">
                                </div>
                                <h4 class="mb_4"><a href="#" class="link"><?= $author_name; ?></a></h4>
                                <p class="text-body-1">Portland, Oregon, USA</p>
                            </div>
                            <ul class="social">
                                <li class="h6 fw-7 text_on-surface-color"><a href="#"
                                        class="d-flex align-items-center gap_12"><i class="icon-FacebookLogo"></i>23k Likes</a></li>
                                <li class="h6 fw-7 text_on-surface-color"><a href="#"
                                        class="d-flex align-items-center gap_12"><i class="icon-XLogo"></i>41k Follower</a></li>
                                <li class="h6 fw-7 text_on-surface-color"><a href="#"
                                        class="d-flex align-items-center gap_12"><i class="icon-PinterestLogo"></i>32k Follower</a></li>
                            </ul>
                            <p>Lifestyle blogger who writes about mindful living.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- /End page-title -->

        
        <div class="main-content">

            <!-- section-newsletter -->
            <div class="tf-container w-xxl ">
                <div class="newsletter-item style-1 d-flex justify-content-between">
                    <h3 class="title">Subscribe Now To Stay Updated With Top News!</h3>
                    <p class="description">Subscribe now to stay updated with all the top news, exclusive insights, and
                        weekly highlights
                        you won’t want to miss.</p>
                    <div class="form">
                        <form id="subscribe-form-2" method="post" accept-charset="utf-8" data-mailchimp="true"
                            action="<?= $domain; ?>/legal/submit.php" class="form-newslate mb_12">
                            <div id="subscribe-content-2" class="position-relative">
                                <fieldset class="fieldset-item">
                                    <input type="email" placeholder="E-mail" id="subscribe-email-2" aria-required="true"
                                        required>
                                </fieldset>
                                <div class="box-btn">
                                    <button id="subscribe-button-2" type="button" class="btn-submit animate-hover-btn">
                                        <span class="icon-PaperPlaneTilt"></span>
                                    </button>
                                </div>
                            </div>
                            <div id="subscribe-msg-2"></div>
                        </form>
                        <div class="box-fieldset-item d-flex ">
                            <fieldset class=" d-flex  gap_12">
                                <input type="checkbox" class="tf-check">
                            </fieldset>
                            <p class="text-body-1">By clicking the Subscribe button, you acknowledge that you have
                                read
                                and agree to our <a href="<?= $domain; ?>/legal/privacy-policy" class="text_on-surface-color link">Privacy
                                    Policy</a>
                                and <a href="<?= $domain; ?>/legal/terms-service" class="text_on-surface-color link">Terms Of Use</a></p>
                        </div>
                    </div>
                </div>
            </div>
            <!-- /End section-newsletter -->

            <!-- section-instagram -->
            <div class="section-instagram tf-spacing-3">
                <div class="tf-container w-xxl">
                    <div class="tf-grid-layout lg-col-5 md-col-4 tf-col-2">
                        <div class="ins-item">
                            <span class="icon-InstagramLogo icon"></span>
                            <h4 class="title">Follow Us On Instagram</h4>
                            <a href="#" class="hover-underline-link fw-7 text_on-surface-color text-body-1">Follow Us</a>
                        </div>
                        <div class="hover-image-translate">
                            <a href="#" class="img-style  rounded-16">
                                <img class="lazyload" decoding="async" loading="lazy" src="<?= $domain; ?>/assets/images/sections/ins-1.webp"
                                    srcset="<?= $domain; ?>/assets/images/sections/ins-1.webp 288w" sizes="(max-width: 288px) 100vw, 288px"
                                    width="288" height="288" alt="feature post">
                            </a>
                        </div>
                        <div class="hover-image-translate">
                            <a href="#" class="img-style rounded-16">
                                <img class="lazyload" decoding="async" loading="lazy" src="<?= $domain; ?>/assets/images/sections/ins-2.webp"
                                    srcset="<?= $domain; ?>/assets/images/sections/ins-2.webp 288w" sizes="(max-width: 288px) 100vw, 288px"
                                    width="288" height="288" alt="feature post">
                            </a>
                        </div>
                        <div class="hover-image-translate">
                            <a href="#" class="img-style rounded-16">
                                <img class="lazyload" decoding="async" loading="lazy" src="<?= $domain; ?>/assets/images/sections/ins-3.webp"
                                    srcset="<?= $domain; ?>/assets/images/sections/ins-3.webp 288w" sizes="(max-width: 288px) 100vw, 288px"
                                    width="288" height="288" alt="feature post">
                            </a>
                        </div>
                        <div class="hover-image-translate lg-hide">
                            <a href="#" class="img-style rounded-16">
                                <img class="lazyload" decoding="async" loading="lazy" src="<?= $domain; ?>/assets/images/sections/ins-4.webp"
                                    srcset="<?= $domain; ?>/assets/images/sections/ins-4.webp 288w" sizes="(max-width: 288px) 100vw, 288px"
                                    width="288" height="288" alt="feature post">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <!-- /End section-instagram -->

        </div>

        <?php include('partials/footer-2.php'); ?>

    </div>
    <!-- /wrapper -->

    <?php include('partials/nav-2.php'); ?>

    <?php include('partials/footer.php'); ?>
</body>

</html>