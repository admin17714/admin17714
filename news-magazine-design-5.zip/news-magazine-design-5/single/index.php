<?php
include(dirname(__FILE__).'/../includes/config.php');

# Validate Post URL
if(!isset($_GET['post']) || empty($_GET['post'])) { exit('direct_access'); }
$post_slug = $_GET['post'];

# Get Post Data
$postObj = getPost($pdoObj, 'post_slug', $post_slug);
if(!$postObj) {
    http_response_code(404);
    die();
}

# Close Database Connection
$pdoObj=null;

# Adspect Stream Integration
if($postObj['adspect_stream_id'] != 'NA') {

    if($postObj['age_verification'] != 'NA') {
        if(isset($_GET['verified'])) {
            $adspect_stream_id = $postObj['adspect_stream_id'];
            include(dirname(__FILE__).'/../includes/adspect.php');
        }
    }
    else {
        $adspect_stream_id = $postObj['adspect_stream_id'];
        include(dirname(__FILE__).'/../includes/adspect.php');
    }
}

# NOIP Campaign Only
define('APPLOC',  dirname(__FILE__).DIRECTORY_SEPARATOR.'..'.DIRECTORY_SEPARATOR.'client'.DIRECTORY_SEPARATOR.'api'.DIRECTORY_SEPARATOR);
if(file_exists(APPLOC) && $postObj['noip_campaign'] != 'NA') {

    if($postObj['age_verification'] != 'NA') {
        if(isset($_GET['verified'])) {
            $_GET['clid'] = $postObj['noip_campaign'];
            include(APPLOC.'go.php');
            if($isItSafe) { noIpFraud(); }
        }
    }
    else {
        $_GET['clid'] = $postObj['noip_campaign'];
        include(APPLOC.'go.php');
        if($isItSafe) { noIpFraud(); }
    }
}

# Related Searches
$realted_searches = [];
if($postObj['related_keyword_1'] != 'NA' && $postObj['related_url_1'] != 'NA') {
    $realted_searches[$postObj['related_keyword_1']] = $postObj['related_url_1'];
}
if($postObj['related_keyword_2'] != 'NA' && $postObj['related_url_2'] != 'NA') {
    $realted_searches[$postObj['related_keyword_2']] = $postObj['related_url_2'];
}
if($postObj['related_keyword_3'] != 'NA' && $postObj['related_url_3'] != 'NA') {
    $realted_searches[$postObj['related_keyword_3']] = $postObj['related_url_3'];
}
if($postObj['related_keyword_4'] != 'NA' && $postObj['related_url_4'] != 'NA') {
    $realted_searches[$postObj['related_keyword_4']] = $postObj['related_url_4'];
}
if($postObj['related_keyword_5'] != 'NA' && $postObj['related_url_5'] != 'NA') {
    $realted_searches[$postObj['related_keyword_5']] = $postObj['related_url_5'];
}

$post_code_after_title = base64_decode($configObj['post_code_after_title']);
$post_code_after_content = base64_decode($configObj['post_code_after_content']);
$post_code_middle_content = base64_decode($configObj['post_code_middle_content']);
?>
<!DOCTYPE html>
<!--[if IE 8]><html class="ie" xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!-->
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US">
<!--<![endif]-->

<head>
    <?php include('../partials/header.php'); ?>
	<title><?= $postObj['post_title']; ?></title>

    <?php if(count($realted_searches) > 0) : ?>
    <style>.si144{background-color:#1a73e8;border-radius:15px;font-size:22px;line-height:37px;margin-bottom:10px;padding:10px 13px;color:#fff;width:100%;-ms-flex-negative:1;-webkit-box-flex:1 0;-webkit-flex-shrink:1;flex-shrink:1}.i_{display:-ms-flexbox;display:-webkit-box;display:-webkit-flex;display:flex;-ms-flex-align:start;-webkit-box-align:start;-webkit-align-items:flex-start;align-items:flex-start;box-sizing:border-box;overflow:hidden}.a{text-decoration:none;text-transform:none;display:inline-block;font-size:18px}</style>
    <?php endif ?>
</head>

<body>
    <!-- wrapper -->
    <div id="wrapper">

        <?php include('../partials/nav.php'); ?>

        <!-- breadcrumb -->
        <div class="bg-surface2-color">
            <div class="tf-container">
                <ul class="breadcrumb text-caption-1 text_on-surface-color">
                    <li><a href="<?= $domain; ?>/" class="link">Home</a></li>
                    <li><?= $postObj['post_category']; ?></li>
                    <li><?= $postObj['post_title']; ?></li>
                </ul>
            </div>
        </div>
        <!-- End breadcrumb -->


        <!-- heading-post -->
        <div class="heading-post style-1">
            <div class="tf-container ">
                <div class="post-inner">
                    <div class="content ">
                        <div class="wrap-meta-feature d-flex align-items-center">
                            <span class="tag">
                                <a href="#" class="text-title text_white"><?= $postObj['post_category']; ?></a>
                            </span>
                            <ul class="meta-feature fw-7 d-flex mb_16 text-body-1 mb-0 align-items-center">
                                <li><?= $postObj['post_date']; ?></li>
                            </ul>
                        </div>
                        <h1 class="mb_20"><?= $postObj['post_title']; ?></h1>
                        <div class="user-post d-flex align-items-center  gap_20">
                            <div class="avatar ">
                                <img src="<?= $domain; ?>/assets/images/avatar/avatar-1.jpg" alt="avatar">
                            </div>
                            <p class="fw-7"><span class="text_secodary2-color">Post by</span> <a href="#" class="link"><?= $author_name; ?></a></p>
                        </div>
                    </div>
                    <div class="thumbs-post">
                        <img src="<?= $postObj['post_image']; ?>" alt="thumbs-main">
                    </div>
                </div>
            </div>
        </div>
        <!-- /End heading-post -->

        <div class="main-content">

            <!-- single-post -->
            <div class="single-post style-1">
                <div class="tf-container">
                    <div class="row">
                        <div class="col-lg-2 lg-hide">
                            <div class="share-bar style-1 text-center ">
                                <h5 class="mb_20">Share This Post</h5>
                                <ul class="d-grid gap_10">
                                    <li><a href="#"
                                            class="social-item d-flex align-items-center text-body-1 fw-7 gap_11 text_on-surface-color">
                                            <i class="icon-FacebookLogo"></i>Facebook
                                        </a></li>
                                    <li><a href="#"
                                            class="social-item d-flex align-items-center text-body-1 fw-7 gap_11 text_on-surface-color">
                                            <i class="icon-XLogo"></i>Twitter
                                        </a></li>
                                    <li><a href="#"
                                            class="social-item d-flex align-items-center text-body-1 fw-7 gap_11 text_on-surface-color">
                                            <i class="icon-InstagramLogo"></i>Instagram
                                        </a></li>
                                    <li><a href="#"
                                            class="social-item d-flex align-items-center text-body-1 fw-7 gap_11 text_on-surface-color">
                                            <i class="icon-PinterestLogo"></i>Pinterest
                                        </a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-lg-10">
                            <div class="content-inner">
                                <div class="wrap-post-details">
                                    <div class="post-details">
                                        <?php if($post_code_after_title != 'NA') { ?>
                                        <div class="mb-3"><?= $post_code_after_title; ?></div>
                                        <?php } ?>

                                        <?php if(count($realted_searches) > 0) : ?>
                                        <div class="related_searches mb-3">
                                            <span class="p_ si133 span">Related searches</span>
                                            <?php foreach($realted_searches as $search_name => $search_link) : ?>
                                            <div style="-ms-flex-direction:row; -webkit-box-orient:horizontal; -webkit-flex-direction:row; flex-direction:row;">
                                                <a href="<?= $search_link; ?>" class="a si144 i_">
                                                    <svg fill='#ffffff'  xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:cc="http://creativecommons.org/ns#" xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#" xmlns:svg="http://www.w3.org/2000/svg" xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24" version="1.1" id="svg136">
                                                        <path d="M0 0h24v24H0z" fill="none" id="path132"/>
                                                        <path d="M 2.01,21 23,12 2.01,3 v 0 l 5.5614285,9.357143 z" id="path134"/>
                                                    </svg>
                                                    <span><?= $search_name; ?></span>
                                                </a>
                                            </div>
                                            <?php endforeach ?>
                                        </div>
                                        <?php endif ?>

                                        <p class="mb_28"><?= $postObj['post_summary']; ?></p>
                                        <div class="passage mb_28">
                                            <?= base64_decode($postObj['post_content']); ?>
                                        </div>
                                        
                                        <?php if($post_code_after_content != 'NA') { ?>
                                        <div class="mt-3 mb-5"><?= $post_code_after_content; ?></div>
                                        <?php } ?>

                                        <div class="wrap-tag d-flex flex-wrap align-items-center gap_12 ">
                                            <span class="text-title text_on-surface-color fw-7">Tag:</span>
                                            <ul class="d-flex flex-wrap gap_12">
                                                <li><a href="#" class="tag text-caption-1">Fashion</a></li>
                                                <li><a href="#" class="tag text-caption-1">Technology</a></li>
                                                <li><a href="#" class="tag text-caption-1">Travel List</a></li>
                                            </ul>
                                        </div>
                                    </div>

                                    <div class="leave-comment">
                                        <div class="heading-title mb_41">
                                            <h4 class="mb_24">Leave A Comment</h4>
                                        </div>
                                        <form class="form-leave-comment" action="<?= $domain; ?>/legal/submit.php" method="post">
                                            <div class="wrap">
                                                <div class="tf-grid-layout md-col-2 mb_20">
                                                    <fieldset class="">
                                                        <input class="" type="text" placeholder="Your Name*" name="text"
                                                            tabindex="2" value="" aria-required="true" required="">
                                                    </fieldset>
                                                    <fieldset class="">
                                                        <input class="" type="email" placeholder="Your Email*"
                                                            name="email" tabindex="2" value="" aria-required="true"
                                                            required="">
                                                    </fieldset>
                                                </div>
                                                <fieldset class="mb_24">
                                                    <textarea class="" rows="4" placeholder="Your Email*" tabindex="2"
                                                        aria-required="true" required=""></textarea>
                                                </fieldset>
                                            </div>
                                            <div class="button-submit mt_49">
                                                <button class="tf-btn animate-hover-btn btn-switch-text " type="submit">
                                                    <span>
                                                        <span class="btn-double-text" data-text="Submit Review">Submit
                                                            Review</span>
                                                    </span>
                                                </button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                                <div class="sidebar">
                                    <div class="sidebar__item about text-center">
                                        <h5 class="sidebar__title ">About Write</h5>
                                        <div class="box-author style-1 sidebar__item">
                                            <div class="info text-center">
                                                <div class="avatar mb_30">
                                                    <img src="<?= $domain; ?>/assets/images/avatar/main-avatar.jpg" alt="avatar">
                                                </div>
                                                <h4 class="mb_4"><a href="#" class="link"><?= $author_name; ?></a></h4>
                                                <p class="text-body-1">Portland, Oregon, USA</p>
                                            </div>
                                            <ul class="social">
                                                <li class="text-title fw-7 text_on-surface-color"><a href="#"
                                                        class="d-flex align-items-center gap_12"><i
                                                            class="icon-FacebookLogo"></i>23k Likes</a></li>
                                                <li class="text-title fw-7 text_on-surface-color"><a href="#"
                                                        class="d-flex align-items-center gap_12"><i
                                                            class="icon-XLogo"></i>41k Follower</a></li>
                                                <li class="text-title fw-7 text_on-surface-color"><a href="#"
                                                        class="d-flex align-items-center gap_12"><i
                                                            class="icon-PinterestLogo"></i>32k Follower</a></li>
                                            </ul>
                                        </div>
                                    </div>

                                    <div class="sidebar__item">
                                        <h5 class="sidebar__title">
                                            Categories
                                        </h5>
                                        <ul class="sidebar-categories">
                                            <li class="item d-flex align-items-center justify-content-between">
                                                <a href="#"
                                                    class="fw-7 text-body-1 text_on-surface-color">
                                                    Colonial
                                                </a>
                                                <span class="number">10</span>
                                            </li>
                                            <li class="item d-flex align-items-center justify-content-between">
                                                <a href="#"
                                                    class="fw-7 text-body-1 text_on-surface-color">
                                                    Minimal
                                                </a>
                                                <span class="number">21</span>
                                            </li>
                                            <li class="item d-flex align-items-center justify-content-between">
                                                <a href="#"
                                                    class="fw-7 text-body-1 text_on-surface-color">
                                                    Craftsman
                                                </a>
                                                <span class="number">30</span>
                                            </li>
                                            <li class="item d-flex align-items-center justify-content-between">
                                                <a href="#"
                                                    class="fw-7 text-body-1 text_on-surface-color">
                                                    Modern
                                                </a>
                                                <span class="number">9</span>
                                            </li>
                                            <li class="item d-flex align-items-center justify-content-between">
                                                <a href="#"
                                                    class="fw-7 text-body-1 text_on-surface-color">
                                                    Creative
                                                </a>
                                                <span class="number">5</span>
                                            </li>
                                        </ul>
                                    </div>

                                    <div class="sidebar__item">
                                        <h5 class="sidebar__title">
                                            Popular Tag
                                        </h5>
                                        <ul class="list d-flex flex-wrap gap_11">
                                            <li class="tag text-caption-1"><a href="#">Breaking</a></li>
                                            <li class="tag text-caption-1"><a href="#">Fashion</a></li>
                                            <li class="tag text-caption-1"><a href="#">Technology</a>
                                            </li>
                                            <li class="tag text-caption-1"><a href="#">Sports</a></li>
                                            <li class="tag text-caption-1"><a href="#">Adventure</a>
                                            </li>
                                            <li class="tag text-caption-1"><a href="#">Travel List</a>
                                            </li>
                                            <li class="tag text-caption-1"><a href="#">Life Style</a>
                                            </li>
                                            <li class="tag text-caption-1"><a href="#">Popular Post</a>
                                            </li>
                                            <li class="tag text-caption-1"><a href="#">Life Style</a>
                                            </li>
                                            <li class="tag text-caption-1"><a href="#">Mussic</a></li>
                                            <li class="tag text-caption-1"><a href="#">Trending</a></li>
                                            <li class="tag text-caption-1"><a href="#">Entertaiment</a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- /End single-post -->

        </div>

        <?php include('../partials/footer-2.php'); ?>
    </div>
    <!-- /wrapper -->

    <?php include('../partials/nav-2.php'); ?>

    <?php include('../partials/footer.php'); ?>    
    <?php if($postObj['age_verification'] != 'NA') { include('../includes/age_popup.php'); } ?>
</body>

</html>