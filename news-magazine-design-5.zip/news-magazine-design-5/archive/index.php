<?php
include(dirname(__FILE__).'/../includes/config.php');

# Validate Archive Name
if(!isset($_GET['category']) || empty($_GET['category'])) { aexit('direct_access'); }
$post_category = ucfirst($_GET['category']);

# Get Post Data
$postObjs = getPosts($pdoObj, 'post_category', $post_category);

# Close Database Connection
$pdoObj=null;
?>
<!DOCTYPE html>
<!--[if IE 8]><html class="ie" xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!-->
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US">
<!--<![endif]-->

<head>
    <?php include('../partials/header.php'); ?>
    <title>News Archives for <?= $post_category; ?> - <?= $website_name; ?></title>
</head>

<body>
    <!-- wrapper -->
    <div id="wrapper">

        <?php include('../partials/nav.php'); ?>

        <!-- breadcrumb -->
        <div class="bg-surface2-color">
            <div class="tf-container">
                <ul class="breadcrumb text-caption-1 text_on-surface-color">
                    <li><a href="<?= $domain; ?>/" class="link">Home</a></li>
                    <li><?= $post_category; ?></li>
                </ul>
            </div>
        </div>
        <!-- End breadcrumb -->

        <!-- page-title -->
        <div class="page-title style-default">
            <div class="tf-container ">
                <div class="title d-flex align-items-center gap_16">
                    <h1 class="mb_12"><?= $post_category; ?></h1>
                    <span class="tag text-caption-1 text_white"><?= count($postObjs); ?> article</span>
                </div>
                <p>Your destination for discovering new ways to enhance your lifestyle from mindful living and travel
                    <br> adventures to style, wellness, and beyond.
                </p>
            </div>
        </div>
        <!-- /End page-title -->

        <div class="main-content">

            <!-- list-features-post -->
            <div class="list-features-post sw-layout pt-0 tf-spacing-1">
                <div class="tf-container">
                    <div class="swiper sw-layout wrap-tag-categories" data-preview="auto" data-destop="auto"
                        data-tablet="auto" data-mobile="auto" data-space-lg="12" data-space-md="12" data-space="12">
                        <div class="sw-button style-default text_primary-color nav-prev-layout ">
                            <i class="icon-CaretLeft"></i>
                        </div>
                        <div class="swiper-wrapper">
                            <div class="swiper-slide">
                                <a href="#" class="tag text_on-surface-color text-body-2">Healthy
                                    Living</a>
                            </div>
                            <div class="swiper-slide">
                                <a href="#" class="tag text_on-surface-color text-body-2">Skincare
                                    Tips</a>
                            </div>
                            <div class="swiper-slide">
                                <a href="#" class="tag text_on-surface-color text-body-2">Travel
                                    Diaries</a>
                            </div>
                            <div class="swiper-slide">
                                <a href="#" class="tag text_on-surface-color text-body-2">Home Decor</a>
                            </div>
                            <div class="swiper-slide">
                                <a href="#" class="tag text_on-surface-color text-body-2">Mental
                                    Health</a>
                            </div>
                            <div class="swiper-slide">
                                <a href="#" class="tag text_on-surface-color text-body-2">Fashion
                                    Trends</a>
                            </div>
                            <div class="swiper-slide">
                                <a href="#" class="tag text_on-surface-color text-body-2">Fitness
                                    Goals</a>
                            </div>
                            <div class="swiper-slide">
                                <a href="#"
                                    class="tag text_on-surface-color text-body-2">Eco-Friendly</a>
                            </div>
                            <div class="swiper-slide">
                                <a href="#" class="tag text_on-surface-color text-body-2">Remote
                                    Work</a>
                            </div>
                            <div class="swiper-slide">
                                <a href="#" class="tag text_on-surface-color text-body-2">Interior
                                    Styling</a>
                            </div>
                            <div class="swiper-slide">
                                <a href="#" class="tag text_on-surface-color text-body-2">Book
                                    Reviews</a>
                            </div>
                            <div class="swiper-slide">
                                <a href="#" class="tag text_on-surface-color text-body-2">Startup
                                    Stories</a>
                            </div>
                        </div>
                        <div class="sw-button style-default text_primary-color nav-next-layout ">
                            <i class="icon-CaretRight"></i>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-9">
                            <div>
                                <?php foreach($postObjs as $loop_postObj): ?>
                                <div class="feature-post-item style-list hover-image-translate">
                                    <div class="img-style">
                                        <img loading="lazy" src="<?= $loop_postObj['post_image']; ?>" alt="feature post">
                                        <a href="<?= $domain; ?>/archive?category=<?= strtolower($loop_postObj['post_category']); ?>" class="tag categories text-caption-2 text_white"><?= $loop_postObj['post_category']; ?></a>
                                        <div class="tag time text-caption-2 text_white"><i class="icon-Timer"></i> 4 Mins read</div>
                                        <a href="<?= $domain; ?>/single?post=<?= $loop_postObj['post_slug']; ?>" class="overlay-link"></a>
                                    </div>
                                    <div class="content">
                                        <ul class="meta-feature fw-7 d-flex mb_12 text-caption-2 text-uppercase">
                                            <li><?= $loop_postObj['post_date']; ?></li>
                                            <li><span class="text_secodary2-color">POST BY</span> <a href="#" class="link"><?= $author_name; ?></a></li>
                                        </ul>
                                        <h4 class="title"> <a href="<?= $domain; ?>/single?post=<?= $loop_postObj['post_slug']; ?>" class="link line-clamp-2"><?= $loop_postObj['post_title']; ?></a></h4>
                                        <p class="text-body-1 line-clamp-2"><?= $loop_postObj['post_summary']; ?></p>
                                    </div>
                                </div>
                                <?php endforeach ?>
                            </div>
                        </div>
                        <div class="col-lg-3">
                            <div class="sidebar">
                                <div class="sidebar__item">
                                    <h5 class="sidebar__title">
                                        Categories
                                    </h5>
                                    <ul class="sidebar-categories">
                                        <li class="item d-flex align-items-center justify-content-between">
                                            <a href="#" class="fw-7 text-body-1 text_on-surface-color">
                                                Colonial
                                            </a>
                                            <span class="number">10</span>
                                        </li>
                                        <li class="item d-flex align-items-center justify-content-between">
                                            <a href="#" class="fw-7 text-body-1 text_on-surface-color">
                                                Minimal
                                            </a>
                                            <span class="number">21</span>
                                        </li>
                                        <li class="item d-flex align-items-center justify-content-between">
                                            <a href="#" class="fw-7 text-body-1 text_on-surface-color">
                                                Craftsman
                                            </a>
                                            <span class="number">30</span>
                                        </li>
                                        <li class="item d-flex align-items-center justify-content-between">
                                            <a href="#" class="fw-7 text-body-1 text_on-surface-color">
                                                Modern
                                            </a>
                                            <span class="number">9</span>
                                        </li>
                                        <li class="item d-flex align-items-center justify-content-between">
                                            <a href="#" class="fw-7 text-body-1 text_on-surface-color">
                                                Creative
                                            </a>
                                            <span class="number">5</span>
                                        </li>
                                    </ul>
                                </div>

                                <div class="sidebar__item">
                                    <div class="text-body-3 sidebar__title fw-7 text_on-surface-color">
                                        Popular Tag
                                    </div>
                                    <ul class="list d-flex flex-wrap gap_11">
                                        <li class="tag text-caption-1"><a href="#">Breaking</a></li>
                                        <li class="tag text-caption-1"><a href="#">Fashion</a></li>
                                        <li class="tag text-caption-1"><a href="#">Technology</a></li>
                                        <li class="tag text-caption-1"><a href="#">Sports</a></li>
                                        <li class="tag text-caption-1"><a href="#">Adventure</a></li>
                                        <li class="tag text-caption-1"><a href="#">Travel List</a></li>
                                        <li class="tag text-caption-1"><a href="#">Life Style</a></li>
                                        <li class="tag text-caption-1"><a href="#">Popular Post</a></li>
                                        <li class="tag text-caption-1"><a href="#">Life Style</a></li>
                                        <li class="tag text-caption-1"><a href="#">Mussic</a></li>
                                        <li class="tag text-caption-1"><a href="#">Trending</a></li>
                                        <li class="tag text-caption-1"><a href="#">Entertaiment</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- /End list-features-post -->

        </div>

        <?php include('../partials/footer-2.php'); ?>

    </div>
    <!-- /wrapper -->

    <?php include('../partials/nav-2.php'); ?>

    <?php include('../partials/footer.php'); ?>
</body>

</html>