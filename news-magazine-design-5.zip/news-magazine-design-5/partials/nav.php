<!-- header -->
<header class="bg-surface-color">
	<!-- topbar -->
	<div class="topbar">
		<div class="tf-container">
			<div class="topbar-inner d-flex justify-content-between align-items-center">
				<ul class="tf-social d-flex lg-hide">
					<li><a href="#" class="icon-FacebookLogo"></a></li>
					<li><a href="#" class="icon-XLogo"></a></li>
					<li><a href="#" class="icon-PinterestLogo"></a></li>
					<li><a href="#" class="icon-InstagramLogo"></a></li>
				</ul>
				<a href="<?= $domain; ?>/" class="site-logo">
					<img src="<?= $domain; ?>/assets/images/logo/logo.svg" alt="logo" class="main-logo" width="193" height="44"
						data-light="<?= $domain; ?>/assets/images/logo/logo.svg" data-dark="<?= $domain; ?>/assets/images/logo/logo-dark.svg">
				</a>
				<div class="wrap d-flex justify-content-end">
					<div class="mode-check">
						<span class="label light sm-hide">Light</span>
						<div class="toggle toggle-switch-mode">
							<div class="toggle-button"></div>
						</div>
						<span class="label dark">Dark</span>
					</div>
					<a href="<?= $domain; ?>/legal/contact-us" class="tf-btn style-2 btn-switch-text animate-hover-btn md-hide">
						<span>
							<span class="btn-double-text" data-text="Let's Talk!">Let's Talk!</span>
						</span>
					</a>
				</div>
			</div>
		</div>
	</div>
	<!-- End topbar -->


	<!--  header-fixed -->
	<div class="header-menu style-default header-fixed">
		<div class="tf-container">
			<div class="header-inner d-flex justify-content-between align-items-center">
				<div class="mobile-button d-lg-none" data-bs-toggle="offcanvas" data-bs-target="#menu-mobile"
					aria-controls="menu-mobile">
					<div class="burger">
						<span></span>
						<span></span>
						<span></span>
					</div>
				</div>
				<nav class="main-menu lg-hide">
					<ul class="navigation ">
						<li class="text-menu"><a href="<?= $domain; ?>/" class="toggle splitting"><span class="text" data-splitting>Home</span><span class="text" data-splitting>Home</span></a></li>
						<li class="text-menu"><a href="<?= $domain; ?>/archive?category=celebrities" class="toggle splitting"><span class="text" data-splitting>Celebrities</span><span class="text" data-splitting>Celebrities</span></a></li>
						<li class="text-menu"><a href="<?= $domain; ?>/archive?category=travel" class="toggle splitting"><span class="text" data-splitting>Travel</span><span class="text" data-splitting>Travel</span></a></li>
						<li class="text-menu"><a href="<?= $domain; ?>/archive?category=lifestyle" class="toggle splitting"><span class="text" data-splitting>Lifestyle</span><span class="text" data-splitting>Lifestyle</span></a></li>
						<li class="text-menu"><a href="<?= $domain; ?>/archive?category=fitness" class="toggle splitting"><span class="text" data-splitting>Fitness</span><span class="text" data-splitting>Fitness</span></a></li>
						<li class="text-menu"><a href="<?= $domain; ?>/archive?category=business" class="toggle splitting"><span class="text" data-splitting>Business</span><span class="text" data-splitting>Business</span></a></li>
					</ul>
				</nav>
			</div>
		</div>
	</div>
	<!-- End  header-fixed -->

	<!-- header-menu -->
	<div class="header-menu style-default">
		<div class="tf-container">
			<div class="header-inner d-flex justify-content-between align-items-center">
				<div class="mobile-button d-lg-none" data-bs-toggle="offcanvas" data-bs-target="#menu-mobile"
					aria-controls="menu-mobile">
					<div class="burger">
						<span></span>
						<span></span>
						<span></span>
					</div>
				</div>
				<nav class="main-menu lg-hide">
					<ul class="navigation ">
						<li class="text-menu"><a href="<?= $domain; ?>/" class="toggle splitting"><span class="text" data-splitting>Home</span><span class="text" data-splitting>Home</span></a></li>
						<li class="text-menu"><a href="<?= $domain; ?>/archive?category=celebrities" class="toggle splitting"><span class="text" data-splitting>Celebrities</span><span class="text" data-splitting>Celebrities</span></a></li>
						<li class="text-menu"><a href="<?= $domain; ?>/archive?category=travel" class="toggle splitting"><span class="text" data-splitting>Travel</span><span class="text" data-splitting>Travel</span></a></li>
						<li class="text-menu"><a href="<?= $domain; ?>/archive?category=lifestyle" class="toggle splitting"><span class="text" data-splitting>Lifestyle</span><span class="text" data-splitting>Lifestyle</span></a></li>
						<li class="text-menu"><a href="<?= $domain; ?>/archive?category=fitness" class="toggle splitting"><span class="text" data-splitting>Fitness</span><span class="text" data-splitting>Fitness</span></a></li>
						<li class="text-menu"><a href="<?= $domain; ?>/archive?category=business" class="toggle splitting"><span class="text" data-splitting>Business</span><span class="text" data-splitting>Business</span></a></li>
					</ul>
				</nav>
			</div>
		</div>
	</div>
	<!-- End header-menu -->

</header>
<!-- End header -->