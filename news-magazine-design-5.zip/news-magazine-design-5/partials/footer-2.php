<div class="tf-container mt-5">
	<footer class="footer">
		<div class="footer-body">
			<div class="footer-about footer-item">
				<a href="<?= $domain; ?>/" class="site-logo mb_20">
					<img src="<?= $domain; ?>/assets/images/logo/logo.svg" alt="logo" height="193" width="44" class="main-logo" data-light="<?= $domain; ?>/assets/images/logo/logo.svg" data-dark="<?= $domain; ?>/assets/images/logo/logo-dark.svg">
				</a>
				<p class="text-caption-1 mb_28">Welcome to your go-to destination for insightful news! Discover carefully selected articles that inform, inspire.</p>
				<ul class="tf-social d-flex">
					<li><a href="#" class="icon-FacebookLogo"></a></li>
					<li><a href="#" class="icon-XLogo"></a></li>
					<li><a href="#" class="icon-PinterestLogo"></a></li>
					<li><a href="#" class="icon-InstagramLogo"></a></li>
				</ul>
			</div>
			<div class="footer-content footer-item">
				<div class="footer-col-block page-link">
					<h6 class="footer-heading  footer-heading-mobile text_color-1 mb_16">Quick Link</h6>
					<div class="tf-collapse-content">
						<ul class="footer-menu-list d-grid gap_12">
							<li class="text-caption-1"><a href="<?= $domain; ?>/legal/contact-us" class="link">Contact us</a></li>
							<li class="text-caption-1"><a href="<?= $domain; ?>/legal/terms-service" class="link">Terms Of Services</a></li>
							<li class="text-caption-1"><a href="<?= $domain; ?>/legal/privacy-policy" class="link">Privacy Policy</a></li>
							<li class="text-caption-1"><a href="<?= $domain; ?>/legal/cppa-form" class="link">Data Privacy</a></li>
						</ul>
					</div>
				</div>
				<div class="footer-col-block page-link">
					<h6 class="footer-heading  footer-heading-mobile text_color-1 mb_16">
						Categories
					</h6>
					<div class="tf-collapse-content">
						<ul class="footer-menu-list d-grid gap_12">
							<li class="text-caption-1"><a href="<?= $domain; ?>/archive?category=celebrities" class="link">Celebrities</a></li>
							<li class="text-caption-1"><a href="<?= $domain; ?>/archive?category=travel" class="link">Travel</a></li>
							<li class="text-caption-1"><a href="<?= $domain; ?>/archive?category=lifestyle" class="link">Lifestyle</a></li>
							<li class="text-caption-1"><a href="<?= $domain; ?>/archive?category=fitness" class="link">Fitness</a></li>
							<li class="text-caption-1"><a href="<?= $domain; ?>/archive?category=business" class="link">Business</a></li>
						</ul>
					</div>
				</div>
			</div>
			<div class="footer-newsletter footer-item">
				<h6 class="footer-title mb_20">Subscribe for all the top news!</h6>
				<form id="subscribe-form" method="post" accept-charset="utf-8" data-mailchimp="true" action="<?= $domain; ?>/legal/submit.php" class="form-newslate mb_20">
					<div id="subscribe-content" class="position-relative">
						<fieldset class="fieldset-item">
							<input type="email" placeholder="E-mail" id="subscribe-email" aria-required="true" required>
						</fieldset>
						<div class="box-btn">
							<button id="subscribe-button" type="button" class="btn-submit animate-hover-btn">
								<span class="icon-PaperPlaneTilt"></span>
							</button>
						</div>
					</div>
					<div id="subscribe-msg"></div>
				</form>
				<div class="box-fieldset-item d-flex ">
					<fieldset class=" d-flex  gap_12">
						<input type="checkbox" class="tf-check" id="note">
					</fieldset>
					<p class="text-body-1">By clicking the Subscribe button, you acknowledge that you have read
						and agree to our <a href="<?= $domain; ?>/legal/privacy-policy" class="fw-7 text_on-surface-color">Privacy Policy</a>
						and <a href="<?= $domain; ?>/legal/terms-service" class="fw-7 text_on-surface-color">Terms Of Use</a></p>
				</div>
			</div>
		</div>
		<div class="footer-bottom d-flex align-items-center justify-content-between">
			<p class="text-caption-1">©2025 <?= $website_name; ?>. All Rights Reserved.</p>
		</div>
	</footer>
</div>