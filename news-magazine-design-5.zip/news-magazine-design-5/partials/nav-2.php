<!-- mobile-nav -->
<div class="offcanvas offcanvas-start mobile-nav-wrap " tabindex="-1" id="menu-mobile"
	aria-labelledby="menu-mobile">
	<div class="offcanvas-header top-nav-mobile">
		<div class="offcanvas-title">
			<a href="<?= $domain; ?>/" class="site-logo">
				<img src="<?= $domain; ?>/assets/images/logo/logo.svg" alt="logo" class="main-logo" width="193" height="44"
					data-light="<?= $domain; ?>/assets/images/logo/logo.svg" data-dark="<?= $domain; ?>/assets/images/logo/logo-dark.svg">
			</a>
		</div>
		<div data-bs-dismiss="offcanvas" class="btn-close-menu">
			<i class="icon-X"></i>
		</div>
	</div>
	<div class="offcanvas-body inner-mobile-nav">
		<div class="mb-body">
			<ul id="menu-mobile-menu" class="style-1">
				<li class="menu-item"><a href="<?= $domain; ?>/" class="item-menu-mobile">Home</a></li>
				<li class="menu-item"><a href="<?= $domain; ?>/archive?category=celebrities" class="item-menu-mobile">Celebrities</a></li>
				<li class="menu-item"><a href="<?= $domain; ?>/archive?category=travel" class="item-menu-mobile">Travel</a></li>
				<li class="menu-item"><a href="<?= $domain; ?>/archive?category=lifestyle" class="item-menu-mobile">Lifestyle</a></li>
				<li class="menu-item"><a href="<?= $domain; ?>/archive?category=fitness" class="item-menu-mobile">Fitness</a></li>
				<li class="menu-item"><a href="<?= $domain; ?>/archive?category=business" class="item-menu-mobile">Business</a></li>
			</ul>
			<div class="support">
				<a href="<?= $domain; ?>/legal/contact-us" class="tf-btn style-2 animate-hover-btn">
					<span>Let's Talk!</span>
				</a>
				<a href="#" class="text-need"> Need help?</a>
				<ul class="mb-info">
					<li>
						<div class="wrap-social">
							<p>Follow us:</p>
							<ul class="tf-social d-flex style-1">
								<li><a href="#" class="icon-TwitterLogo"></a></li>
								<li><a href="#" class="icon-XLogo"></a></li>
								<li><a href="#" class="icon-FacebookLogo"></a></li>
								<li><a href="#" class="icon-PinterestLogo"></a></li>
								<li><a href="#" class="icon-InstagramLogo"></a></li>
							</ul>
						</div>
					</li>
				</ul>
			</div>
		</div>
	</div>
</div><!-- /mobile-nav -->