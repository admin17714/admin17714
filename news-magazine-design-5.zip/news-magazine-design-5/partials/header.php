<meta charset="utf-8">
<!--[if IE ]><meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"/><![endif]-->
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

<meta name="author" content="<?= $website_name; ?>">

<!-- Theme Style -->
<link rel="stylesheet" type="text/css" href="<?= $domain; ?>/assets/css/bootstrap.css">
<link rel="stylesheet" type="text/css" href="<?= $domain; ?>/assets/css/styles.css">
<link rel="stylesheet" type="text/css" href="<?= $domain; ?>/assets/css/swiper-bundle.min.css">

<!-- Font -->
<link rel="stylesheet" href="<?= $domain; ?>/assets/font/fonts.css">

<!-- Icon -->
<link rel="stylesheet" type="text/css" href="<?= $domain; ?>/assets/icons/icomoon/style.css">

<!-- Favicon and Touch Icons  -->
<link rel="shortcut icon" href="<?= $domain; ?>/assets/images/logo/favicon.svg">
<link rel="apple-touch-icon-precomposed" href="<?= $domain; ?>/assets/images/logo/favicon.svg">

<?php
$site_code_header = base64_decode($configObj['site_code_header']);
$site_code_footer = base64_decode($configObj['site_code_footer']);

$matamo_domain = $configObj['matamo_domain'];
$matamo_site_id = $configObj['matamo_site_id'];

if($site_code_header != 'NA') { echo $site_code_header; }

if($matamo_domain != 'NA' && $matamo_site_id != 'NA') { ?>
<!-- Matomo -->
<script>
  var _paq = window._paq = window._paq || [];
  /* tracker methods like "setCustomDimension" should be called before "trackPageView" */
  _paq.push(['trackPageView']);
  _paq.push(['enableLinkTracking']);
  (function() {
    var u="//<?= $matamo_domain; ?>/";
    _paq.push(['setTrackerUrl', u+'matomo.php']);
    _paq.push(['setSiteId', '<?= $matamo_site_id; ?>']);
    var d=document, g=d.createElement('script'), s=d.getElementsByTagName('script')[0];
    g.async=true; g.src=u+'matomo.js'; s.parentNode.insertBefore(g,s);
  })();
</script>
<!-- End Matomo Code -->
<?php } ?>