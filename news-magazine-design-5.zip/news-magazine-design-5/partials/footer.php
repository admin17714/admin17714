<script src="<?= $domain; ?>/assets/js/bootstrap.min.js"></script>
<script src="<?= $domain; ?>/assets/js/jquery.min.js"></script>
<script src="<?= $domain; ?>/assets/js/splitting.min.js"></script>
<script src="<?= $domain; ?>/assets/js/swiper-bundle.min.js"></script>
<script src="<?= $domain; ?>/assets/js/carousel.js"></script>
<script src="<?= $domain; ?>/assets/js/main.js"></script>

<?php if($site_code_footer != 'NA') { echo $site_code_footer; } ?>